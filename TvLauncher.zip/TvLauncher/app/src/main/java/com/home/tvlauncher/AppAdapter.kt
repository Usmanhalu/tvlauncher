package com.home.tvlauncher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppAdapter(
    private val columns: Int,
    private val onFocus: (AppEntry) -> Unit,
    private val onClick: (AppEntry) -> Unit,
    private val onLongClick: (AppEntry) -> Unit
) : RecyclerView.Adapter<AppAdapter.Holder>() {

    var items: List<AppEntry> = emptyList()
        private set

    init {
        setHasStableIds(true)
    }

    fun submit(list: List<AppEntry>) {
        items = list
        notifyDataSetChanged()
    }

    override fun getItemId(position: Int): Long = items[position].packageName.hashCode().toLong()

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        // Плитка 16:9 по ширине колонки, на любом разрешении экрана
        val cell = (parent.width - parent.paddingLeft - parent.paddingRight) / columns
        if (cell > 0) {
            val card = view.findViewById<View>(R.id.card)
            val w = cell - view.paddingLeft - view.paddingRight
            card.layoutParams = card.layoutParams.apply {
                width = w
                height = w * 9 / 16
            }
        }
        return Holder(view)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) = holder.bind(items[position])

    inner class Holder(view: View) : RecyclerView.ViewHolder(view) {
        private val card: View = view.findViewById(R.id.card)
        private val image: ImageView = view.findViewById(R.id.image)
        private val label: TextView = view.findViewById(R.id.label)
        private val density = view.resources.displayMetrics.density

        init {
            card.clipToOutline = true
        }

        fun bind(app: AppEntry) {
            if (app.banner != null) {
                image.setImageDrawable(app.banner)
                image.scaleType = ImageView.ScaleType.CENTER_CROP
                image.setPadding(0, 0, 0, 0)
            } else {
                image.setImageDrawable(app.icon)
                image.scaleType = ImageView.ScaleType.FIT_CENTER
                val p = (18 * density).toInt()
                image.setPadding(p, p, p, p)
            }
            label.text = app.label

            applyFocus(itemView.isFocused, animate = false)
            itemView.setOnClickListener { onClick(app) }
            itemView.setOnLongClickListener { onLongClick(app); true }
            itemView.setOnFocusChangeListener { _, hasFocus ->
                applyFocus(hasFocus, animate = true)
                if (hasFocus) onFocus(app)
            }
        }

        // Эффект как на Apple TV: плитка «приподнимается» и появляется подпись
        private fun applyFocus(focused: Boolean, animate: Boolean) {
            val scale = if (focused) 1.12f else 1f
            val z = if (focused) 20f * density else 0f
            val alpha = if (focused) 1f else 0f
            if (animate) {
                card.animate().scaleX(scale).scaleY(scale).translationZ(z).setDuration(150).start()
                label.animate().alpha(alpha).setDuration(150).start()
            } else {
                card.scaleX = scale
                card.scaleY = scale
                card.translationZ = z
                label.alpha = alpha
            }
        }
    }
}
