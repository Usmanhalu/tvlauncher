package com.home.tvlauncher

import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator

/** Пружинные анимации, как в iOS. */
object Motion {

    fun springOnFocus(view: View, scale: Float) {
        view.setOnFocusChangeListener { v, hasFocus -> spring(v, if (hasFocus) scale else 1f, hasFocus) }
    }

    fun spring(v: View, scale: Float, grow: Boolean) {
        v.animate()
            .scaleX(scale)
            .scaleY(scale)
            .setDuration(if (grow) 320L else 220L)
            .setInterpolator(if (grow) OvershootInterpolator(2.2f) else DecelerateInterpolator(1.6f))
            .start()
    }
}
