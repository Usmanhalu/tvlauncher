package com.home.tvlauncher

import android.graphics.drawable.Drawable

data class AppEntry(
    val packageName: String,
    val label: String,
    val banner: Drawable?,
    val icon: Drawable
)
