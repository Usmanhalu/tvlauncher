package com.home.tvlauncher

import android.graphics.Bitmap

data class AppEntry(
    val packageName: String,
    val label: String,
    val icon: Bitmap
)
