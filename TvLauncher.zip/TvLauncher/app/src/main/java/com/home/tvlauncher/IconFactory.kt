package com.home.tvlauncher

import android.content.Context
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Shader
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import android.os.Build

/** Делает квадратную иконку в стиле iOS: на всю плитку, без белых рамок, где это возможно. */
object IconFactory {

    fun make(context: Context, info: ResolveInfo, size: Int): Bitmap {
        val pm = context.packageManager
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        // У приложения нет своего значка, но есть баннер для ТВ — рисуем баннер на его фоне
        val banner = info.activityInfo.loadBanner(pm)
        if (info.iconResource == 0 && banner != null) {
            drawBanner(canvas, banner, size)
            return bmp
        }

        val icon = info.loadIcon(pm)

        // Современные адаптивные иконки: рисуем фон и рисунок на всю плитку
        if (Build.VERSION.SDK_INT >= 26 && icon is AdaptiveIconDrawable) {
            val extra = size / 4
            val bounds = Rect(-extra, -extra, size + extra, size + extra)
            icon.background?.let { it.bounds = bounds; it.draw(canvas) }
            icon.foreground?.let { it.bounds = bounds; it.draw(canvas) }
            return bmp
        }

        // Старые иконки: если углы непрозрачные — значок уже квадратный, иначе кладём на светлую плитку
        val probe = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        icon.setBounds(0, 0, size, size)
        icon.draw(Canvas(probe))
        val corners = listOf(
            probe.getPixel(3, 3), probe.getPixel(size - 4, 3),
            probe.getPixel(3, size - 4), probe.getPixel(size - 4, size - 4)
        )
        if (corners.all { Color.alpha(it) > 200 }) {
            canvas.drawBitmap(probe, 0f, 0f, null)
        } else {
            val paint = Paint().apply {
                shader = LinearGradient(
                    0f, 0f, 0f, size.toFloat(),
                    0xFFFFFFFF.toInt(), 0xFFE5E5EA.toInt(), Shader.TileMode.CLAMP
                )
            }
            canvas.drawRect(0f, 0f, size.toFloat(), size.toFloat(), paint)
            val inset = (size * 0.16f).toInt()
            icon.setBounds(inset, inset, size - inset, size - inset)
            icon.draw(canvas)
        }
        probe.recycle()
        return bmp
    }

    private fun drawBanner(canvas: Canvas, banner: Drawable, size: Int) {
        val w = 320
        val h = 180
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        banner.setBounds(0, 0, w, h)
        banner.draw(Canvas(b))
        val corner = b.getPixel(4, 4)
        canvas.drawColor(if (Color.alpha(corner) > 200) corner else 0xFF2C2C2E.toInt())
        val scaledH = size * h / w
        val top = (size - scaledH) / 2
        canvas.drawBitmap(b, null, Rect(0, top, size, top + scaledH), Paint(Paint.FILTER_BITMAP_FLAG))
        b.recycle()
    }
}
