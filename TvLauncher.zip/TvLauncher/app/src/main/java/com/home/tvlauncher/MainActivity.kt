package com.home.tvlauncher

import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs

@Suppress("DEPRECATION")
class MainActivity : Activity() {

    private lateinit var root: ViewGroup
    private lateinit var homeLayer: ViewGroup
    private lateinit var dock: LinearLayout
    private lateinit var tooltip: TextView
    private lateinit var launchpad: View
    private lateinit var launchpadGrid: RecyclerView
    private lateinit var controlCenter: View
    private lateinit var ccPanel: View
    private lateinit var ccWifi: ImageView
    private lateinit var ccWifiState: TextView
    private lateinit var ccBt: ImageView
    private lateinit var ccBtState: TextView
    private lateinit var ccVolume: SeekBar
    private lateinit var menuWifi: ImageView
    private lateinit var launchpadAdapter: LaunchpadAdapter

    private val prefs by lazy { getSharedPreferences("launcher", Context.MODE_PRIVATE) }
    private val wifi by lazy { applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager }
    private val audio by lazy { getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    private val bluetooth: BluetoothAdapter? by lazy { BluetoothAdapter.getDefaultAdapter() }

    private var allApps: List<AppEntry> = emptyList()
    private var appsSignature = ""
    private val dockViews = mutableListOf<View>()
    private var lastHomeFocus: View? = null
    private val iconPx by lazy { dp(76) }

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = loadApps(force = true)
    }

    private val statusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = refreshStatus()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        homeLayer = findViewById(R.id.home_layer)
        dock = findViewById(R.id.dock)
        tooltip = findViewById(R.id.tooltip)
        launchpad = findViewById(R.id.launchpad)
        launchpadGrid = findViewById(R.id.launchpad_grid)
        controlCenter = findViewById(R.id.control_center)
        ccPanel = findViewById(R.id.cc_panel)
        ccWifi = findViewById(R.id.cc_wifi)
        ccWifiState = findViewById(R.id.cc_wifi_state)
        ccBt = findViewById(R.id.cc_bt)
        ccBtState = findViewById(R.id.cc_bt_state)
        ccVolume = findViewById(R.id.cc_volume)
        menuWifi = findViewById(R.id.menu_wifi)

        setupLaunchpad()
        setupControlCenter()

        val controlButton = findViewById<View>(R.id.btn_control)
        controlButton.setOnClickListener { openControlCenter() }
        Motion.springOnFocus(controlButton, 1.12f)

        registerReceiver(packageReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        })
        registerReceiver(statusReceiver, IntentFilter().apply {
            addAction(WifiManager.WIFI_STATE_CHANGED_ACTION)
            addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION)
            addAction(ConnectivityManager.CONNECTIVITY_ACTION)
            addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
            addAction("android.media.VOLUME_CHANGED_ACTION")
        })
    }

    override fun onResume() {
        super.onResume()
        loadApps(force = false)
        refreshStatus()
        root.post { if (currentFocus == null) restoreHomeFocus() }
    }

    override fun onDestroy() {
        unregisterReceiver(packageReceiver)
        unregisterReceiver(statusReceiver)
        super.onDestroy()
    }

    // Нажали «Домой»: закрываем всё и встаём на Dock
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (controlCenter.visibility == View.VISIBLE) closeControlCenter()
        if (launchpad.visibility == View.VISIBLE) closeLaunchpad()
        root.post { dockViews.firstOrNull()?.requestFocus() }
    }

    override fun onBackPressed() {
        when {
            controlCenter.visibility == View.VISIBLE -> closeControlCenter()
            launchpad.visibility == View.VISIBLE -> closeLaunchpad()
            else -> Unit // главный экран не закрывается
        }
    }

    // Кнопка «Меню» на пульте открывает и закрывает шторку
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            if (controlCenter.visibility == View.VISIBLE) closeControlCenter()
            else if (launchpad.visibility != View.VISIBLE) openControlCenter()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // ================= Приложения =================

    private fun loadApps(force: Boolean) {
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val infos = packageManager.queryIntentActivities(query, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }

        val signature = infos.joinToString(",") { it.activityInfo.packageName } +
            "|" + hiddenSet().sorted().joinToString(",") +
            "|" + prefs.getString(KEY_DOCK, "")
        if (!force && signature == appsSignature) return
        appsSignature = signature

        allApps = infos
            .map { AppEntry(it.activityInfo.packageName, it.loadLabel(packageManager).toString(), IconFactory.make(this, it, iconPx)) }
            .sortedBy { it.label.lowercase() }

        val hidden = hiddenSet()
        val visible = allApps.filter { it.packageName !in hidden }
        if (prefs.getString(KEY_DOCK, null) == null) {
            saveDock(visible.take(DEFAULT_DOCK_SIZE).map { it.packageName })
        }

        launchpadAdapter.submit(visible)

        val focusedIndex = dockViews.indexOfFirst { it.isFocused }
        buildDock(visible)
        root.post {
            if (launchpad.visibility != View.VISIBLE && controlCenter.visibility != View.VISIBLE) {
                (dockViews.getOrNull(focusedIndex) ?: if (currentFocus == null) dockViews.firstOrNull() else null)
                    ?.requestFocus()
            }
        }
    }

    private fun launch(app: AppEntry, from: View?) {
        val intent = packageManager.getLeanbackLaunchIntentForPackage(app.packageName)
            ?: packageManager.getLaunchIntentForPackage(app.packageName)
        if (intent == null) {
            toast(R.string.cannot_open)
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        // Приложение «вырастает» из значка, как в iOS
        val options = from?.let { ActivityOptions.makeScaleUpAnimation(it, 0, 0, it.width, it.height).toBundle() }
        try {
            startActivity(intent, options)
        } catch (e: Exception) {
            toast(R.string.cannot_open)
            return
        }
        if (launchpad.visibility == View.VISIBLE) root.postDelayed({ hideLaunchpadNow() }, 450)
    }

    // ================= Dock =================

    private fun dockPackages(): List<String> =
        prefs.getString(KEY_DOCK, "").orEmpty().split(",").filter { it.isNotBlank() }

    private fun saveDock(list: List<String>) {
        prefs.edit().putString(KEY_DOCK, list.joinToString(",")).apply()
    }

    private fun buildDock(visible: List<AppEntry>) {
        dock.removeAllViews()
        dockViews.clear()

        val byPackage = visible.associateBy { it.packageName }
        dockPackages().mapNotNull { byPackage[it] }.forEach { app ->
            val item = LayoutInflater.from(this).inflate(R.layout.item_dock, dock, false)
            val icon = item.findViewById<ImageView>(R.id.icon)
            icon.setImageBitmap(app.icon)
            icon.clipToOutline = true
            item.setOnClickListener { launch(app, icon) }
            item.setOnLongClickListener { showAppMenu(app); true }
            addDockItem(item, app.label)
        }

        // Разделитель, как в Dock на Mac
        dock.addView(View(this).apply {
            setBackgroundColor(0x59FFFFFF)
            layoutParams = LinearLayout.LayoutParams(dp(1), dp(54)).apply {
                setMargins(dp(10), 0, dp(10), dp(5))
            }
        })

        val all = LayoutInflater.from(this).inflate(R.layout.item_dock, dock, false)
        val allIcon = all.findViewById<ImageView>(R.id.icon)
        allIcon.setBackgroundResource(R.drawable.launchpad_tile)
        allIcon.setImageResource(R.drawable.ic_apps)
        allIcon.scaleType = ImageView.ScaleType.FIT_CENTER
        val p = dp(16)
        allIcon.setPadding(p, p, p, p)
        all.setOnClickListener { openLaunchpad() }
        addDockItem(all, getString(R.string.launchpad))
    }

    private fun addDockItem(item: View, label: String) {
        val index = dockViews.size
        dockViews += item
        dock.addView(item)
        item.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                lastHomeFocus = v
                magnify(index)
                showTooltip(v, label)
            } else {
                v.post {
                    if (dockViews.none { it.isFocused }) {
                        magnify(-1)
                        hideTooltip()
                    }
                }
            }
        }
    }

    // Увеличение значков как в Dock на Mac: выбранный крупнее всех, соседи чуть меньше
    private fun magnify(center: Int) {
        dockViews.forEachIndexed { i, v ->
            val d = if (center < 0) 99 else abs(i - center)
            val scale = when (d) { 0 -> 1.4f; 1 -> 1.16f; 2 -> 1.05f; else -> 1f }
            val lift = when (d) { 0 -> -dp(16); 1 -> -dp(6); 2 -> -dp(2); else -> 0 }.toFloat()
            val push = when {
                center < 0 || d == 0 -> 0
                d == 1 -> dp(9)
                d == 2 -> dp(14)
                else -> dp(16)
            } * (if (i < center) -1 else 1)
            v.pivotX = v.width / 2f
            v.pivotY = v.height.toFloat()
            v.animate()
                .scaleX(scale).scaleY(scale)
                .translationY(lift).translationX(push.toFloat())
                .setDuration(300)
                .setInterpolator(OvershootInterpolator(1.5f))
                .start()
        }
    }

    private fun showTooltip(anchor: View, label: String) {
        tooltip.animate().cancel()
        tooltip.text = label
        tooltip.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val a = IntArray(2)
        val r = IntArray(2)
        anchor.getLocationInWindow(a)
        root.getLocationInWindow(r)
        tooltip.translationX = a[0] - r[0] + anchor.width / 2f - tooltip.measuredWidth / 2f
        tooltip.translationY = (a[1] - r[1]).toFloat() - tooltip.measuredHeight - dp(40)
        tooltip.visibility = View.VISIBLE
        tooltip.alpha = 0f
        tooltip.animate().alpha(1f).setDuration(160).start()
    }

    private fun hideTooltip() {
        tooltip.animate().cancel()
        tooltip.animate().alpha(0f).setDuration(120)
            .withEndAction { tooltip.visibility = View.INVISIBLE }
            .start()
    }

    private fun restoreHomeFocus() {
        root.post {
            val target = lastHomeFocus?.takeIf { it.isAttachedToWindow } ?: dockViews.firstOrNull()
            target?.requestFocus()
        }
    }

    // ================= Все приложения =================

    private fun setupLaunchpad() {
        launchpadAdapter = LaunchpadAdapter(
            onClick = { app, v -> launch(app, v) },
            onLongClick = { showAppMenu(it) }
        )
        launchpadGrid.layoutManager = GridLayoutManager(this, LAUNCHPAD_COLUMNS)
        launchpadGrid.adapter = launchpadAdapter
        launchpadGrid.itemAnimator = null
    }

    private fun openLaunchpad() {
        if (launchpad.visibility == View.VISIBLE) return
        hideTooltip()
        homeLayer.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS

        launchpad.animate().cancel()
        launchpad.visibility = View.VISIBLE
        launchpad.alpha = 0f
        launchpad.scaleX = 1.12f
        launchpad.scaleY = 1.12f
        launchpad.animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(340).setInterpolator(DecelerateInterpolator(2f)).start()

        homeLayer.animate().alpha(0f).scaleX(0.92f).scaleY(0.92f)
            .setDuration(340).setInterpolator(DecelerateInterpolator(2f)).start()

        launchpadGrid.scrollToPosition(0)
        launchpadGrid.post { launchpadGrid.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
    }

    private fun closeLaunchpad() {
        launchpad.animate().cancel()
        launchpad.animate().alpha(0f).scaleX(1.12f).scaleY(1.12f)
            .setDuration(260).setInterpolator(AccelerateInterpolator(1.5f))
            .withEndAction { launchpad.visibility = View.GONE }
            .start()
        homeLayer.animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setDuration(360).setInterpolator(DecelerateInterpolator(2f)).start()
        homeLayer.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        restoreHomeFocus()
    }

    private fun hideLaunchpadNow() {
        launchpad.animate().cancel()
        launchpad.visibility = View.GONE
        homeLayer.animate().cancel()
        homeLayer.alpha = 1f
        homeLayer.scaleX = 1f
        homeLayer.scaleY = 1f
        homeLayer.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
    }

    // ================= Пункт управления =================

    private fun setupControlCenter() {
        ccPanel.addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ ->
            v.pivotX = v.width.toFloat()
            v.pivotY = 0f
        }

        ccWifi.setOnClickListener { toggleWifi() }
        ccBt.setOnClickListener { toggleBluetooth() }
        Motion.springOnFocus(ccWifi, 1.15f)
        Motion.springOnFocus(ccBt, 1.15f)

        bindTile(R.id.cc_display) {
            startSafely(Intent(Settings.ACTION_DISPLAY_SETTINGS), Intent(Settings.ACTION_SETTINGS))
        }
        bindTile(R.id.cc_network) {
            startSafely(Intent(Settings.ACTION_WIFI_SETTINGS), Intent(Settings.ACTION_SETTINGS))
        }
        bindTile(R.id.cc_settings) { startSafely(Intent(Settings.ACTION_SETTINGS)) }
        bindTile(R.id.cc_hidden) { showHiddenApps() }
        bindTile(R.id.cc_apps) {
            closeControlCenter()
            openLaunchpad()
        }

        Motion.springOnFocus(ccVolume, 1.04f)
        ccVolume.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) audio.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) = Unit
            override fun onStopTrackingTouch(seekBar: SeekBar) = Unit
        })
    }

    private fun bindTile(id: Int, action: () -> Unit) {
        val v = findViewById<View>(id)
        v.setOnClickListener { action() }
        Motion.springOnFocus(v, 1.06f)
    }

    private fun openControlCenter() {
        if (controlCenter.visibility == View.VISIBLE) return
        hideTooltip()
        refreshStatus()
        homeLayer.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS

        controlCenter.animate().cancel()
        controlCenter.visibility = View.VISIBLE
        controlCenter.alpha = 0f
        controlCenter.animate().alpha(1f).setDuration(220).start()

        // Шторка «выезжает» из правого верхнего угла с пружинкой
        ccPanel.animate().cancel()
        ccPanel.scaleX = 0.82f
        ccPanel.scaleY = 0.82f
        ccPanel.translationY = -dp(36).toFloat()
        ccPanel.animate().scaleX(1f).scaleY(1f).translationY(0f)
            .setDuration(420).setInterpolator(OvershootInterpolator(1.1f)).start()

        homeLayer.animate().alpha(0.55f).scaleX(0.97f).scaleY(0.97f).setDuration(300).start()
        root.post { ccWifi.requestFocus() }
    }

    private fun closeControlCenter() {
        controlCenter.animate().cancel()
        controlCenter.animate().alpha(0f).setDuration(220)
            .withEndAction { controlCenter.visibility = View.GONE }
            .start()
        ccPanel.animate().cancel()
        ccPanel.animate().scaleX(0.88f).scaleY(0.88f).translationY(-dp(24).toFloat())
            .setDuration(220).setInterpolator(AccelerateInterpolator(1.4f)).start()

        if (launchpad.visibility != View.VISIBLE) {
            homeLayer.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(320).setInterpolator(DecelerateInterpolator(2f)).start()
            homeLayer.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
            restoreHomeFocus()
        }
    }

    private fun toggleWifi() {
        val enable = !wifi.isWifiEnabled
        val ok = try {
            wifi.setWifiEnabled(enable)
        } catch (e: SecurityException) {
            false
        }
        if (ok) {
            ccWifiState.setText(if (enable) R.string.turning_on else R.string.turning_off)
            setCircle(ccWifi, enable)
        } else {
            startSafely(Intent(Settings.ACTION_WIFI_SETTINGS), Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun toggleBluetooth() {
        val adapter = bluetooth
        if (adapter == null) {
            toast(R.string.unavailable)
            return
        }
        if (adapter.isEnabled) {
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle(R.string.bt_off_title)
                .setMessage(R.string.bt_off_message)
                .setPositiveButton(R.string.turn_off) { _, _ -> setBluetooth(adapter, false) }
                .setNegativeButton(R.string.cancel, null)
                .show()
        } else {
            setBluetooth(adapter, true)
        }
    }

    private fun setBluetooth(adapter: BluetoothAdapter, enable: Boolean) {
        val ok = try {
            if (enable) adapter.enable() else adapter.disable()
        } catch (e: SecurityException) {
            false
        }
        if (ok) {
            ccBtState.setText(if (enable) R.string.turning_on else R.string.turning_off)
            setCircle(ccBt, enable)
        } else {
            startSafely(Intent(Settings.ACTION_BLUETOOTH_SETTINGS), Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun refreshStatus() {
        val wifiOn = wifi.isWifiEnabled
        val caps = getSystemService(ConnectivityManager::class.java)?.let { cm ->
            cm.activeNetwork?.let { cm.getNetworkCapabilities(it) }
        }
        val onWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        val onCable = caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true
        val ssid = wifi.connectionInfo?.ssid?.trim('"')?.takeIf { it.isNotBlank() && it != "<unknown ssid>" }

        ccWifiState.text = when {
            onCable && !onWifi -> getString(R.string.cable)
            !wifiOn -> getString(R.string.off)
            onWifi && ssid != null -> ssid
            onWifi -> getString(R.string.connected)
            else -> getString(R.string.on)
        }
        setCircle(ccWifi, wifiOn)
        menuWifi.alpha = if (onWifi || onCable) 1f else 0.35f

        val adapter = bluetooth
        val btOn = adapter?.isEnabled == true
        ccBtState.setText(
            when {
                adapter == null -> R.string.unavailable
                btOn -> R.string.on
                else -> R.string.off
            }
        )
        setCircle(ccBt, btOn)

        ccVolume.max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        ccVolume.keyProgressIncrement = 1
        ccVolume.progress = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
    }

    private fun setCircle(v: View, on: Boolean) {
        v.setBackgroundResource(if (on) R.drawable.cc_circle_on else R.drawable.cc_circle_off)
    }

    // ================= Меню приложения и скрытые =================

    private fun showAppMenu(app: AppEntry) {
        val inDock = app.packageName in dockPackages()
        val actions = arrayOf(
            getString(if (inDock) R.string.remove_dock else R.string.add_dock),
            getString(R.string.hide),
            getString(R.string.app_info),
            getString(R.string.uninstall)
        )
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(app.label)
            .setItems(actions) { _, which ->
                val uri = Uri.parse("package:${app.packageName}")
                when (which) {
                    0 -> toggleDock(app)
                    1 -> setHidden(app.packageName, true)
                    2 -> startSafely(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                    3 -> startSafely(Intent(Intent.ACTION_DELETE, uri))
                }
            }
            .show()
    }

    private fun toggleDock(app: AppEntry) {
        val list = dockPackages().toMutableList()
        if (app.packageName in list) {
            list.remove(app.packageName)
        } else {
            if (list.size >= MAX_DOCK) {
                toast(R.string.dock_full)
                return
            }
            list.add(app.packageName)
        }
        saveDock(list)
        loadApps(force = true)
    }

    private fun hiddenSet(): Set<String> = prefs.getStringSet(KEY_HIDDEN, emptySet()).orEmpty()

    private fun setHidden(pkg: String, hidden: Boolean) {
        val set = hiddenSet().toMutableSet()
        if (hidden) set.add(pkg) else set.remove(pkg)
        prefs.edit().putStringSet(KEY_HIDDEN, set).apply()
        loadApps(force = true)
    }

    private fun showHiddenApps() {
        val hidden = hiddenSet()
        val apps = allApps.filter { it.packageName in hidden }
        if (apps.isEmpty()) {
            toast(R.string.nothing_hidden)
            return
        }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(R.string.hidden_title)
            .setItems(apps.map { it.label }.toTypedArray()) { _, which ->
                setHidden(apps[which].packageName, false)
            }
            .setNegativeButton(R.string.close, null)
            .show()
    }

    // ================= Вспомогательное =================

    private fun startSafely(intent: Intent, fallback: Intent? = null) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            if (fallback != null) startSafely(fallback) else toast(R.string.cannot_open)
        }
    }

    private fun toast(res: Int) = Toast.makeText(this, res, Toast.LENGTH_SHORT).show()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    companion object {
        private const val LAUNCHPAD_COLUMNS = 7
        private const val DEFAULT_DOCK_SIZE = 7
        private const val MAX_DOCK = 10
        private const val KEY_DOCK = "dock"
        private const val KEY_HIDDEN = "hidden"
    }
}
