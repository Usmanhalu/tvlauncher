package com.home.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ResolveInfo
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : Activity() {

    private lateinit var grid: RecyclerView
    private lateinit var shelfImage: ImageView
    private lateinit var shelfTitle: TextView
    private lateinit var adapter: AppAdapter

    private val prefs by lazy { getSharedPreferences("launcher", Context.MODE_PRIVATE) }
    private var allApps: List<AppEntry> = emptyList()

    // Обновляем список, когда приложение установили, удалили или отключили
    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = loadApps()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        grid = findViewById(R.id.grid)
        shelfImage = findViewById(R.id.shelf_image)
        shelfTitle = findViewById(R.id.shelf_title)
        findViewById<View>(R.id.shelf_card).clipToOutline = true

        adapter = AppAdapter(
            columns = COLUMNS,
            onFocus = { showOnShelf(it) },
            onClick = { launch(it) },
            onLongClick = { showAppMenu(it) }
        )
        grid.layoutManager = GridLayoutManager(this, COLUMNS)
        grid.adapter = adapter
        grid.itemAnimator = null

        findViewById<View>(R.id.btn_settings).setOnClickListener {
            startSafely(Intent(Settings.ACTION_SETTINGS))
        }
        findViewById<View>(R.id.btn_hidden).setOnClickListener { showHiddenApps() }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        registerReceiver(packageReceiver, filter)
    }

    override fun onResume() {
        super.onResume()
        loadApps()
    }

    override fun onDestroy() {
        unregisterReceiver(packageReceiver)
        super.onDestroy()
    }

    // Нажали «Домой», когда лаунчер уже открыт: возвращаемся к первой плитке
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        grid.scrollToPosition(0)
        grid.post { focusFirst() }
    }

    @Deprecated("Главный экран не закрывается кнопкой «Назад»")
    override fun onBackPressed() {
        // Ничего не делаем
    }

    private fun focusFirst() {
        grid.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus()
    }

    private fun loadApps() {
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        allApps = packageManager.queryIntentActivities(query, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { it.toEntry() }

        val hidden = hiddenSet()
        adapter.submit(sortByUserOrder(allApps.filter { it.packageName !in hidden }))
        grid.post { if (currentFocus == null || !currentFocus!!.isAttachedToWindow) focusFirst() }
    }

    private fun ResolveInfo.toEntry(): AppEntry {
        val info = activityInfo
        return AppEntry(
            packageName = info.packageName,
            label = loadLabel(packageManager).toString(),
            banner = info.loadBanner(packageManager)
                ?: info.applicationInfo.loadBanner(packageManager),
            icon = loadIcon(packageManager)
        )
    }

    // ---------- Порядок и скрытые приложения ----------

    private fun savedOrder(): List<String> =
        prefs.getString(KEY_ORDER, "").orEmpty().split(",").filter { it.isNotBlank() }

    private fun sortByUserOrder(apps: List<AppEntry>): List<AppEntry> {
        val order = savedOrder()
        return apps.sortedWith(
            compareBy<AppEntry>(
                { order.indexOf(it.packageName).let { i -> if (i < 0) Int.MAX_VALUE else i } },
                { it.label.lowercase() }
            )
        )
    }

    private fun moveToFront(app: AppEntry) {
        val newOrder = listOf(app.packageName) +
            adapter.items.map { it.packageName }.filter { it != app.packageName }
        prefs.edit().putString(KEY_ORDER, newOrder.joinToString(",")).apply()
        loadApps()
        grid.scrollToPosition(0)
        grid.post { focusFirst() }
    }

    private fun hiddenSet(): Set<String> =
        prefs.getStringSet(KEY_HIDDEN, emptySet()).orEmpty()

    private fun setHidden(pkg: String, hidden: Boolean) {
        val set = hiddenSet().toMutableSet()
        if (hidden) set.add(pkg) else set.remove(pkg)
        prefs.edit().putStringSet(KEY_HIDDEN, set).apply()
        loadApps()
    }

    // ---------- Действия ----------

    private fun launch(app: AppEntry) {
        val intent = packageManager.getLeanbackLaunchIntentForPackage(app.packageName)
            ?: packageManager.getLaunchIntentForPackage(app.packageName)
        if (intent == null) {
            Toast.makeText(this, R.string.cannot_open, Toast.LENGTH_SHORT).show()
            return
        }
        startSafely(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun startSafely(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, R.string.cannot_open, Toast.LENGTH_SHORT).show()
        }
    }

    private fun showOnShelf(app: AppEntry) {
        shelfImage.setImageDrawable(app.banner ?: app.icon)
        shelfImage.scaleType =
            if (app.banner != null) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER
        shelfTitle.text = app.label
        shelfImage.alpha = 0f
        shelfImage.animate().alpha(1f).setDuration(180).start()
    }

    private fun showAppMenu(app: AppEntry) {
        val actions = arrayOf(
            getString(R.string.move_first),
            getString(R.string.hide),
            getString(R.string.app_info),
            getString(R.string.uninstall)
        )
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(app.label)
            .setItems(actions) { _, which ->
                val uri = Uri.parse("package:${app.packageName}")
                when (which) {
                    0 -> moveToFront(app)
                    1 -> setHidden(app.packageName, true)
                    2 -> startSafely(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                    3 -> startSafely(Intent(Intent.ACTION_DELETE, uri))
                }
            }
            .show()
    }

    private fun showHiddenApps() {
        val hidden = hiddenSet()
        val apps = allApps.filter { it.packageName in hidden }.sortedBy { it.label.lowercase() }
        if (apps.isEmpty()) {
            Toast.makeText(this, R.string.nothing_hidden, Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(R.string.hidden_title)
            .setItems(apps.map { it.label }.toTypedArray()) { _, which ->
                setHidden(apps[which].packageName, false)
            }
            .setNegativeButton(R.string.close, null)
            .show()
    }

    companion object {
        private const val COLUMNS = 5
        private const val KEY_ORDER = "order"
        private const val KEY_HIDDEN = "hidden"
    }
}
