package com.home.tvlauncher

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class LaunchpadAdapter(
    private val onClick: (AppEntry, View) -> Unit,
    private val onLongClick: (AppEntry) -> Unit
) : RecyclerView.Adapter<LaunchpadAdapter.Holder>() {

    var items: List<AppEntry> = emptyList()
        private set

    init {
        setHasStableIds(true)
    }

    fun submit(list: List<AppEntry>) {
        items = list
        notifyDataSetChanged()
    }

    override fun getItemId(position: Int): Long = items[position].packageName.hashCode().toLong()

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_launchpad, parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) = holder.bind(items[position])

    inner class Holder(view: View) : RecyclerView.ViewHolder(view) {
        private val icon: ImageView = view.findViewById(R.id.icon)
        private val label: TextView = view.findViewById(R.id.label)

        init {
            icon.clipToOutline = true
            Motion.springOnFocus(view, 1.18f)
        }

        fun bind(app: AppEntry) {
            icon.setImageBitmap(app.icon)
            label.text = app.label
            itemView.setOnClickListener { onClick(app, icon) }
            itemView.setOnLongClickListener { onLongClick(app); true }
        }
    }
}
