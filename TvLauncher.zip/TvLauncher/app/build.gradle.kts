plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.home.tvlauncher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.home.tvlauncher"
        minSdk = 24
        // 28: на Android 9 разрешает лаунчеру самому включать и выключать Wi-Fi
        targetSdk = 28
        versionCode = 2
        versionName = "2.0"
    }

    // Постоянный ключ подписи: новые версии ставятся поверх старой без удаления
    signingConfigs {
        getByName("debug") {
            storeFile = file("launcher.keystore")
            storePassword = "launcher"
            keyAlias = "launcher"
            keyPassword = "launcher"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.recyclerview:recyclerview:1.3.2")
}
