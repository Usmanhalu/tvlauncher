package com.home.tvlauncher

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object AlarmScheduler {

    private fun prefs(c: Context) = c.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    private fun pending(c: Context, code: Int): PendingIntent = PendingIntent.getActivity(
        c, code,
        Intent(c, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun setAt(c: Context, time: Long, code: Int) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(c, code)
        val show = PendingIntent.getActivity(
            c, 100, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(time, show), pi)
        } catch (e: Exception) {
            try {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, pi)
            } catch (e2: Exception) {
                am.set(AlarmManager.RTC_WAKEUP, time, pi)
            }
        }
    }

    /** Поставить (или снять) основной будильник по настройкам */
    fun schedule(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(c, 1))
        val p = prefs(c)
        if (!p.getBoolean("al_on", false)) return
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, p.getInt("al_h", 7))
            set(Calendar.MINUTE, p.getInt("al_m", 0))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis() + 5000) add(Calendar.DAY_OF_YEAR, 1)
        }
        setAt(c, cal.timeInMillis, 1)
    }

    /** Вызывается, когда будильник сработал */
    fun afterFired(c: Context) {
        val p = prefs(c)
        if (p.getBoolean("al_daily", true)) schedule(c) else p.edit().putBoolean("al_on", false).apply()
    }

    fun snooze(c: Context, minutes: Int) = setAt(c, System.currentTimeMillis() + minutes * 60_000L, 2)
}
