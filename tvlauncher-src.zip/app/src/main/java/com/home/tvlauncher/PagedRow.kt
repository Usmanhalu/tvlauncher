package com.home.tvlauncher

import android.content.Context
import android.graphics.Rect
import android.view.KeyEvent
import android.widget.HorizontalScrollView

/** Горизонтальный ряд, который не листается сам — листанием управляет лаунчер (по 5 целых плиток). */
class PagedRow(context: Context) : HorizontalScrollView(context) {
    override fun computeScrollDeltaToGetChildRectOnScreen(rect: Rect): Int = 0
    override fun executeKeyEvent(event: KeyEvent): Boolean = false
}
