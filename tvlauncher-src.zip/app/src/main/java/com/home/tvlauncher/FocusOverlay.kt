package com.home.tvlauncher

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.PI
import kotlin.math.sin

/**
 * Рамка выбора поверх экрана:
 *  - плавно переезжает от плитки к плитке;
 *  - мягко пульсирует;
 *  - рисует на выбранной плитке «стекло» как в iPhone: блик сверху,
 *    светящуюся кромку и пробегающий отблеск.
 */
class FocusOverlay(context: Context) : View(context) {

    private val density = resources.displayMetrics.density
    private val cur = RectF()
    private val from = RectF()
    private val tmp = RectF()
    private val r1 = RectF()
    private val r2 = RectF()
    private val clip = Path()
    private val loc = IntArray(2)
    private val myLoc = IntArray(2)

    private var target: View? = null
    private var targetCorner = 10f * density
    private var curCorner = targetCorner
    private var fromCorner = targetCorner
    private var progress = 1f
    private var anim: ValueAnimator? = null

    var targetScale = 1.12f
    private val pad = 3f * density

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * density
        color = Color.WHITE
    }
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 7f * density
    }
    private val gloss = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shine = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.5f * density
    }

    var frameColor: Int = Color.WHITE
        set(value) {
            field = value
            stroke.color = value
            invalidate()
        }

    // постоянный «тикер» для пульса и отблеска
    private val ticker = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1000L
        repeatCount = ValueAnimator.INFINITE
        addUpdateListener { if (target != null) update() }
    }

    init {
        isFocusable = false
        isClickable = false
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        ticker.start()
    }

    override fun onDetachedFromWindow() {
        ticker.cancel()
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    private fun computeTarget(v: View, out: RectF): Boolean {
        if (!v.isAttachedToWindow || v.width == 0 || v.height == 0) return false
        v.getLocationInWindow(loc)
        getLocationInWindow(myLoc)
        val cx = loc[0] - myLoc[0] + v.width * v.scaleX / 2f
        val cy = loc[1] - myLoc[1] + v.height * v.scaleY / 2f
        val hw = v.width * targetScale / 2f + pad
        val hh = v.height * targetScale / 2f + pad
        out.set(cx - hw, cy - hh, cx + hw, cy + hh)
        return true
    }

    /** @param cornerPx радиус скругления самой карточки (без увеличения) */
    fun moveTo(v: View, cornerPx: Float) {
        val hadFrame = target != null && !cur.isEmpty
        target = v
        targetCorner = cornerPx * targetScale + pad
        anim?.cancel()
        if (!hadFrame) {
            progress = 1f
            curCorner = targetCorner
            update()
            return
        }
        from.set(cur)
        fromCorner = curCorner
        progress = 0f
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 240L
            interpolator = DecelerateInterpolator(1.8f)
            addUpdateListener {
                progress = it.animatedValue as Float
                update()
            }
            start()
        }
    }

    fun hide() {
        target = null
        cur.setEmpty()
        invalidate()
    }

    fun update() {
        val v = target ?: return
        if (!computeTarget(v, tmp)) return
        if (progress >= 1f) {
            cur.set(tmp)
            curCorner = targetCorner
        } else {
            val p = progress
            cur.set(
                from.left + (tmp.left - from.left) * p,
                from.top + (tmp.top - from.top) * p,
                from.right + (tmp.right - from.right) * p,
                from.bottom + (tmp.bottom - from.bottom) * p
            )
            curCorner = fromCorner + (targetCorner - fromCorner) * p
        }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (target == null || cur.isEmpty) return
        val now = SystemClock.uptimeMillis()
        val pulse = ((sin(now / 1500.0 * 2 * PI) + 1) / 2).toFloat()   // 0..1

        // ---- стекло на самой карточке ----
        r1.set(cur.left + pad, cur.top + pad, cur.right - pad, cur.bottom - pad)
        val rc = (curCorner - pad).coerceAtLeast(0f)
        clip.reset()
        clip.addRoundRect(r1, rc, rc, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(clip)

        // блик сверху
        gloss.shader = LinearGradient(
            0f, r1.top, 0f, r1.top + r1.height() * 0.55f,
            0x59FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP
        )
        canvas.drawRect(r1.left, r1.top, r1.right, r1.top + r1.height() * 0.55f, gloss)

        // пробегающий отблеск раз в ~3 секунды
        val phase = (now % 3000L) / 3000f
        if (phase < 0.4f) {
            val f = phase / 0.4f
            val w = r1.width()
            val x = r1.left - w * 0.5f + (w * 2f) * f
            val band = w * 0.22f
            shine.shader = LinearGradient(
                x - band, r1.top, x + band, r1.bottom,
                intArrayOf(0x00FFFFFF, 0x55FFFFFF, 0x00FFFFFF), floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawRect(r1, shine)
        }
        canvas.restore()

        // светящаяся кромка стекла
        edge.shader = LinearGradient(
            r1.left, r1.top, r1.right, r1.bottom,
            intArrayOf(0xE6FFFFFF.toInt(), 0x33FFFFFF, 0x99FFFFFF.toInt()), floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(r1, rc, rc, edge)

        // ---- пульсирующая рамка ----
        val grow = pulse * 2.5f * density
        r2.set(cur.left - grow, cur.top - grow, cur.right + grow, cur.bottom + grow)
        val o = 4f * density
        val haloAlpha = (40 + pulse * 90).toInt()
        halo.color = (frameColor and 0x00FFFFFF) or (haloAlpha shl 24)
        r1.set(r2.left - o, r2.top - o, r2.right + o, r2.bottom + o)
        canvas.drawRoundRect(r1, curCorner + grow + o, curCorner + grow + o, halo)
        canvas.drawRoundRect(r2, curCorner + grow, curCorner + grow, stroke)
    }
}
