package com.home.tvlauncher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.widget.FrameLayout
import kotlin.math.max

/**
 * Панель «матовое стекло»: под ней размытые обои ровно того места,
 * где она стоит, плюс тонировка в цвет обоев, блик и светлая кромка.
 */
class FrostedPanel(context: Context) : FrameLayout(context) {

    private val d = resources.displayMetrics.density
    var cornerRadius = 24f * d

    var blurred: Bitmap? = null
        set(value) {
            field = value
            invalidate()
        }

    var tint: Int = 0x99202840.toInt()
        set(value) {
            field = value
            tintPaint.color = value
            invalidate()
        }

    private val rect = RectF()
    private val path = Path()
    private val m = Matrix()
    private val loc = IntArray(2)
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val tintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x99202840.toInt() }
    private val glossPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f * d
    }

    init {
        setWillNotDraw(false)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        rect.set(0f, 0f, w, h)
        path.reset()
        path.addRoundRect(rect, cornerRadius, cornerRadius, Path.Direction.CW)

        canvas.save()
        canvas.clipPath(path)
        val b = blurred
        if (b != null && !b.isRecycled) {
            getLocationInWindow(loc)
            val root = rootView
            val sw = root.width.toFloat()
            val sh = root.height.toFloat()
            val s = max(sw / b.width, sh / b.height)
            m.reset()
            m.setScale(s, s)
            m.postTranslate((sw - b.width * s) / 2f - loc[0], (sh - b.height * s) / 2f - loc[1])
            canvas.drawBitmap(b, m, bmpPaint)
        }
        canvas.drawRect(rect, tintPaint)
        glossPaint.shader = LinearGradient(0f, 0f, 0f, h * 0.45f, 0x2EFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h * 0.45f, glossPaint)
        canvas.restore()

        border.shader = LinearGradient(
            0f, 0f, w, h,
            intArrayOf(0x99FFFFFF.toInt(), 0x22FFFFFF, 0x55FFFFFF), floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        val i = border.strokeWidth / 2f
        rect.set(i, i, w - i, h - i)
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius, border)
    }
}
