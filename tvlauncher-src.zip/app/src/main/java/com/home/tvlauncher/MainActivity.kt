package com.home.tvlauncher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.TransitionDrawable
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.AdapterView
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.Collator
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : Activity() {

    data class AppEntry(
        val pkg: String,
        val label: String,
        val banner: Drawable?,
        val icon: Drawable?,
        val launch: Intent
    )

    data class InputEntry(val id: String, val label: String, val device: String?)

    companion object {
        private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

        private const val FAV_W = 176
        private const val FAV_H = 99
        private const val GRID_W = 144
        private const val GRID_H = 81
        private const val GAP = 26

        private const val SLIDE_MS = 15 * 60 * 1000L
        private const val WEATHER_MS = 30 * 60 * 1000L
        private const val REQ_FILES = 7
        private const val MOVE_COLOR = 0xFFFFC233.toInt()
        private const val DEFAULT_WP = "builtin:9"

        private const val PANEL_ADD = 1
        private const val PANEL_LAUNCH = 2

        private val IMG_EXT = setOf("jpg", "jpeg", "png", "webp")

        private val DEFAULT_FAVS = listOf(
            "com.google.android.youtube.tv",
            "com.netflix.ninja",
            "ru.kinopoisk.tv",
            "ru.ivi.client",
            "com.google.android.youtube.tvmusic",
            "com.sony.dtv.tvx"
        )
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var wallpaperView: ImageView
    private lateinit var overlay: FocusOverlay
    private lateinit var scroll: ScrollView
    private lateinit var content: LinearLayout
    private lateinit var weatherText: TextView
    private lateinit var inputsBar: LinearLayout
    private lateinit var iconsBar: LinearLayout
    private lateinit var favRow: LinearLayout

    private lateinit var panel: FrameLayout
    private lateinit var panelTitle: TextView
    private lateinit var panelGrid: LinearLayout
    private var panelMode = 0
    private var focusBeforePanel: View? = null

    private var apps: List<AppEntry> = emptyList()
    private var appsSignature = ""
    private var inputsSignature = ""
    private val favorites = mutableListOf<String>()
    private var perRow = 5

    private var movingPkg: String? = null
    private var moveStartedAt = 0L
    private var suppressFocus = false
    private var afterPermission: (() -> Unit)? = null

    private var wpToken = 0
    private var lastWeatherAt = 0L

    private val handler = Handler(Looper.getMainLooper())
    private val slideRunnable = object : Runnable {
        override fun run() {
            nextSlide()
            handler.postDelayed(this, SLIDE_MS)
        }
    }
    private val weatherRunnable = object : Runnable {
        override fun run() {
            updateWeather()
            handler.postDelayed(this, WEATHER_MS)
        }
    }

    // ================= жизненный цикл =================

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)
        buildLayout()
        loadFavorites()
        buildIconsBar()
        applyWallpaper()
    }

    override fun onResume() {
        super.onResume()
        refresh()
        handler.removeCallbacks(slideRunnable)
        if (slideMode() != "off") handler.postDelayed(slideRunnable, SLIDE_MS)
        handler.removeCallbacks(weatherRunnable)
        if (System.currentTimeMillis() - lastWeatherAt > WEATHER_MS) updateWeather()
        handler.postDelayed(weatherRunnable, WEATHER_MS)
    }

    override fun onPause() {
        super.onPause()
        if (movingPkg != null) finishMove()
        handler.removeCallbacks(slideRunnable)
        handler.removeCallbacks(weatherRunnable)
    }

    // ================= разметка =================

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun shadow(tv: TextView, r: Float = 8f) = tv.setShadowLayer(r, 0f, 2f, 0x99000000.toInt())

    private fun glassBg(radiusDp: Int, oval: Boolean = false) = GradientDrawable().apply {
        if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(radiusDp).toFloat()
        setColor(0x33FFFFFF)
        setStroke(dp(1), 0x40FFFFFF)
    }

    private fun buildLayout() {
        val root = FrameLayout(this)

        wallpaperView = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(wallpaperView, FrameLayout.LayoutParams(MATCH, MATCH))

        val dim = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x55000000, 0x11000000, 0x22000000, 0xAA000000.toInt())
            )
        }
        root.addView(dim, FrameLayout.LayoutParams(MATCH, MATCH))

        scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            isFillViewport = true
            clipChildren = false
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            setPadding(dp(48), dp(20), dp(48), dp(32))
        }
        scroll.addView(content, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))

        // Панель «все приложения» (поверх экрана)
        panel = FrameLayout(this).apply {
            setBackgroundColor(0xE60C0E16.toInt())
            visibility = View.GONE
            isClickable = true
        }
        val pv = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(48), dp(32), dp(48), dp(24))
            clipChildren = false
            clipToPadding = false
        }
        panelTitle = TextView(this).apply {
            textSize = 24f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        val panelHint = TextView(this).apply {
            textSize = 14f
            setTextColor(0xAAFFFFFF.toInt())
            text = "OK — выбрать, «Назад» — закрыть"
        }
        val panelScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            clipChildren = false
        }
        panelGrid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            setPadding(0, dp(8), 0, dp(24))
        }
        panelScroll.addView(panelGrid, FrameLayout.LayoutParams(MATCH, WRAP))
        pv.addView(panelTitle)
        pv.addView(panelHint)
        pv.addView(panelScroll, LinearLayout.LayoutParams(MATCH, MATCH))
        panel.addView(pv, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(panel, FrameLayout.LayoutParams(MATCH, MATCH))

        overlay = FocusOverlay(this)
        root.addView(overlay, FrameLayout.LayoutParams(MATCH, MATCH))

        setContentView(root)

        root.viewTreeObserver.addOnScrollChangedListener { overlay.update() }
        root.viewTreeObserver.addOnGlobalLayoutListener { overlay.update() }
        root.viewTreeObserver.addOnGlobalFocusChangeListener { _, newFocus ->
            if (newFocus != null && newFocus.parent === favRow) scroll.smoothScrollTo(0, 0)
        }

        // ---- Верхняя полоса: входы слева, мелкие значки справа ----
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
            clipChildren = false
            clipToPadding = false
        }
        inputsBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            clipToPadding = false
        }
        iconsBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            clipToPadding = false
        }
        topBar.addView(inputsBar, LinearLayout.LayoutParams(WRAP, WRAP))
        topBar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        topBar.addView(iconsBar, LinearLayout.LayoutParams(WRAP, WRAP))
        content.addView(topBar, LinearLayout.LayoutParams(MATCH, WRAP))

        // ---- Часы, дата и погода по центру ----
        val shelf = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val time = TextClock(this).apply {
            format24Hour = "HH:mm"
            format12Hour = "HH:mm"
            textSize = 88f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
            includeFontPadding = false
        }
        shadow(time, 12f)
        val date = TextClock(this).apply {
            format24Hour = "EEEE, d MMMM"
            format12Hour = "EEEE, d MMMM"
            textSize = 20f
            setTextColor(0xEEFFFFFF.toInt())
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        shadow(date)
        weatherText = TextView(this).apply {
            textSize = 22f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            gravity = Gravity.CENTER
            visibility = View.INVISIBLE
        }
        shadow(weatherText)
        shelf.addView(time)
        shelf.addView(date, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(2) })
        shelf.addView(weatherText, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(10) })
        val shelfHeight = (resources.displayMetrics.heightPixels * 0.46f).toInt()
        content.addView(shelf, LinearLayout.LayoutParams(MATCH, shelfHeight))

        // ---- Избранное ----
        content.addView(TextView(this).apply {
            text = "Избранное"
            textSize = 15f
            setTextColor(0xBBFFFFFF.toInt())
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding(dp(8), dp(14), 0, 0)
            shadow(this, 6f)
        })
        val hsv = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
            setPadding(dp(8), dp(14), dp(8), dp(4))
        }
        favRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
            clipToPadding = false
        }
        hsv.addView(favRow, FrameLayout.LayoutParams(WRAP, WRAP))
        content.addView(hsv, LinearLayout.LayoutParams(MATCH, WRAP))

        val avail = resources.displayMetrics.widthPixels - dp(96) - dp(16)
        perRow = maxOf(3, avail / (dp(GRID_W) + dp(GAP)))
    }

    private fun tileLp(gapDp: Int = GAP) = LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = dp(gapDp) }

    private fun cardOf(tile: View): View = (tile as ViewGroup).getChildAt(0)

    private fun cornerOf(tile: View): Float = (tile.getTag(R.id.tag_corner) as? Float) ?: dp(10).toFloat()

    private fun focusEffects(tile: LinearLayout, card: View, label: View?, corner: Float, scale: Float) {
        tile.setTag(R.id.tag_corner, corner)
        tile.setOnFocusChangeListener { _, has ->
            val s = if (has) scale else 1f
            card.animate().scaleX(s).scaleY(s).setDuration(180).start()
            card.elevation = if (has) dp(14).toFloat() else 0f
            label?.animate()?.alpha(if (has) 1f else 0f)?.setDuration(180)?.start()
            if (has && !suppressFocus) {
                overlay.targetScale = scale
                overlay.moveTo(card, corner)
            }
        }
    }

    /** Большая плитка приложения */
    private fun makeTile(
        wDp: Int,
        hDp: Int,
        title: String,
        image: Drawable?,
        isBanner: Boolean,
        fallbackText: String?,
        onClick: () -> Unit,
        onLong: (() -> Unit)?
    ): LinearLayout {
        val w = dp(wDp)
        val h = dp(hDp)
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            isFocusable = true
            clipChildren = false
            clipToPadding = false
        }
        val card = FrameLayout(this).apply {
            background = glassBg(10)
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
        }
        if (image != null) {
            val iv = ImageView(this).apply {
                setImageDrawable(image)
                scaleType = if (isBanner) ImageView.ScaleType.FIT_XY else ImageView.ScaleType.FIT_CENTER
            }
            val lp = if (isBanner) FrameLayout.LayoutParams(MATCH, MATCH)
            else FrameLayout.LayoutParams(h * 5 / 10, h * 5 / 10, Gravity.CENTER)
            card.addView(iv, lp)
        } else {
            card.addView(TextView(this).apply {
                text = fallbackText ?: title
                gravity = Gravity.CENTER
                textSize = 16f
                setTextColor(Color.WHITE)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                maxLines = 3
                ellipsize = TextUtils.TruncateAt.END
                setPadding(dp(8), 0, dp(8), 0)
            }, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        tile.addView(card, LinearLayout.LayoutParams(w, h))

        val label = TextView(this).apply {
            text = title
            textSize = 13f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            alpha = 0f
        }
        shadow(label, 6f)
        tile.addView(label, LinearLayout.LayoutParams(w, WRAP).apply { topMargin = dp(10) })

        focusEffects(tile, card, label, dp(10).toFloat(), 1.12f)
        tile.setOnClickListener { onClick() }
        if (onLong != null) tile.setOnLongClickListener { onLong(); true }
        return tile
    }

    /** Маленькая «таблетка» входа: значок + подпись */
    private fun makeChip(iconRes: Int, text: String, onClick: () -> Unit): LinearLayout {
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isFocusable = true
            clipChildren = false
            clipToPadding = false
            setPadding(0, dp(4), 0, dp(4))
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = glassBg(18)
            setPadding(dp(12), 0, dp(14), 0)
        }
        card.addView(ImageView(this).apply { setImageResource(iconRes) }, LinearLayout.LayoutParams(dp(18), dp(18)))
        card.addView(TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(Color.WHITE)
            maxLines = 1
        }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(8) })
        tile.addView(card, LinearLayout.LayoutParams(WRAP, dp(36)))
        focusEffects(tile, card, null, dp(18).toFloat(), 1.1f)
        tile.setOnClickListener { onClick() }
        return tile
    }

    /** Маленький круглый значок в углу */
    private fun makeIcon(iconRes: Int, title: String, onClick: () -> Unit): LinearLayout {
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            isFocusable = true
            clipChildren = false
            clipToPadding = false
            setPadding(0, dp(4), 0, 0)
        }
        val card = FrameLayout(this).apply {
            background = glassBg(0, oval = true)
            outlineProvider = ViewOutlineProvider.BACKGROUND
            clipToOutline = true
        }
        card.addView(ImageView(this).apply { setImageResource(iconRes) },
            FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        tile.addView(card, LinearLayout.LayoutParams(dp(36), dp(36)))
        val label = TextView(this).apply {
            text = title
            textSize = 11f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            maxLines = 1
            alpha = 0f
        }
        shadow(label, 6f)
        tile.addView(label, LinearLayout.LayoutParams(dp(72), WRAP).apply { topMargin = dp(6) })
        focusEffects(tile, card, label, dp(18).toFloat(), 1.15f)
        tile.setOnClickListener { onClick() }
        return tile
    }

    private fun buildIconsBar() {
        iconsBar.removeAllViews()
        val lp = { LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = dp(-14) } }
        iconsBar.addView(makeIcon(R.drawable.ic_apps, "Приложения") { openPanel(PANEL_LAUNCH) }, lp())
        iconsBar.addView(makeIcon(R.drawable.ic_wifi, "Wi‑Fi") { openWifi() }, lp())
        iconsBar.addView(makeIcon(R.drawable.ic_wallpaper, "Обои") { showWallpaperMenu() }, lp())
        iconsBar.addView(makeIcon(R.drawable.ic_weather, "Погода") { showWeatherMenu() }, lp())
        iconsBar.addView(makeIcon(R.drawable.ic_settings, "Настройки") { safeStart(Intent(Settings.ACTION_SETTINGS)) }, lp())
    }

    private fun appTile(app: AppEntry, wDp: Int, hDp: Int, onClick: () -> Unit, onLong: (() -> Unit)?): LinearLayout {
        val t = makeTile(wDp, hDp, app.label, app.banner ?: app.icon, app.banner != null, app.label, onClick, onLong)
        t.tag = app.pkg
        return t
    }

    // ================= данные =================

    private fun installedSet(): Set<String> = apps.mapTo(HashSet()) { it.pkg }

    private fun visibleFavs(): List<String> {
        val inst = installedSet()
        return favorites.filter { it in inst }
    }

    private fun refresh() {
        val newApps = loadApps()
        val sig = newApps.joinToString(",") { it.pkg + "/" + it.label }
        if (sig != appsSignature) {
            appsSignature = sig
            apps = newApps
            if (!prefs.contains("favs")) {
                val inst = installedSet()
                favorites.clear()
                favorites.addAll(DEFAULT_FAVS.filter { it in inst })
                for (a in apps) {
                    if (favorites.size >= 6) break
                    if (a.banner != null && a.pkg !in favorites) favorites.add(a.pkg)
                }
                saveFavorites()
            }
            rebuildFavorites()
            if (panel.visibility == View.VISIBLE) fillPanel()
        }

        val inputs = loadInputs()
        val isig = inputs.joinToString(",") { it.id + it.label + it.device }
        if (isig != inputsSignature || inputsBar.childCount == 0) {
            inputsSignature = isig
            rebuildInputs(inputs)
        }

        if (currentFocus == null) focusFirst()
    }

    private fun loadApps(): List<AppEntry> {
        val pm = packageManager
        val result = LinkedHashMap<String, AppEntry>()
        val lb = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val normal = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val infos = try {
            pm.queryIntentActivities(lb, 0) + pm.queryIntentActivities(normal, 0)
        } catch (e: Exception) {
            emptyList()
        }
        for (ri in infos) {
            val ai = ri.activityInfo ?: continue
            val pkg = ai.packageName
            if (pkg == packageName || result.containsKey(pkg)) continue
            val label = try { ri.loadLabel(pm).toString() } catch (e: Exception) { pkg }
            val banner = try { ai.loadBanner(pm) } catch (e: Exception) { null }
            val icon = try { ri.loadIcon(pm) } catch (e: Exception) { null }
            val launch = Intent(Intent.ACTION_MAIN)
                .setClassName(pkg, ai.name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            result[pkg] = AppEntry(pkg, label, banner, icon, launch)
        }
        val collator = Collator.getInstance(Locale.getDefault())
        return result.values.sortedWith { a, b -> collator.compare(a.label, b.label) }
    }

    private fun loadInputs(): List<InputEntry> {
        val service: Any? = try {
            getSystemService(Context.TV_INPUT_SERVICE)
        } catch (e: Exception) {
            null
        }
        val tim = service as? TvInputManager ?: return emptyList()
        val all = try { tim.tvInputList } catch (e: Exception) { return emptyList() }
        val hdmi = all.filter { it.type == TvInputInfo.TYPE_HDMI }
        val parents = hdmi.filter { it.parentId == null }.ifEmpty { hdmi }
        return parents
            .filter { !(try { it.isHidden(this) } catch (e: Exception) { false }) }
            .map { p ->
                val child = hdmi.firstOrNull { it.parentId == p.id }
                InputEntry(p.id, inputLabel(p), child?.let { inputLabel(it) })
            }
            .sortedBy { it.label }
    }

    private fun inputLabel(info: TvInputInfo): String {
        val custom = try { info.loadCustomLabel(this) } catch (e: Exception) { null }
        val base = try { info.loadLabel(this) } catch (e: Exception) { null }
        return (custom ?: base)?.toString() ?: "HDMI"
    }

    // ================= ряды =================

    private fun rebuildFavorites() {
        favRow.removeAllViews()
        val byPkg = apps.associateBy { it.pkg }
        for (app in favorites.mapNotNull { byPkg[it] }) {
            favRow.addView(appTile(app, FAV_W, FAV_H, { launchApp(app) }, { showFavMenu(app) }), tileLp())
        }
        // плитка «+» в конце — добавить приложение
        val plus = makeTile(
            FAV_W, FAV_H, "Добавить", getDrawable(R.drawable.ic_plus), false, null,
            { openPanel(PANEL_ADD) }, null
        )
        favRow.addView(plus, tileLp())
    }

    private fun rebuildInputs(inputs: List<InputEntry>) {
        inputsBar.removeAllViews()
        for (inp in inputs) {
            val text = inp.device ?: inp.label
            inputsBar.addView(makeChip(R.drawable.ic_input, text) { switchInput(inp) }, tileLp(10))
        }
    }

    private fun focusTag(container: ViewGroup, pkg: String) {
        suppressFocus = false
        val v = container.findViewWithTag<View>(pkg) ?: return
        if (v.isFocused) overlay.moveTo(cardOf(v), cornerOf(v)) else v.requestFocus()
    }

    private fun focusFirst() {
        favRow.getChildAt(0)?.requestFocus()
    }

    private fun goTop() {
        scroll.smoothScrollTo(0, 0)
        focusFirst()
    }

    // ================= панель приложений =================

    private fun openPanel(mode: Int) {
        if (panel.visibility != View.VISIBLE) focusBeforePanel = currentFocus
        panelMode = mode
        content.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        panel.visibility = View.VISIBLE
        panel.alpha = 0f
        panel.animate().alpha(1f).setDuration(180).start()
        fillPanel()
    }

    private fun fillPanel() {
        panelTitle.text = if (panelMode == PANEL_ADD) "Добавить в избранное" else "Все приложения"
        panelGrid.removeAllViews()
        val fav = favorites.toHashSet()
        val list = if (panelMode == PANEL_ADD) apps.filter { it.pkg !in fav } else apps
        if (list.isEmpty()) {
            panelGrid.addView(TextView(this).apply {
                text = "Все приложения уже в избранном"
                textSize = 16f
                setTextColor(0xCCFFFFFF.toInt())
                setPadding(0, dp(24), 0, 0)
            })
            overlay.hide()
            return
        }
        for (chunk in list.chunked(perRow)) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                clipChildren = false
                clipToPadding = false
                setPadding(dp(8), dp(14), dp(8), dp(2))
            }
            for (app in chunk) {
                row.addView(appTile(app, GRID_W, GRID_H, { panelClick(app) }, { panelLong(app) }), tileLp())
            }
            panelGrid.addView(row)
        }
        (panelGrid.getChildAt(0) as? ViewGroup)?.getChildAt(0)?.requestFocus()
    }

    private fun panelClick(app: AppEntry) {
        if (panelMode == PANEL_ADD) addToFavorites(app.pkg) else launchApp(app)
    }

    private fun panelLong(app: AppEntry) {
        val isFav = app.pkg in favorites
        val items = mutableListOf<Pair<String, () -> Unit>>()
        items += "Открыть" to { launchApp(app) }
        if (!isFav) items += "Добавить в избранное" to { addToFavorites(app.pkg) }
        items += "О приложении" to { openAppInfo(app) }
        dialog()
            .setTitle(app.label)
            .setItems(items.map { it.first }.toTypedArray()) { _, which -> items[which].second() }
            .show()
    }

    private fun closePanel(restoreFocus: Boolean = true) {
        panel.visibility = View.GONE
        panelGrid.removeAllViews()
        content.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        if (restoreFocus) {
            val back = focusBeforePanel
            if (back != null && back.isAttachedToWindow) back.requestFocus() else focusFirst()
        }
        focusBeforePanel = null
    }

    private fun addToFavorites(pkg: String) {
        if (pkg !in favorites) favorites.add(pkg)
        saveFavorites()
        closePanel(false)
        suppressFocus = true
        rebuildFavorites()
        focusTag(favRow, pkg)
        toast("Добавлено в избранное")
    }

    // ================= действия =================

    private fun launchApp(app: AppEntry) {
        if (!safeStart(app.launch)) {
            packageManager.getLeanbackLaunchIntentForPackage(app.pkg)
                ?.let { safeStart(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        }
    }

    private fun openAppInfo(app: AppEntry) {
        safeStart(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    private fun openWifi() {
        val tries = listOf(Settings.ACTION_WIFI_SETTINGS, Settings.ACTION_WIRELESS_SETTINGS, Settings.ACTION_SETTINGS)
        for (a in tries) {
            if (safeStart(Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), false)) return
        }
        toast("Не удалось открыть настройки Wi‑Fi")
    }

    private fun switchInput(inp: InputEntry) {
        val uri = TvContract.buildChannelUriForPassthroughInput(inp.id)
        val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (!safeStart(intent, false)) toast("Не удалось переключиться на ${inp.label}")
    }

    private fun safeStart(intent: Intent, showError: Boolean = true): Boolean = try {
        startActivity(intent)
        true
    } catch (e: Exception) {
        if (showError) toast("Не удалось открыть")
        false
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun dialog() = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    /** Панель при долгом нажатии на приложение в избранном (как в стоковом лаунчере Sony) */
    private fun showFavMenu(app: AppEntry) {
        val items = mutableListOf<Pair<String, () -> Unit>>()
        items += "Открыть" to { launchApp(app) }
        items += "Переместить" to { startMove(app.pkg) }
        items += "Убрать из избранного" to {
            val idx = visibleFavs().indexOf(app.pkg)
            favorites.remove(app.pkg)
            saveFavorites()
            suppressFocus = true
            rebuildFavorites()
            suppressFocus = false
            val n = favRow.childCount
            favRow.getChildAt(minOf(maxOf(idx, 0), n - 1))?.requestFocus()
            Unit
        }
        items += "Добавить приложение…" to { openPanel(PANEL_ADD) }
        items += "Все приложения" to { openPanel(PANEL_LAUNCH) }
        items += "О приложении" to { openAppInfo(app) }
        dialog()
            .setTitle(app.label)
            .setItems(items.map { it.first }.toTypedArray()) { _, which -> items[which].second() }
            .show()
    }

    // ================= перестановка =================

    private fun startMove(pkg: String) {
        movingPkg = pkg
        moveStartedAt = SystemClock.uptimeMillis()
        overlay.frameColor = MOVE_COLOR
        favRow.findViewWithTag<View>(pkg)?.let { if (!it.isFocused) it.requestFocus() }
        toast("◀ ▶ — двигать, OK — готово")
    }

    private fun finishMove() {
        movingPkg = null
        overlay.frameColor = Color.WHITE
        saveFavorites()
    }

    private fun moveInFavorites(pkg: String, dir: Int) {
        val inst = installedSet()
        val visible = favorites.filter { it in inst }.toMutableList()
        val i = visible.indexOf(pkg)
        val j = i + dir
        if (i < 0 || j < 0 || j >= visible.size) return
        visible.removeAt(i)
        visible.add(j, pkg)
        val hidden = favorites.filter { it !in inst }
        favorites.clear()
        favorites.addAll(visible)
        favorites.addAll(hidden)

        val v = favRow.getChildAt(i) ?: return
        suppressFocus = true
        favRow.removeViewAt(i)
        favRow.addView(v, j)
        suppressFocus = false
        v.requestFocus()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        val moving = movingPkg
        if (moving != null) {
            when (code) {
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    if (event.action == KeyEvent.ACTION_DOWN) {
                        moveInFavorites(moving, if (code == KeyEvent.KEYCODE_DPAD_LEFT) -1 else 1)
                    }
                    return true
                }
                KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> return true
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
                KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_BACK -> {
                    if (event.action == KeyEvent.ACTION_UP && event.downTime >= moveStartedAt) finishMove()
                    return true
                }
            }
            return super.dispatchKeyEvent(event)
        }
        if (code == KeyEvent.KEYCODE_BACK) {
            if (event.action == KeyEvent.ACTION_UP) {
                if (panel.visibility == View.VISIBLE) closePanel() else goTop()
            }
            return true
        }
        if (code == KeyEvent.KEYCODE_MENU && event.action == KeyEvent.ACTION_UP) {
            val pkg = currentFocus?.tag as? String
            val app = apps.firstOrNull { it.pkg == pkg }
            if (app != null) {
                if (panel.visibility == View.VISIBLE) panelLong(app) else showFavMenu(app)
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun loadFavorites() {
        favorites.clear()
        prefs.getString("favs", null)?.split("|")?.filter { it.isNotBlank() }?.let { favorites.addAll(it) }
    }

    private fun saveFavorites() {
        prefs.edit().putString("favs", favorites.joinToString("|")).apply()
    }

    // ================= погода =================

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "TvLauncher/3.0")
        try {
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun ipLocation(): Triple<Float, Float, String?>? {
        try {
            val j = JSONObject(httpGet("https://ipwho.is/?lang=ru"))
            if (j.optBoolean("success", false)) {
                return Triple(j.getDouble("latitude").toFloat(), j.getDouble("longitude").toFloat(), j.optString("city", "").ifBlank { null })
            }
        } catch (e: Exception) {
        }
        try {
            val j = JSONObject(httpGet("https://ipapi.co/json/"))
            if (j.has("latitude")) {
                return Triple(j.getDouble("latitude").toFloat(), j.getDouble("longitude").toFloat(), j.optString("city", "").ifBlank { null })
            }
        } catch (e: Exception) {
        }
        return null
    }

    private fun weatherInfo(code: Int, day: Boolean): Pair<String, String> = when (code) {
        0 -> (if (day) "☀" else "☾") to "ясно"
        1 -> (if (day) "🌤" else "☾") to "почти ясно"
        2 -> "⛅" to "переменная облачность"
        3 -> "☁" to "пасмурно"
        45, 48 -> "🌫" to "туман"
        51, 53, 55, 56, 57 -> "🌦" to "морось"
        61, 63, 65, 66, 67 -> "🌧" to "дождь"
        71, 73, 75, 77 -> "❄" to "снег"
        80, 81, 82 -> "🌧" to "ливень"
        85, 86 -> "🌨" to "снегопад"
        95, 96, 99 -> "⛈" to "гроза"
        else -> "☁" to ""
    }

    private fun updateWeather() {
        lastWeatherAt = System.currentTimeMillis()
        Thread {
            try {
                var lat = prefs.getFloat("w_lat", Float.NaN)
                var lon = prefs.getFloat("w_lon", Float.NaN)
                var city = prefs.getString("w_city", null)
                if (prefs.getBoolean("w_auto", true) || lat.isNaN()) {
                    val loc = ipLocation()
                    if (loc != null) {
                        lat = loc.first
                        lon = loc.second
                        city = loc.third
                        prefs.edit().putFloat("w_lat", lat).putFloat("w_lon", lon).putString("w_city", city).apply()
                    }
                }
                if (lat.isNaN() || lon.isNaN()) throw IllegalStateException("no location")
                val j = JSONObject(
                    httpGet(
                        "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                            "&current=temperature_2m,weather_code,is_day&timezone=auto"
                    )
                )
                val cur = j.getJSONObject("current")
                val t = cur.getDouble("temperature_2m").roundToInt()
                val (icon, desc) = weatherInfo(cur.getInt("weather_code"), cur.optInt("is_day", 1) == 1)
                val temp = if (t > 0) "+$t°" else "$t°"
                val place = if (city.isNullOrBlank()) "" else "   $city"
                val tail = if (desc.isBlank()) "" else " · $desc"
                val text = "$icon  $temp$place$tail"
                runOnUiThread {
                    weatherText.text = text
                    weatherText.visibility = View.VISIBLE
                }
            } catch (e: Exception) {
                // повторим через 5 минут
                lastWeatherAt = System.currentTimeMillis() - WEATHER_MS + 5 * 60 * 1000L
                handler.removeCallbacks(weatherRunnable)
                handler.postDelayed(weatherRunnable, 5 * 60 * 1000L)
            }
        }.start()
    }

    private fun showWeatherMenu() {
        val auto = prefs.getBoolean("w_auto", true)
        val city = prefs.getString("w_city", null)
        val items = arrayOf(
            (if (auto) "✓ " else "") + "Определять город автоматически",
            (if (!auto && city != null) "✓ $city — изменить город…" else "Указать город вручную…"),
            "Обновить сейчас"
        )
        dialog()
            .setTitle("Погода")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        prefs.edit().putBoolean("w_auto", true).apply()
                        updateWeather()
                    }
                    1 -> askCity()
                    else -> updateWeather()
                }
            }
            .show()
    }

    private fun askCity() {
        val input = EditText(this).apply {
            hint = "Например: Москва"
            setSingleLine()
            setText(prefs.getString("w_city", ""))
        }
        val box = FrameLayout(this).apply { setPadding(dp(24), dp(8), dp(24), 0) }
        box.addView(input)
        dialog()
            .setTitle("Город для погоды")
            .setView(box)
            .setPositiveButton("Сохранить") { _, _ -> geocode(input.text.toString().trim()) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun geocode(name: String) {
        if (name.isBlank()) return
        Thread {
            try {
                val q = URLEncoder.encode(name, "UTF-8")
                val j = JSONObject(httpGet("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1&language=ru"))
                val r = j.optJSONArray("results")?.optJSONObject(0)
                if (r == null) {
                    runOnUiThread { toast("Город «$name» не найден") }
                } else {
                    prefs.edit()
                        .putBoolean("w_auto", false)
                        .putFloat("w_lat", r.getDouble("latitude").toFloat())
                        .putFloat("w_lon", r.getDouble("longitude").toFloat())
                        .putString("w_city", r.optString("name", name))
                        .apply()
                    runOnUiThread { updateWeather() }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Нет связи с сервером погоды") }
            }
        }.start()
    }

    // ================= обои =================

    private fun slideMode(): String = prefs.getString("slide", "off") ?: "off"

    private fun applyWallpaper() {
        if (slideMode() != "off") {
            nextSlide()
            return
        }
        val wp = prefs.getString("wp", DEFAULT_WP) ?: DEFAULT_WP
        when {
            wp.startsWith("file:") -> loadFileWallpaper(File(wp.removePrefix("file:")))
            wp.startsWith("builtin:") -> loadBuiltin(wp.removePrefix("builtin:").toIntOrNull() ?: 9)
            else -> loadBuiltin(9)
        }
    }

    private fun showBitmap(bmp: Bitmap, token: Int) {
        if (token != wpToken) return
        val nd = BitmapDrawable(resources, bmp)
        val old = wallpaperView.drawable
        if (old == null) {
            wallpaperView.setImageDrawable(nd)
            return
        }
        val prev = if (old is TransitionDrawable) old.getDrawable(1) else old
        val td = TransitionDrawable(arrayOf(prev, nd))
        td.isCrossFadeEnabled = true
        wallpaperView.setImageDrawable(td)
        td.startTransition(450)
    }

    private fun loadBuiltin(index: Int) {
        val item = Wallpapers.items.getOrNull(index) ?: Wallpapers.items[0]
        val token = ++wpToken
        Thread {
            val bmp = try {
                BitmapFactory.decodeResource(resources, item.res, BitmapFactory.Options().apply {
                    inPreferredConfig = Bitmap.Config.RGB_565
                })
            } catch (t: Throwable) {
                null
            }
            if (bmp != null) runOnUiThread { showBitmap(bmp, token) }
        }.start()
    }

    private fun loadFileWallpaper(file: File) {
        val token = ++wpToken
        Thread {
            val bmp = decodeScaled(file)
            runOnUiThread {
                if (bmp != null) showBitmap(bmp, token) else loadBuiltin(9)
            }
        }.start()
    }

    private fun decodeScaled(file: File): Bitmap? = try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            null
        } else {
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 1920 && bounds.outHeight / (sample * 2) >= 1080) sample *= 2
            BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.RGB_565
            })
        }
    } catch (t: Throwable) {
        null
    }

    private fun nextSlide() {
        if (slideMode() == "files") {
            Thread {
                val files = scanImages()
                if (files.isEmpty()) {
                    runOnUiThread { loadBuiltin(9) }
                } else {
                    val i = (prefs.getInt("slide_f", -1) + 1) % files.size
                    prefs.edit().putInt("slide_f", i).apply()
                    runOnUiThread { loadFileWallpaper(files[i]) }
                }
            }.start()
        } else {
            val n = Wallpapers.items.size
            val i = (prefs.getInt("slide_b", -1) + 1) % n
            prefs.edit().putInt("slide_b", i).apply()
            loadBuiltin(i)
        }
    }

    private fun scanImages(): List<File> {
        val out = LinkedHashSet<File>()
        fun scan(dir: File, depth: Int) {
            if (out.size >= 300) return
            val list = try { dir.listFiles() } catch (e: Exception) { null } ?: return
            for (f in list.sortedBy { it.name.lowercase() }) {
                if (out.size >= 300) return
                if (f.isFile && f.extension.lowercase() in IMG_EXT) out += f
                else if (f.isDirectory && depth > 0 && !f.name.startsWith(".")) scan(f, depth - 1)
            }
        }
        val ext = Environment.getExternalStorageDirectory()
        scan(File(ext, "Wallpapers"), 1)
        scan(File(ext, "Pictures"), 2)
        scan(File(ext, "Download"), 1)
        scan(File(ext, "DCIM"), 2)
        scan(ext, 0)
        val usb = try { File("/storage").listFiles() } catch (e: Exception) { null }
        usb?.filter { it.isDirectory && it.name != "emulated" && it.name != "self" }?.forEach {
            scan(File(it, "Wallpapers"), 1)
            scan(File(it, "Pictures"), 2)
            scan(it, 0)
        }
        return out.toList()
    }

    private fun setSlide(mode: String) {
        prefs.edit().putString("slide", mode).apply()
        handler.removeCallbacks(slideRunnable)
        if (mode != "off") {
            nextSlide()
            handler.postDelayed(slideRunnable, SLIDE_MS)
            toast("Слайд-шоу включено: смена каждые 15 минут")
        } else {
            applyWallpaper()
            toast("Слайд-шоу выключено")
        }
    }

    private fun showWallpaperMenu() {
        val cats = Wallpapers.categories
        val mode = slideMode()
        val actions = mutableListOf<Pair<String, () -> Unit>>()
        for (c in cats) {
            val n = Wallpapers.items.count { it.category == c }
            actions += "$c ($n)" to { showCategoryPicker(c) }
        }
        actions += "Свои картинки (память или флешка)…" to { ensureFileAccess { showImagePicker() } }
        actions += ((if (mode == "builtin") "✓ " else "") + "Слайд-шоу встроенных обоев") to { setSlide("builtin") }
        actions += ((if (mode == "files") "✓ " else "") + "Слайд-шоу своих картинок") to { ensureFileAccess { setSlide("files") } }
        if (mode != "off") actions += "Выключить слайд-шоу" to { setSlide("off") }
        dialog()
            .setTitle("Обои")
            .setItems(actions.map { it.first }.toTypedArray()) { _, which -> actions[which].second() }
            .show()
    }

    private fun showCategoryPicker(category: String) {
        val list = Wallpapers.items.withIndex().filter { it.value.category == category }
        val names = list.map { it.value.name }.toTypedArray()
        var chosen = false
        val dlg = dialog()
            .setTitle("$category — листайте для просмотра")
            .setItems(names) { _, which ->
                chosen = true
                val idx = list[which].index
                prefs.edit().putString("wp", "builtin:$idx").putString("slide", "off").apply()
                handler.removeCallbacks(slideRunnable)
                loadBuiltin(idx)
            }
            .create()
        dlg.setOnDismissListener { if (!chosen) applyWallpaper() }
        dlg.show()
        dlg.window?.let {
            it.setGravity(Gravity.START or Gravity.CENTER_VERTICAL)
            it.setDimAmount(0f)
        }
        dlg.listView?.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                list.getOrNull(position)?.let { loadBuiltin(it.index) }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    private fun showImagePicker() {
        Thread {
            val files = scanImages()
            runOnUiThread {
                if (files.isEmpty()) {
                    dialog()
                        .setTitle("Картинки не найдены")
                        .setMessage(
                            "Положите картинки (jpg, png, webp) в папку Wallpapers, Pictures или Download " +
                                "в памяти телевизора или на флешке — и откройте это меню снова."
                        )
                        .setPositiveButton("OK", null)
                        .show()
                } else {
                    val names = files.map { "${it.parentFile?.name ?: ""}/${it.name}" }
                    dialog()
                        .setTitle("Выберите картинку")
                        .setItems(names.toTypedArray()) { _, which ->
                            val f = files[which]
                            prefs.edit().putString("wp", "file:${f.absolutePath}").putString("slide", "off").apply()
                            handler.removeCallbacks(slideRunnable)
                            loadFileWallpaper(f)
                        }
                        .show()
                }
            }
        }.start()
    }

    private fun ensureFileAccess(action: () -> Unit) {
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE
        if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) {
            action()
        } else {
            afterPermission = action
            requestPermissions(arrayOf(perm), REQ_FILES)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_FILES) return
        val action = afterPermission
        afterPermission = null
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) action?.invoke()
        else toast("Без доступа к файлам доступны только встроенные обои")
    }
}
