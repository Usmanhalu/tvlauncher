package com.home.tvlauncher

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView

/** Экран сработавшего будильника */
class AlarmActivity : Activity() {

    private var player: MediaPlayer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private val stopRunnable = Runnable { finish() }

    private fun dp(v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                "tvlauncher:alarm"
            ).apply { acquire(10 * 60 * 1000L) }
        } catch (e: Exception) {
        }

        val test = intent.getBooleanExtra("test", false)
        if (!test) AlarmScheduler.afterFired(this)
        buildUi(test)
        startSound()
        handler.postDelayed(stopRunnable, if (test) 8000L else 10 * 60 * 1000L)
    }

    private fun button(text: String, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        textSize = 20f
        gravity = Gravity.CENTER
        isFocusable = true
        isClickable = true
        setPadding(dp(28), dp(14), dp(28), dp(14))
        val bg = GradientDrawable().apply {
            cornerRadius = dp(28).toFloat()
            setColor(0x33FFFFFF)
            setStroke(dp(1), 0x55FFFFFF)
        }
        background = bg
        setTextColor(Color.WHITE)
        setOnFocusChangeListener { v, has ->
            bg.setColor(if (has) Color.WHITE else 0x33FFFFFF)
            setTextColor(if (has) 0xFF102030.toInt() else Color.WHITE)
            v.animate().scaleX(if (has) 1.08f else 1f).scaleY(if (has) 1.08f else 1f).setDuration(150).start()
        }
        setOnClickListener { onClick() }
    }

    private fun buildUi(test: Boolean) {
        val root = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF0F2027.toInt(), 0xFF203A43.toInt(), 0xFF2C5364.toInt())
            )
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        col.addView(TextView(this).apply {
            text = if (test) "⏰ Проверка звука" else "⏰ Будильник"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        col.addView(TextClock(this).apply {
            format24Hour = "HH:mm"
            format12Hour = "HH:mm"
            textSize = 130f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
            gravity = Gravity.CENTER
        })
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(24), 0, 0)
        }
        val stop = button("Выключить") { finish() }
        row.addView(stop)
        if (!test) {
            row.addView(button("Отложить на 10 минут") {
                AlarmScheduler.snooze(this, 10)
                finish()
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginStart = dp(24)
            })
        }
        col.addView(row)
        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)
        stop.requestFocus()
    }

    private fun startSound() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            if (am.getStreamVolume(AudioManager.STREAM_MUSIC) < max / 5) {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, max / 4, 0)
            }
        } catch (e: Exception) {
        }
        try {
            val afd = resources.openRawResourceFd(R.raw.alarm)
            player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                isLooping = true
                prepare()
                start()
            }
        } catch (e: Exception) {
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(stopRunnable)
        try {
            player?.stop()
        } catch (e: Exception) {
        }
        player?.release()
        player = null
        wakeLock?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }
}
