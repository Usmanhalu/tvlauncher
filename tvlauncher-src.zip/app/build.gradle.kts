plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.home.tvlauncher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.home.tvlauncher"
        minSdk = 24
        targetSdk = 34
        versionCode = 6
        versionName = "6.0"
    }

    // Постоянный ключ: обновления ставятся поверх без удаления
    signingConfigs {
        getByName("debug") {
            storeFile = file("launcher.keystore")
            storePassword = "android"
            keyAlias = "launcher"
            keyPassword = "android"
        }
    }

    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("debug") }
        getByName("release") { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
