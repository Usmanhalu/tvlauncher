package com.usman.braviaglass;

import android.content.SharedPreferences;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import javax.net.ssl.SSLException;
import org.json.*;

final class Weather {
    static final String DEFAULT_CITY="Махачкала";
    static final long FRESH_MS=30*60*1000L;
    static final class Place {
        final String city,latitude,longitude,zone;
        Place(String city,String latitude,String longitude,String zone){this.city=city;this.latitude=latitude;this.longitude=longitude;this.zone=zone;}
        String cacheKey(){return "weather.v2."+latitude+","+longitude;}
        String requestKey(){return cacheKey()+"."+city;}
    }
    static final Place[] PLACES={
        new Place(DEFAULT_CITY,"42.97782","47.50027","Europe/Moscow"),
        new Place("Узген","40.77","73.30","Asia/Bishkek"),
        new Place("Ош","40.51","72.81","Asia/Bishkek"),
        new Place("Бишкек","42.87","74.59","Asia/Bishkek"),
        new Place("Москва","55.75","37.62","Europe/Moscow")
    };
    static Place place(Store store){
        String city=store.text("city",DEFAULT_CITY).trim();
        for(Place p:PLACES)if(p.city.equalsIgnoreCase(city))return p;
        return new Place(city,store.text("latitude",PLACES[0].latitude),store.text("longitude",PLACES[0].longitude),store.text("weatherZone","auto"));
    }
    static void migrateMakhachkala(Store store){
        if(store.prefs.getBoolean("weather.makhachkala.v101",false))return;
        Place p=PLACES[0];
        store.prefs.edit().putString(store.key("city"),p.city).putString(store.key("latitude"),p.latitude)
            .putString(store.key("longitude"),p.longitude).putString(store.key("weatherZone"),p.zone)
            .putBoolean(store.key("showWeather"),true).putBoolean("weather.makhachkala.v101",true).apply();
    }
    static final class Day {
        final String date;
        final int high,low,code;
        Day(String date,int high,int low,int code){this.date=date;this.high=high;this.low=low;this.code=code;}
    }
    final int temperature,code;
    final long updated;
    final String city,source;
    final List<Day> days;
    Weather(int temperature,int code,long updated,String city,List<Day> days){this(temperature,code,updated,city,days,"Open-Meteo.com");}
    Weather(int temperature,int code,long updated,String city,List<Day> days,String source){
        this.temperature=temperature;this.code=code;this.updated=updated;this.city=city;this.days=days;this.source=source;
    }
    static String description(int code){
        if(code<0)return "Нет данных";
        if(code==0)return "Ясно";
        if(code<=2)return "Малооблачно";
        if(code==3)return "Облачно";
        if(code<=48)return "Туман";
        if(code<=57)return "Морось";
        if(code<=67||(code>=80&&code<=82))return "Дождь";
        if(code<=77||(code>=85&&code<=86))return "Снег";
        if(code>=95&&code<=99)return "Гроза";
        return "Облачно";
    }
    static String degrees(int n){return (n>0?"+":"")+n+"°";}
    static int temperature(JSONObject object,String key)throws JSONException{
        double t=object.getDouble(key);
        if(!Double.isFinite(t)||t< -100||t>70)throw new JSONException("Invalid temperature");
        return (int)Math.round(t);
    }
    static Weather parse(String json,String city,long time)throws JSONException{
        JSONObject root=new JSONObject(json);
        if(root.has("current_condition"))return parseBackup(root,city,time);
        JSONObject current=root.optJSONObject("current");
        boolean legacy=current==null;
        if(legacy)current=root.getJSONObject("current_weather");
        int temp=temperature(current,legacy?"temperature":"temperature_2m");
        int code=current.getInt(legacy?"weathercode":"weather_code");
        ArrayList<Day> days=new ArrayList<>();JSONObject daily=root.optJSONObject("daily");
        if(daily!=null){
            JSONArray dates=daily.optJSONArray("time"),highs=daily.optJSONArray("temperature_2m_max"),lows=daily.optJSONArray("temperature_2m_min"),codes=daily.optJSONArray("weather_code");
            if(dates!=null&&highs!=null&&lows!=null&&codes!=null){
                int length=Math.min(5,Math.min(Math.min(dates.length(),highs.length()),Math.min(lows.length(),codes.length())));
                for(int i=0;i<length;i++)try{
                    if(highs.isNull(i)||lows.isNull(i)||codes.isNull(i))continue;
                    double high=highs.getDouble(i),low=lows.getDouble(i);
                    if(!Double.isFinite(high)||!Double.isFinite(low)||high< -100||high>70||low< -100||low>70)continue;
                    days.add(new Day(dates.getString(i),(int)Math.round(high),(int)Math.round(low),codes.getInt(i)));
                }catch(JSONException ignored){/* An incomplete forecast must not hide current conditions. */}
            }
        }
        return new Weather(temp,code,time,city,days);
    }
    static Weather parseBackup(JSONObject root,String city,long time)throws JSONException{
        JSONObject current=root.getJSONArray("current_condition").getJSONObject(0);
        int temp=temperature(current,"temp_C"),code=backupCode(current.getInt("weatherCode"));
        ArrayList<Day> days=new ArrayList<>();JSONArray values=root.optJSONArray("weather");
        if(values!=null)for(int i=0;i<Math.min(5,values.length());i++)try{
            JSONObject day=values.getJSONObject(i);JSONArray hourly=day.optJSONArray("hourly");
            int dayCode=code;
            if(hourly!=null&&hourly.length()>0)dayCode=backupCode(hourly.getJSONObject(hourly.length()/2).getInt("weatherCode"));
            days.add(new Day(day.getString("date"),temperature(day,"maxtempC"),temperature(day,"mintempC"),dayCode));
        }catch(JSONException ignored){}
        return new Weather(temp,code,time,city,days,"wttr.in");
    }
    static int backupCode(int code){
        switch(code){
            case 113:return 0;
            case 116:return 2;
            case 119:case 122:return 3;
            case 143:case 248:case 260:return 45;
            case 176:case 263:case 266:return 51;
            case 185:case 281:case 284:return 56;
            case 179:case 182:case 227:case 230:case 320:case 323:case 326:case 329:case 332:case 335:case 338:case 368:case 371:return 71;
            case 200:case 386:case 389:case 392:case 395:return 95;
            case 311:case 314:case 317:case 350:case 362:case 365:case 374:case 377:return 66;
            case 293:case 296:case 299:case 302:case 305:case 308:case 353:case 356:case 359:return 61;
            default:return -1;
        }
    }
    static boolean fresh(Weather w,long now){return w!=null&&now>=w.updated&&now-w.updated<FRESH_MS;}
    static Weather cached(Store store){return cached(place(store),store.prefs);}
    static Weather cached(Place place,SharedPreferences prefs){
        try{return parse(prefs.getString(place.cacheKey()+".json",""),place.city,prefs.getLong(place.cacheKey()+".time",0));}
        catch(Exception ignored){return null;}
    }
    interface Transport{String get(String url)throws IOException;}
    private static final Transport NETWORK=Weather::download;
    static Weather fetch(Store store)throws Exception{return fetch(place(store),store.prefs,NETWORK);}
    static Weather fetch(Place place,SharedPreferences prefs)throws Exception{return fetch(place,prefs,NETWORK);}
    static Weather fetch(String city,String lat,String lon,SharedPreferences prefs)throws Exception{return fetch(new Place(city,lat,lon,"auto"),prefs,NETWORK);}
    static Weather fetch(Place place,SharedPreferences prefs,Transport transport)throws Exception{
        double lat=Double.parseDouble(place.latitude.replace(',','.')),lon=Double.parseDouble(place.longitude.replace(',','.'));
        if(!Double.isFinite(lat)||!Double.isFinite(lon)||lat< -90||lat>90||lon< -180||lon>180)throw new IOException("Invalid coordinates");
        String primary=String.format(Locale.US,"https://api.open-meteo.com/v1/forecast?latitude=%.5f&longitude=%.5f&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min,weather_code&forecast_days=5&timezone=%s",lat,lon,URLEncoder.encode(place.zone,"UTF-8"));
        String backup=String.format(Locale.US,"https://wttr.in/%.5f,%.5f?format=j1&lang=ru",lat,lon);
        Exception first=null;
        for(String url:new String[]{primary,backup}){
            try{
                String json=transport.get(url);long now=System.currentTimeMillis();Weather result=parse(json,place.city,now);
                prefs.edit().putString(place.cacheKey()+".json",json).putLong(place.cacheKey()+".time",now).apply();
                return result;
            }catch(Exception error){if(first==null)first=error;else{IOException failure=new IOException("Both weather sources unavailable",first);failure.addSuppressed(error);throw failure;}}
        }
        throw new IOException("Weather unavailable",first);
    }
    static String download(String address)throws IOException{
        HttpURLConnection conn=(HttpURLConnection)new URL(address).openConnection();
        conn.setConnectTimeout(10000);conn.setReadTimeout(12000);conn.setRequestProperty("User-Agent","BraviaGlass/1.0.1 (Android TV personal weather)");conn.setRequestProperty("Accept","application/json");
        try{
            int status=conn.getResponseCode();if(status!=200)throw new IOException("Weather HTTP "+status);
            ByteArrayOutputStream data=new ByteArrayOutputStream();
            try(InputStream in=conn.getInputStream()){
                byte[] buf=new byte[8192];int n;
                while((n=in.read(buf))!=-1){data.write(buf,0,n);if(data.size()>512*1024)throw new IOException("Weather response too large");}
            }
            return new String(data.toByteArray(),StandardCharsets.UTF_8);
        }finally{conn.disconnect();}
    }
    static String errorMessage(Throwable error){
        for(Throwable e=error;e!=null;e=e.getCause())if(e instanceof SSLException)return "Проверьте дату и время телевизора";
        return "Нет связи с погодой. Повторим автоматически";
    }
}
