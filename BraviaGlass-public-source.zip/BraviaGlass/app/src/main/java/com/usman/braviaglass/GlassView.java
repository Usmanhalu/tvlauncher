package com.usman.braviaglass;

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.*;
import android.os.SystemClock;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.DecelerateInterpolator;
import java.text.SimpleDateFormat;
import java.util.*;

/** Native 1920x1080 scene; scales to HD, Full HD and 4K without fixed device pixels. */
@SuppressLint("ViewConstructor") // Constructed only by MainActivity, never inflated from XML.
public final class GlassView extends View {
    enum Screen { HOME, APPS, CONTROL, SETTINGS, WEATHER, SAVER }
    static final int W=1920, H=1080, WHITE=0xfff3f8fb, MUTED=0xffb7c8d4;
    final MainActivity host;
    final Store store;
    final ScenicHome scenic;
    final ColorHome colorHome;
    final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
    final Typeface regular=Typeface.create("sans-serif",Typeface.NORMAL);
    final Typeface medium=Typeface.create("sans-serif-medium",Typeface.NORMAL);
    final Typeface light=Typeface.create("sans-serif-thin",Typeface.NORMAL);
    final ArrayList<Hit> hits=new ArrayList<>();
    List<AppEntry> apps=new ArrayList<>();
    Bitmap wallpaper, blurred;
    Weather weather;
    boolean weatherLoading=false;
    String weatherError="";
    boolean loading=true, moving=false, topFocused=false, clockFocused=false, recentFocused=false, prayerFocused=false;
    int recentIndex=0;
    Screen screen=Screen.HOME;
    int selected=0, topIndex=2, gridIndex=0, controlIndex=0, category=0, settingIndex=0;
    boolean settingsRight=false;
    String moveId="";
    private float scale=1, offsetX=0, offsetY=0, focusProgress=1;
    private long keyDownAt;
    private boolean longFired=false;
    boolean weatherFailed=false;
    private int wakeKey=-1;
    private ValueAnimator animator;
    private final GestureDetector gestures;
    long nowOverride=0;
    private String toast="";
    private long toastUntil=0;
    private static final String[] CATEGORIES={"Вид и сцены","Приложения","Профили","Погода","Главный экран","Заставка","Управление","О приложении","Время намаза"};
    private static final String[] CAT_ICONS={"image","apps","profile","cloud","home","moon","remote","info","moon"};

    static final class Hit {
        final RectF rect;
        final String action;
        final int index;
        Hit(RectF rect,String action,int index){this.rect=rect;this.action=action;this.index=index;}
    }
    GlassView(MainActivity host,Store store) {
        super(host);this.host=host;this.store=store;scenic=new ScenicHome(this);colorHome=new ColorHome(this);
        setFocusable(true);setFocusableInTouchMode(true);setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_YES);
        setContentDescription("Bravia Glass. Влево и вправо — приложения. Вверх — быстрые настройки. Удерживайте OK для меню приложения.");
        gestures=new GestureDetector(host,new GestureDetector.SimpleOnGestureListener(){
            @Override public boolean onDown(android.view.MotionEvent e){return true;}
            @Override public boolean onSingleTapUp(android.view.MotionEvent e){tap(e.getX(),e.getY(),false);return true;}
            @Override public void onLongPress(android.view.MotionEvent e){tap(e.getX(),e.getY(),true);}
            @Override public boolean onScroll(android.view.MotionEvent a,android.view.MotionEvent b,float dx,float dy){
                if (screen==Screen.HOME && Math.abs(dx)>Math.abs(dy) && Math.abs(dx)>25) {navigate(dx>0?KeyEvent.KEYCODE_DPAD_RIGHT:KeyEvent.KEYCODE_DPAD_LEFT);return true;}
                return false;
            }
        });
    }
    void setApps(List<AppEntry> list){apps=new ArrayList<>(list);loading=false;clamp();invalidate();}
    void setWallpaper(Bitmap image,Bitmap blur){wallpaper=image;blurred=blur;invalidate();}
    void setWeather(Weather value,boolean failed){weather=value;weatherFailed=failed;weatherLoading=false;if(!failed)weatherError="";invalidate();}
    void notifyText(String value){toast=value;toastUntil=SystemClock.uptimeMillis()+3500;invalidate();postDelayed(this::invalidate,3600);}
    void refresh(){clamp();invalidate();}
    void clamp(){selected=Math.max(0,Math.min(selected,dockApps().size()+extraDockCount()-1));gridIndex=Math.max(0,Math.min(gridIndex,Math.max(0,visibleApps().size()-1)));}
    List<AppEntry> dockApps(){return store.visible(apps,true);}
    List<AppEntry> visibleApps(){return store.visible(apps,false);}
    void open(Screen value){if(host.travelSaver!=null)host.travelSaver.stop();screen=value;moving=false;clockFocused=false;topFocused=false;recentFocused=false;prayerFocused=false;animateFocus();updateDescription();}
    void home(){host.lastInteraction=SystemClock.elapsedRealtime();if(host.travelSaver!=null)host.travelSaver.stop();screen=Screen.HOME;moving=false;topFocused=false;clockFocused=false;recentFocused=false;prayerFocused=false;clamp();animateFocus();}
    void animateFocus(){
        if(animator!=null)animator.cancel();
        if(!store.bool("animations",true)){focusProgress=1;invalidate();return;}
        animator=ValueAnimator.ofFloat(0,1);animator.setDuration(160);animator.setInterpolator(new DecelerateInterpolator());
        animator.addUpdateListener(v->{focusProgress=(float)v.getAnimatedValue();invalidate();});animator.start();
    }
    long now(){return nowOverride!=0?nowOverride:System.currentTimeMillis();}

    @SuppressLint("DrawAllocation") // Lightweight geometry; images and blur are cached outside drawing.
    @Override protected void onDraw(Canvas canvas){
        super.onDraw(canvas);
        scale=Math.min(getWidth()/(float)W,getHeight()/(float)H);
        offsetX=(getWidth()-W*scale)/2;offsetY=(getHeight()-H*scale)/2;
        canvas.drawColor(0xff142633);canvas.save();canvas.translate(offsetX,offsetY);canvas.scale(scale,scale);
        hits.clear();
        if(screen==Screen.SAVER){drawSaver(canvas);canvas.restore();return;}
        if(ambient())colorHome.background(canvas);else backdrop(canvas,couch()&&scenic.frame!=null?scenic.frame.photo:wallpaper);
        String scene=store.text("scene","forest");
        if(!ambient()&&!couch()&&scene.equals("night")) rect(canvas,0,0,W,H,0x99091b38);
        if(!ambient()&&!couch()&&scene.equals("warm")) rect(canvas,0,0,W,H,0x26d9a662);
        if(store.number("darkness",0)>0)rect(canvas,0,0,W,H,Color.argb(store.number("darkness",0),0,0,0));
        if(screen==Screen.HOME||screen==Screen.CONTROL)drawHome(canvas);
        if(screen==Screen.APPS) drawApps(canvas);
        else if(screen==Screen.CONTROL)drawControl(canvas);
        else if(screen==Screen.SETTINGS)drawSettings(canvas);
        else if(screen==Screen.WEATHER)drawWeather(canvas);
        if(SystemClock.uptimeMillis()<toastUntil){
            float width=Math.min(1400,measure(toast,25)+80);
            glass(canvas,new RectF((W-width)/2,744,(W+width)/2,812),24,0xe61b303e);
            text(canvas,toast,W/2,787,25,WHITE,regular,Paint.Align.CENTER);
        }
        canvas.restore();
    }
    void backdrop(Canvas c,Bitmap bitmap){
        if(bitmap==null){rect(c,0,0,W,H,0xff9fb8c6);return;}
        float imageScale=Math.max(W/(float)bitmap.getWidth(),H/(float)bitmap.getHeight());
        float width=bitmap.getWidth()*imageScale,height=bitmap.getHeight()*imageScale;
        paint.setColor(Color.WHITE);paint.setAlpha(255);paint.setShader(null);
        c.drawBitmap(bitmap,null,new RectF((W-width)/2,(H-height)/2,(W+width)/2,(H+height)/2),paint);
    }
    boolean couch(){return store.text("look","couch").equals("couch");}
    boolean ambient(){return store.text("look","ambient").equals("ambient");}
    int extraDockCount(){return ambient()?0:couch()?2:3;}
    float focusAmount(){return focusProgress;}
    List<AppEntry> recentApps(){
        ArrayList<AppEntry> result=new ArrayList<>();
        for(String id:store.list("recents"))for(AppEntry app:apps)if(id.equals(app.id)&&!store.hidden(id)){result.add(app);break;}
        return result;
    }
    List<WatchCard> shelfCards(){
        ArrayList<WatchCard> result=new ArrayList<>();
        if(store.bool("useWatchNext",true))for(WatchCard card:host.watchCards)if(!store.hidden(card.app.id))result.add(card);
        if(result.isEmpty())for(AppEntry app:recentApps())result.add(WatchCard.recent(app,store.label(app)));
        return result;
    }
    void drawHome(Canvas c){if(ambient())colorHome.draw(c);else if(couch())scenic.draw(c);else drawHomeClassic(c);}
    void drawHomeClassic(Canvas c){
        boolean dark=store.text("scene","forest").equals("night")||store.number("darkness",0)>90||store.bool("lightText",false);
        int ink=dark?WHITE:0xff344a55;
        float clockScale=store.number("clockSize",100)/100f;
        Calendar date=Calendar.getInstance();date.setTimeInMillis(now());int hour=date.get(Calendar.HOUR_OF_DAY);
        String greet=hour>=5&&hour<12?"Доброе утро":hour>=12&&hour<18?"Добрый день":hour>=18&&hour<23?"Добрый вечер":"Доброй ночи";
        if(store.bool("showClock",true)) {
            text(c,greet+", "+store.name(),64,92,34,ink,regular);
            String dateText=new SimpleDateFormat("EEEE, d MMMM",new Locale("ru")).format(new Date(now()));
            dateText=dateText.substring(0,1).toUpperCase(new Locale("ru"))+dateText.substring(1);
            text(c,dateText,66,141,27,ink,regular);
            String time=new SimpleDateFormat(store.bool("clock24",true)?"HH:mm":"h:mm",Locale.US).format(new Date(now()));
            text(c,time,52,354*clockScale+12,218*clockScale,ink,light);
            if(clockFocused&&screen==Screen.HOME) round(c,new RectF(50,46,740,396*clockScale),24,0x15ffffff,0x70ffffff,2);
            if(screen==Screen.HOME)hits.add(new Hit(new RectF(45,42,850,400*clockScale),"clock",0));
        }
        if(store.bool("showWeather",true))drawHomeWeather(c,ink,dark);
        String[] top={"wifi","profile","control"};
        for(int i=0;i<3;i++){
            float x=1638+i*84;
            RectF r=new RectF(x,54,x+62,116);
            boolean active=topFocused&&topIndex==i&&screen==Screen.HOME;
            round(c,r,31,active?0xdcf4faff:0x22edf8ff,active?0xffffffff:0x60ffffff,active?3:1.4f);
            icon(c,top[i],r.centerX(),r.centerY(),30,active?0xff294659:ink);
            if(screen==Screen.HOME)hits.add(new Hit(r,"top",i));
        }
        if(showPrayer())drawPrayers(c);
        List<AppEntry> favorites=dockApps();
        int count=favorites.size()+3;
        int capacity=store.number("dockSize",100)>=115?9:12;
        int shown=Math.min(count,capacity),start=Math.max(0,Math.min(selected-shown/2,count-shown));
        float tile=store.number("dockSize",100)>=115?122:108;
        float gap=24;
        float width=shown*(tile+gap)+36;
        float x=(W-width)/2;
        RectF dock=new RectF(x,880,x+width,1038);
        glass(c,dock,36,0x9934484e);
        if(start>0)text(c,"‹",x-32,982,40,WHITE,regular);
        if(start+shown<count)text(c,"›",x+width+26,982,40,WHITE,regular);
        for(int n=0;n<shown;n++){
            int index=start+n;
            float tx=x+30+n*(tile+gap),ty=905+(108-tile)/2;
            RectF r=new RectF(tx,ty,tx+tile,ty+tile);
            boolean focused=index==selected&&!topFocused&&!clockFocused&&!prayerFocused&&screen==Screen.HOME;
            String label=index<favorites.size()?store.label(favorites.get(index)):index==favorites.size()?"Входы телевизора":index==favorites.size()+1?"Настройки":"Все приложения";
            if(focused){
                text(c,moving?"↔  "+label:label,r.centerX(),862,25,WHITE,medium,Paint.Align.CENTER);
                float expansion=4+3*focusProgress;
                RectF ring=new RectF(r);ring.inset(-expansion,-expansion);
                round(c,ring,27,0x45ffffff,moving?0xffb9e7ff:0xffffffff,3);
            }
            if(index<favorites.size())appIcon(c,favorites.get(index),r,focused);
            else {
                round(c,r,22,0x70576d78,0x40ffffff,1);
                icon(c,index==favorites.size()?"input":index==favorites.size()+1?"settings":"more",r.centerX(),r.centerY(),53,WHITE);
            }
            if(screen==Screen.HOME)hits.add(new Hit(new RectF(tx-8,ty-15,tx+tile+8,ty+tile+15),"dock",index));
        }
        if(loading)text(c,"Загрузка приложений…",W/2,842,24,WHITE,regular,Paint.Align.CENTER);
        else if(favorites.isEmpty())text(c,"Откройте «Все приложения» и добавьте любимые на панель",W/2,842,24,WHITE,regular,Paint.Align.CENTER);
    }
    String homeWeatherSummary(){
        String city=Weather.place(store).city;
        if(weather!=null)return city+" · "+Weather.degrees(weather.temperature)+" · "+Weather.description(weather.code);
        return city+" · "+(weatherFailed?"Нет связи с погодой":"Загрузка погоды…");
    }
    boolean showPrayer(){return store.bool("showPrayer",true);}
    boolean prayersAtTop(){return ambient()||store.text("prayerLayout","top_text").equals("top_text");}
    static final float PRAYER_COMPACT_SCALE=.6f;
    RectF compactPrayerBounds(){float width=Math.round(1540*PRAYER_COMPACT_SCALE);float shift=ambient()?210:0;return new RectF((W-width)/2,18+shift,(W+width)/2,110+shift);}
    boolean hasRecents(){return (ambient()||couch())&&store.bool("showRecents",true)&&!shelfCards().isEmpty();}
    void drawPrayers(Canvas c){
        if(prayersAtTop()){drawCompactPrayers(c);return;}
        PrayerTimes.Display value=host.prayers.display(now());
        String date=value==null?PrayerTimes.format("d MMMM").format(new Date(now())):PrayerTimes.format("d MMMM").format(PrayerTimes.parseDate(value.day.date));
        text(c,"Время намаза   ·   Махачкала   ·   "+date+(value!=null&&value.previousNight?" · ночь":""),190,670,25,WHITE,medium);
        text(c,"Sajda",1730,670,23,WHITE,regular,Paint.Align.RIGHT);
        RectF panel=new RectF(190,691,1730,824);glass(c,panel,30,0xb91a242b);
        if(prayerFocused&&screen==Screen.HOME)round(c,panel,30,0x09ffffff,WHITE,3);
        if(value==null){
            text(c,"Обновите расписание Sajda",960,752,32,WHITE,medium,Paint.Align.CENTER);
            text(c,"OK — настройки времени намаза",960,790,22,MUTED,regular,Paint.Align.CENTER);
        }else for(int i=0;i<6;i++){
            float left=200+i*253.3f,center=left+122;
            if(value.active==i)round(c,new RectF(left,701,left+244,814),23,0xff079b75,0,0);
            text(c,PrayerTimes.LABELS[i],center,742,31,i==value.active?WHITE:0xffd5dce1,regular,Paint.Align.CENTER);
            text(c,value.day.times[i],center,794,45,WHITE,medium,Paint.Align.CENTER);
        }
        if(screen==Screen.HOME){
            hits.add(new Hit(panel,"prayer",0));
            if(hasRecents()){
                RectF link=new RectF(1310,626,1578,681);
                text(c,"Недавно ↑",link.centerX(),668,22,WHITE,regular,Paint.Align.CENTER);
                hits.add(new Hit(link,"showRecents",0));
            }
        }
    }
    void drawCompactPrayers(Canvas c){
        PrayerTimes.Display value=host.prayers.display(now());RectF area=compactPrayerBounds();
        float shift=ambient()?210:0;c.save();c.translate(0,shift);
        boolean lightInk=ambient()||couch()||store.text("scene","forest").equals("night")||store.number("darkness",0)>90||store.bool("lightText",false);
        int ink=lightInk?WHITE:0xff344a55;
        String date=PrayerTimes.format("d MMMM").format(value==null?new Date(now()):PrayerTimes.parseDate(value.day.date));
        paint.setShadowLayer(3,0,1,lightInk?0xc0000000:0x90ffffff);
        text(c,"Махачкала · "+date+(value!=null&&value.previousNight?" · ночь":"")+" · Sajda",W/2,32,24*PRAYER_COMPACT_SCALE,ink,regular,Paint.Align.CENTER);
        if(value==null){
            text(c,"Обновите расписание Sajda",W/2,65,30*PRAYER_COMPACT_SCALE,ink,medium,Paint.Align.CENTER);
            text(c,"OK — настройки времени намаза",W/2,93,23*PRAYER_COMPACT_SCALE,ink,regular,Paint.Align.CENTER);
        }else for(int i=0;i<6;i++){
            float center=area.left+area.width()*(i+.5f)/6;
            boolean active=i==value.active;int color=active?0xff00ca89:ink;
            if(active)paint.setShadowLayer(3,0,1,0xc0000000);
            text(c,PrayerTimes.LABELS[i],center,61,31*PRAYER_COMPACT_SCALE,color,regular,Paint.Align.CENTER);
            text(c,value.day.times[i],center,92,45*PRAYER_COMPACT_SCALE,color,medium,Paint.Align.CENTER);
            if(active)paint.setShadowLayer(3,0,1,lightInk?0xc0000000:0x90ffffff);
        }
        paint.clearShadowLayer();c.restore();
        if(screen==Screen.HOME){
            if(prayerFocused)rect(c,area.left+12,105+shift,area.right-12,107+shift,lightInk?0xccffffff:0xcc344a55);
            hits.add(new Hit(area,"prayer",0));
        }
    }
    boolean weatherUnderClock(){return store.text("weatherPosition","under_clock").equals("under_clock");}
    RectF homeWeatherBounds(){
        if(!weatherUnderClock())return new RectF(1320,174,1848,391);
        float top=store.bool("showClock",true)?354*store.number("clockSize",100)/100f+44:174;
        return new RectF(66,top,746,top+164);
    }
    void drawHomeWeather(Canvas c,int ink,boolean dark){
        boolean under=weatherUnderClock(),background=store.bool("weatherBackground",false);
        RectF card=homeWeatherBounds();float x=card.left,y=card.top;
        if(background)glass(c,card,29,dark?0xb3223e51:0x80eef7fa);
        if(clockFocused&&screen==Screen.HOME){
            if(background)round(c,card,29,0x15ffffff,0xe0ffffff,3);
            else rect(c,x,y+card.height()-3,card.right,y+card.height(),0xc0ffffff);
        }
        float labelX=x+(under?0:30),symbolX=x+(under?24:48),tempX=x+(under?58:90),descX=x+(under?260:238);
        if(!background)paint.setShadowLayer(3,0,1,dark?0xb0000000:0x90ffffff);
        text(c,Weather.place(store).city,labelX,y+(under?27:44),under?24:27,ink,medium);
        if(weather!=null){
            icon(c,weather.code==0?"sun":"cloud",symbolX,y+(under?78:103),under?38:43,ink);
            text(c,Weather.degrees(weather.temperature),tempX,y+(under?101:127),under?60:65,ink,light);
            text(c,ellipsize(Weather.description(weather.code),under?410:245,25),descX,y+(under?83:108),25,ink,regular);
            String status=weatherLoading?"Обновление…":weatherFailed?"Сохранённые данные · повторим автоматически":
                "Обновлено "+new SimpleDateFormat("HH:mm",new Locale("ru")).format(new Date(weather.updated));
            if(!weatherLoading&&!weatherFailed&&now()-weather.updated>=Weather.FRESH_MS)status="Сохранено "+new SimpleDateFormat("d MMM, HH:mm",new Locale("ru")).format(new Date(weather.updated));
            text(c,ellipsize(status,under?660:464,20),labelX,y+(under?144:175),20,ink,regular);
        }else{
            icon(c,"cloud",symbolX,y+(under?78:105),under?38:45,ink);
            text(c,"—°",tempX,y+(under?101:126),61,ink,light);
            text(c,weatherFailed?"Нет связи":"Загрузка…",descX,y+(under?83:107),25,ink,regular);
            String status=weatherFailed?(weatherError.isEmpty()?"Повторим автоматически · OK — обновить":weatherError):"Получаем погоду для вашего города";
            text(c,ellipsize(status,under?660:464,20),labelX,y+(under?144:175),20,ink,regular);
        }
        paint.clearShadowLayer();
        if(screen==Screen.HOME)hits.add(new Hit(card,"clock",0));
    }
    void appIcon(Canvas c,AppEntry app,RectF r,boolean focused){
        int color=store.bool("initials."+app.id,false)?0xff315f7b:tileColor(app.id);
        round(c,r,22,color,0x35ffffff,1);
        Bitmap custom=host.customIcon(app.id);
        boolean initials=store.bool("initials."+app.id,false);
        Bitmap image=custom!=null?custom:initials?null:app.icon;
        if(image!=null){
            c.save();Path clip=new Path();clip.addRoundRect(r,22,22,Path.Direction.CW);c.clipPath(clip);
            RectF fit=new RectF(r);fit.inset(custom!=null?0:8,custom!=null?0:8);
            paint.setAlpha(255);paint.setColor(Color.WHITE);paint.setShader(null);
            c.drawBitmap(image,null,fit,paint);c.restore();
        }else{
            String label=store.label(app);String mark=label.length()>3?label.substring(0,Math.min(3,label.length())):label;
            text(c,mark,r.centerX(),r.centerY()+12,Math.min(35,r.width()/3),WHITE,medium,Paint.Align.CENTER);
        }
    }
    static int tileColor(String id){
        String s=id.toLowerCase(Locale.ROOT);
        if(s.contains("youtube")||s.contains("netflix"))return 0xfff7f9fa;
        if(Store.matchesPriority(s,"ivi"))return 0xffd41273;
        if(s.contains("amazon"))return 0xff087cdb;
        if(s.contains("apple"))return 0xff13191d;
        if(s.contains("file"))return 0xffba842d;
        int[] colors={0xff166fa4,0xff2d6681,0xff484c70,0xff1e7c81,0xff526175,0xff33434b};
        return colors[Math.floorMod(id.hashCode(),colors.length)];
    }
    void drawApps(Canvas c){
        rect(c,0,0,W,H,0xd50b1b28);
        text(c,"Все приложения",98,109,46,WHITE,medium);
        text(c,"OK — открыть    ·    Удерживайте OK — меню приложения",100,158,24,MUTED,regular);
        List<AppEntry> list=visibleApps();
        text(c,list.size()+" приложений",1820,112,24,MUTED,regular,Paint.Align.RIGHT);
        if(list.isEmpty())text(c,loading?"Загрузка…":"Нет видимых приложений. Скрытые приложения доступны в настройках.",W/2,540,30,WHITE,regular,Paint.Align.CENTER);
        int cols=8,rows=3,row=gridIndex/cols,start=Math.max(0,row-rows+1)*cols;
        for(int i=start;i<Math.min(list.size(),start+cols*rows);i++){
            int n=i-start,col=n%cols,rr=n/cols;
            float x=110+col*216,y=234+rr*246;
            RectF tile=new RectF(x+28,y,x+164,y+136);
            if(i==gridIndex){RectF ring=new RectF(tile);ring.inset(-9,-9);round(c,ring,30,0x35ffffff,WHITE,3);}
            appIcon(c,list.get(i),tile,i==gridIndex);
            String label=ellipsize(store.label(list.get(i)),190,25);
            text(c,label,x+96,y+181,25,WHITE,regular,Paint.Align.CENTER);
            if(store.favorite(list.get(i).id))text(c,"•",x+96,y+213,24,0xffacdfff,regular,Paint.Align.CENTER);
            hits.add(new Hit(new RectF(x,y-10,x+193,y+216),"grid",i));
        }
        int totalPages=Math.max(1,(list.size()+23)/24);
        text(c,"Назад — главный экран",100,1022,23,MUTED,regular);
        if(totalPages>1)text(c,"↕  "+(row+1)+" / "+Math.max(1,(list.size()+7)/8)+" рядов",1820,1022,23,MUTED,regular,Paint.Align.RIGHT);
    }
    void drawControl(Canvas c){
        rect(c,0,0,W,H,0x3a071522);
        RectF panel=new RectF(1266,138,1858,966);glass(c,panel,40,0xb428414e);
        text(c,"Пункт управления",1310,204,30,WHITE,medium);
        String[] names={"Wi-Fi","Bluetooth","Память","Звук","Таймер заставки","Чёрный экран","Входы ТВ","Настройки"};
        String[] icons={"wifi","bluetooth","memory","sound","timer","moon","input","settings"};
        String[] sub={host.networkLabel(),"Открыть настройки",host.memoryLabel(),"Громкость и выход",host.timerLabel(),"Выход любой кнопкой","HDMI и телевидение","Оформление и система"};
        for(int i=0;i<8;i++){
            float x=1302+(i%2)*268,y=242+(i/2)*153;
            RectF r=new RectF(x,y,x+248,y+132);
            round(c,r,28,i==controlIndex?0xe9eef8fe:0x407a97a9,i==controlIndex?WHITE:0x40ffffff,i==controlIndex?2.5f:1);
            int color=i==controlIndex?0xff25485c:WHITE;
            icon(c,icons[i],x+37,y+34,29,color);
            text(c,names[i],x+22,y+79,23,color,medium);
            text(c,ellipsize(sub[i],216,18),x+22,y+109,18,i==controlIndex?0xff426277:MUTED,regular);
            hits.add(new Hit(r,"control",i));
        }
        text(c,"Назад — закрыть",1562,918,22,MUTED,regular,Paint.Align.CENTER);
    }
    void drawSettings(Canvas c){
        rect(c,0,0,W,H,0xf00b1d2c);
        text(c,"Настройки главного экрана",100,116,41,WHITE,medium);
        text(c,"Bravia Glass",1818,112,25,MUTED,regular,Paint.Align.RIGHT);
        for(int i=0;i<CATEGORIES.length;i++){
            RectF r=new RectF(80,190+i*87,567,263+i*87);
            boolean active=i==category;
            if(active)round(c,r,22,settingsRight?0x344b728b:0xffe8f5fe,0x00000000,0);
            icon(c,CAT_ICONS[i],117,r.centerY(),27,active&&!settingsRight?0xff26465d:MUTED);
            text(c,CATEGORIES[i],154,r.centerY()+9,27,active&&!settingsRight?0xff17394f:WHITE,active?medium:regular);
            hits.add(new Hit(r,"category",i));
        }
        rect(c,613,198,614,951,0x30c2dfef);
        text(c,CATEGORIES[category],675,234,35,WHITE,medium);
        List<MainActivity.SettingRow> rows=host.rows(category);
        settingIndex=Math.max(0,Math.min(settingIndex,Math.max(0,rows.size()-1)));
        int start=Math.max(0,settingIndex-5);
        for(int i=start;i<Math.min(rows.size(),start+6);i++){
            float y=280+(i-start)*102;
            MainActivity.SettingRow row=rows.get(i);RectF r=new RectF(672,y,1814,y+88);
            boolean active=settingsRight&&i==settingIndex;
            round(c,r,21,active?0xffe8f5fe:0x343c6078,active?WHITE:0x20466e87,active?2:1);
            text(c,row.title,700,y+36,26,active?0xff183a50:WHITE,medium);
            text(c,ellipsize(row.detail,1025,21),700,y+66,21,active?0xff406278:MUTED,regular);
            text(c,"›",1775,y+55,35,active?0xff183a50:MUTED,regular);
            hits.add(new Hit(r,"setting",i));
        }
        text(c,"← →  Разделы и параметры    ·    OK  Выбрать    ·    Назад  Главный экран",100,1020,23,MUTED,regular);
        if(rows.size()>6)text(c,(settingIndex+1)+" / "+rows.size(),1814,956,22,MUTED,regular,Paint.Align.RIGHT);
    }
    void drawWeather(Canvas c){
        rect(c,0,0,W,H,0xda102a3b);
        text(c,Weather.place(store).city,104,140,55,WHITE,medium);
        text(c,"Погода",106,188,27,MUTED,regular);
        if(weather==null){
            icon(c,"cloud",960,430,115,MUTED);
            text(c,weatherFailed?"Не удалось обновить погоду":"Обновление погоды…",960,550,36,WHITE,regular,Paint.Align.CENTER);
            if(weatherFailed)text(c,weatherError.isEmpty()?"Проверьте интернет. Повторим автоматически.":weatherError,960,590,25,MUTED,regular,Paint.Align.CENTER);
            text(c,"OK — повторить    ·    Назад — главный экран",960,620,26,MUTED,regular,Paint.Align.CENTER);
        }else{
            text(c,Weather.degrees(weather.temperature),100,448,190,WHITE,light);
            text(c,Weather.description(weather.code),110,513,34,WHITE,regular);
            String age=weatherFailed||now()-weather.updated>=Weather.FRESH_MS?"Сохранённые данные · ":"Обновлено ";
            text(c,age+new SimpleDateFormat("d MMM, HH:mm",new Locale("ru")).format(new Date(weather.updated)),110,563,23,MUTED,regular);
            for(int i=0;i<weather.days.size();i++){
                Weather.Day day=weather.days.get(i);float x=112+i*349;
                RectF r=new RectF(x,636,x+323,895);glass(c,r,27,0x6b44637a);
                String name=day.date;
                try{name=i==0?"Сегодня":new SimpleDateFormat("EEE, d MMM",new Locale("ru")).format(new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(day.date));}catch(Exception ignored){}
                text(c,name,x+26,683,26,WHITE,medium);
                icon(c,day.code==0?"sun":"cloud",x+55,739,47,WHITE);
                text(c,Weather.degrees(day.high)+" / "+Weather.degrees(day.low),x+26,814,33,WHITE,regular);
                text(c,Weather.description(day.code),x+26,862,21,MUTED,regular);
            }
            text(c,"OK — обновить    ·    Меню — выбрать город    ·    Назад — главный экран",110,1000,24,MUTED,regular);
        }
        text(c,"Данные: "+(weather==null?"Open-Meteo / wttr.in":weather.source),1810,1000,22,MUTED,regular,Paint.Align.RIGHT);
        hits.add(new Hit(new RectF(0,0,W,H),"weather",0));
    }
    void drawSaver(Canvas c){
        c.drawColor(Color.BLACK);
        if(!host.blackOnly&&host.travelSaver!=null){
            TravelSaver saver=host.travelSaver;
            // Always retain a photograph while the next one is decoded off the UI thread.
            backdrop(c,saver.current!=null?saver.current:wallpaper);
            float fade=saver.fade();
            if(saver.previous!=null&&fade<1){
                backdrop(c,saver.previous);
                drawSaverPhoto(c,saver.current,Math.round(255*fade));
                postInvalidateOnAnimation();
            }
            paint.setShader(new LinearGradient(0,480,0,H,new int[]{0x00000000,0xc9000000},null,Shader.TileMode.CLAMP));
            paint.setColor(Color.WHITE);c.drawRect(0,0,W,H,paint);paint.setShader(null);
            long step=now()/60000;
            float driftX=(step%3)*12,driftY=(step%2)*12;
            paint.setShadowLayer(8,0,2,0xaa000000);
            text(c,new SimpleDateFormat("HH:mm",Locale.US).format(new Date(now())),1816-driftX,854-driftY,116,WHITE,light,Paint.Align.RIGHT);
            text(c,new SimpleDateFormat("EEEE, d MMMM",new Locale("ru")).format(new Date(now())),1810-driftX,907-driftY,29,WHITE,regular,Paint.Align.RIGHT);
            if(store.bool("saverWeather",true)){
                String line=Weather.place(store).city;
                if(weather!=null){
                    line+=" · "+Weather.degrees(weather.temperature)+" · "+Weather.description(weather.code);
                    if(weatherFailed||now()-weather.updated>=Weather.FRESH_MS)line+=" · сохранено";
                }else line+=weatherFailed?" · погода недоступна":" · загрузка погоды…";
                text(c,ellipsize(line,900,27),1810-driftX,957-driftY,27,WHITE,regular,Paint.Align.RIGHT);
            }
            TravelCatalog.Photo photo=saver.photo;
            text(c,photo==null?"Путешествие по миру":photo.title,90+driftX,927-driftY,38,WHITE,medium);
            text(c,photo==null?"Природа и города":photo.subtitle,92+driftX,967-driftY,25,0xffd8e1e8,regular);
            paint.clearShadowLayer();
        }
        if(SystemClock.uptimeMillis()-host.saverStarted<4500)text(c,"Нажмите OK или Назад для возврата",960,1035,22,0xffc6d0d8,regular,Paint.Align.CENTER);
    }
    void drawSaverPhoto(Canvas c,Bitmap bitmap,int alpha){
        if(bitmap==null)return;
        float fit=Math.max(W/(float)bitmap.getWidth(),H/(float)bitmap.getHeight());
        float w=bitmap.getWidth()*fit,h=bitmap.getHeight()*fit;
        paint.setShader(null);paint.setColor(Color.WHITE);paint.setAlpha(alpha);
        c.drawBitmap(bitmap,null,new RectF((W-w)/2,(H-h)/2,(W+w)/2,(H+h)/2),paint);
        paint.setAlpha(255);
    }
    void glass(Canvas c,RectF r,float radius,int color){
        c.save();Path clip=new Path();clip.addRoundRect(r,radius,radius,Path.Direction.CW);c.clipPath(clip);
        if(!ambient()){if(couch()&&scenic.frame!=null)backdrop(c,scenic.frame.glass);else if(blurred!=null)backdrop(c,blurred);}
        round(c,r,radius,color,0,0);c.restore();
        round(c,r,radius,Color.TRANSPARENT,0x60dfedf4,1.5f);
    }
    void rect(Canvas c,float x,float y,float right,float bottom,int color){paint.setShader(null);paint.setStyle(Paint.Style.FILL);paint.setColor(color);c.drawRect(x,y,right,bottom,paint);}
    void round(Canvas c,RectF r,float radius,int fill,int stroke,float strokeWidth){
        paint.setShader(null);paint.setStyle(Paint.Style.FILL);paint.setColor(fill);c.drawRoundRect(r,radius,radius,paint);
        if(strokeWidth>0){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(strokeWidth);paint.setColor(stroke);c.drawRoundRect(r,radius,radius,paint);paint.setStyle(Paint.Style.FILL);}
    }
    void text(Canvas c,String text,float x,float y,float size,int color,Typeface font){text(c,text,x,y,size,color,font,Paint.Align.LEFT);}
    void text(Canvas c,String text,float x,float y,float size,int color,Typeface font,Paint.Align align){
        paint.setShader(null);paint.setColor(color);paint.setStyle(Paint.Style.FILL);paint.setTypeface(font);paint.setTextSize(size);paint.setTextAlign(align);c.drawText(text,x,y,paint);paint.setTextAlign(Paint.Align.LEFT);
    }
    float measure(String s,float size){paint.setTypeface(regular);paint.setTextSize(size);return paint.measureText(s);}
    String ellipsize(String s,float width,float size){if(measure(s,size)<=width)return s;int n=s.length();while(n>0&&measure(s.substring(0,n)+"…",size)>width)n--;return s.substring(0,n)+"…";}

    void icon(Canvas c,String type,float x,float y,float size,int color){
        c.save();c.translate(x,y);c.scale(size/32,size/32);
        paint.setShader(null);paint.setColor(color);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2);paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);
        Path p=new Path();
        switch(type){
            case "wifi":
                c.drawArc(new RectF(-17,-9,17,24),220,100,false,paint);c.drawArc(new RectF(-11,-3,11,19),220,100,false,paint);c.drawArc(new RectF(-5,3,5,13),225,90,false,paint);paint.setStyle(Paint.Style.FILL);c.drawCircle(0,11,1.7f,paint);break;
            case "profile":
                c.drawCircle(0,-7,5.6f,paint);c.drawArc(new RectF(-11,3,11,22),180,180,false,paint);break;
            case "control":case "settings":
                for(int i=0;i<3;i++){float yy=-10+i*10,xx=i==1?7:-5;c.drawLine(-13,yy,xx-3,yy,paint);c.drawLine(xx+3,yy,13,yy,paint);c.drawCircle(xx,yy,3,paint);}break;
            case "gear":
                for(int i=0;i<32;i++){double angle=i*Math.PI/16;float r=(i%4==0||i%4==3)?15:11.5f;float xx=(float)Math.cos(angle)*r,yy=(float)Math.sin(angle)*r;if(i==0)p.moveTo(xx,yy);else p.lineTo(xx,yy);}p.close();c.drawPath(p,paint);c.drawCircle(0,0,5,paint);break;
            case "more":
                paint.setStyle(Paint.Style.FILL);for(int i=-1;i<=1;i++)c.drawCircle(i*10,0,2.4f,paint);break;
            case "input":
                p.moveTo(-14,-6);p.lineTo(14,-6);p.lineTo(11,8);p.lineTo(-11,8);p.close();c.drawPath(p,paint);c.drawLine(-8,-1,8,-1,paint);c.drawLine(-5,12,5,12,paint);break;
            case "apps":
                for(int yy=-1;yy<=1;yy+=2)for(int xx=-1;xx<=1;xx+=2)c.drawRoundRect(new RectF(xx*8-5,yy*8-5,xx*8+5,yy*8+5),2,2,paint);break;
            case "bluetooth":
                p.moveTo(-8,-9);p.lineTo(8,7);p.lineTo(0,14);p.lineTo(0,-14);p.lineTo(8,-7);p.lineTo(-8,9);c.drawPath(p,paint);break;
            case "memory":
                c.drawRoundRect(new RectF(-10,-10,10,10),2,2,paint);c.drawRect(-4,-4,4,4,paint);for(int i=-1;i<=1;i++){c.drawLine(i*7,-14,i*7,-10,paint);c.drawLine(i*7,10,i*7,14,paint);c.drawLine(-14,i*7,-10,i*7,paint);c.drawLine(10,i*7,14,i*7,paint);}break;
            case "sound":
                p.moveTo(-13,-4);p.lineTo(-7,-4);p.lineTo(0,-11);p.lineTo(0,11);p.lineTo(-7,4);p.lineTo(-13,4);p.close();c.drawPath(p,paint);c.drawArc(new RectF(-1,-11,17,11),-60,120,false,paint);break;
            case "timer":
                c.drawCircle(0,2,11,paint);c.drawLine(0,2,0,-5,paint);c.drawLine(0,2,6,5,paint);c.drawLine(-4,-13,4,-13,paint);break;
            case "moon":
                p.moveTo(5,-13);p.cubicTo(-15,-11,-15,13,4,13);p.cubicTo(10,13,13,8,14,5);p.cubicTo(1,10,-6,-3,5,-13);c.drawPath(p,paint);break;
            case "cloud":
                p.moveTo(-9,10);p.cubicTo(-19,9,-16,-5,-7,-4);p.cubicTo(-4,-17,13,-14,13,-2);p.cubicTo(24,-1,22,11,13,10);p.close();c.drawPath(p,paint);break;
            case "sun":
                c.drawCircle(0,0,6,paint);for(int i=0;i<8;i++){double angle=i*Math.PI/4;c.drawLine((float)Math.cos(angle)*10,(float)Math.sin(angle)*10,(float)Math.cos(angle)*14,(float)Math.sin(angle)*14,paint);}break;
            case "image":
                c.drawRoundRect(new RectF(-14,-11,14,11),2,2,paint);p.moveTo(-12,8);p.lineTo(-3,-3);p.lineTo(2,3);p.lineTo(7,-4);p.lineTo(13,6);c.drawPath(p,paint);c.drawCircle(-7,-5,2,paint);break;
            case "home":
                p.moveTo(-14,-1);p.lineTo(0,-13);p.lineTo(14,-1);p.moveTo(-10,-4);p.lineTo(-10,13);p.lineTo(10,13);p.lineTo(10,-4);p.moveTo(-3,13);p.lineTo(-3,3);p.lineTo(3,3);p.lineTo(3,13);c.drawPath(p,paint);break;
            case "remote":
                c.drawRoundRect(new RectF(-7,-15,7,15),5,5,paint);c.drawCircle(0,-5,3,paint);c.drawLine(-2,3,2,3,paint);c.drawLine(-2,8,2,8,paint);break;
            default:
                c.drawCircle(0,0,13,paint);c.drawLine(0,-1,0,7,paint);paint.setStyle(Paint.Style.FILL);c.drawCircle(0,-7,1.5f,paint);break;
        }
        paint.setStyle(Paint.Style.FILL);paint.setStrokeCap(Paint.Cap.BUTT);c.restore();
    }

    boolean handleKey(KeyEvent event){
        int code=event.getKeyCode();
        if(code==wakeKey){if(event.getAction()==KeyEvent.ACTION_UP)wakeKey=-1;return true;}
        if(code==KeyEvent.KEYCODE_VOLUME_UP||code==KeyEvent.KEYCODE_VOLUME_DOWN||code==KeyEvent.KEYCODE_VOLUME_MUTE||code==KeyEvent.KEYCODE_POWER||code==KeyEvent.KEYCODE_HOME)return false;
        boolean ok=code==KeyEvent.KEYCODE_DPAD_CENTER||code==KeyEvent.KEYCODE_ENTER||code==KeyEvent.KEYCODE_NUMPAD_ENTER;
        boolean handled=ok||code==KeyEvent.KEYCODE_BACK||code==KeyEvent.KEYCODE_ESCAPE||code==KeyEvent.KEYCODE_MENU||code==KeyEvent.KEYCODE_SETTINGS||code==KeyEvent.KEYCODE_INFO||code==KeyEvent.KEYCODE_DPAD_UP||code==KeyEvent.KEYCODE_DPAD_DOWN||code==KeyEvent.KEYCODE_DPAD_LEFT||code==KeyEvent.KEYCODE_DPAD_RIGHT||code==KeyEvent.KEYCODE_CHANNEL_UP||code==KeyEvent.KEYCODE_CHANNEL_DOWN;
        if(!handled)return false;
        host.lastInteraction=SystemClock.elapsedRealtime();
        if(screen==Screen.SAVER){if(event.getAction()==KeyEvent.ACTION_DOWN){wakeKey=code;home();}return true;}
        if(ok){
            if(event.getAction()==KeyEvent.ACTION_DOWN){
                if(event.getRepeatCount()==0){keyDownAt=event.getEventTime();longFired=false;}
                else if(!longFired&&event.getEventTime()-keyDownAt>=550){longFired=true;longActivate();}
            }else if(event.getAction()==KeyEvent.ACTION_UP){if(!longFired)activate();longFired=false;}
            return true;
        }
        if(event.getAction()!=KeyEvent.ACTION_DOWN)return true;
        if(code==KeyEvent.KEYCODE_BACK||code==KeyEvent.KEYCODE_ESCAPE){if(moving){moving=false;notifyText("Порядок сохранён");}else home();return true;}
        if(code==KeyEvent.KEYCODE_MENU||code==KeyEvent.KEYCODE_INFO){if(screen==Screen.WEATHER)host.chooseCity();else longActivate();return true;}
        if(code==KeyEvent.KEYCODE_SETTINGS){open(Screen.SETTINGS);return true;}
        navigate(code);return true;
    }
    void navigate(int code){
        boolean left=code==KeyEvent.KEYCODE_DPAD_LEFT,right=code==KeyEvent.KEYCODE_DPAD_RIGHT,up=code==KeyEvent.KEYCODE_DPAD_UP,down=code==KeyEvent.KEYCODE_DPAD_DOWN;
        if(screen==Screen.HOME){
            if(ambient()){colorHome.navigate(code);animateFocus();updateDescription();return;}
            if(moving){
                if(left||right){store.move(moveId,left?-1:1);List<AppEntry> d=dockApps();for(int i=0;i<d.size();i++)if(d.get(i).id.equals(moveId))selected=i;}
            }else if(prayerFocused){
                if(down){prayerFocused=false;if(prayersAtTop()&&hasRecents())recentFocused=true;}
                if(up){prayerFocused=false;if(!prayersAtTop()&&hasRecents())recentFocused=true;else{topFocused=true;topIndex=2;}}
            }else if(recentFocused){
                if(left)recentIndex=Math.max(0,recentIndex-1);
                if(right)recentIndex=Math.min(Math.max(0,shelfCards().size()-1),recentIndex+1);
                if(up){recentFocused=false;if(showPrayer()&&prayersAtTop())prayerFocused=true;else{topFocused=true;topIndex=2;}}
                if(down){recentFocused=false;prayerFocused=showPrayer()&&!prayersAtTop();}
            }else if(clockFocused){if(right){clockFocused=false;topFocused=true;topIndex=0;}else if(down)clockFocused=false;}
            else if(topFocused){
                if(left){if(topIndex>(couch()?-1:0))topIndex--;else{topFocused=false;clockFocused=true;}}
                if(right)topIndex=Math.min(couch()?3:2,topIndex+1);
                if(down){topFocused=false;if(showPrayer()&&prayersAtTop())prayerFocused=true;else if(hasRecents())recentFocused=true;else prayerFocused=showPrayer();}
            }else{
                if(left)selected=Math.max(0,selected-1);
                if(right)selected=Math.min(dockApps().size()+extraDockCount()-1,selected+1);
                if(up){if(showPrayer()&&prayersAtTop()&&hasRecents())recentFocused=true;else if(showPrayer())prayerFocused=true;else if(hasRecents())recentFocused=true;else{topFocused=true;topIndex=2;}}
                if(down)open(Screen.APPS);
            }
        }else if(screen==Screen.APPS){
            int count=visibleApps().size();
            if(left)gridIndex=Math.max(0,gridIndex-1);
            if(right)gridIndex=Math.min(Math.max(0,count-1),gridIndex+1);
            if(up)gridIndex=Math.max(0,gridIndex-8);
            if(down)gridIndex=Math.min(Math.max(0,count-1),gridIndex+8);
            if(code==KeyEvent.KEYCODE_CHANNEL_DOWN)gridIndex=Math.min(Math.max(0,count-1),gridIndex+24);
            if(code==KeyEvent.KEYCODE_CHANNEL_UP)gridIndex=Math.max(0,gridIndex-24);
        }else if(screen==Screen.CONTROL){
            if(left&&controlIndex%2==1)controlIndex--;
            if(right&&controlIndex%2==0)controlIndex++;
            if(up)controlIndex=Math.max(0,controlIndex-2);
            if(down)controlIndex=Math.min(7,controlIndex+2);
        }else if(screen==Screen.SETTINGS){
            if(left)settingsRight=false;
            if(right)settingsRight=true;
            if(settingsRight){
                if(up)settingIndex=Math.max(0,settingIndex-1);
                if(down)settingIndex=Math.min(Math.max(0,host.rows(category).size()-1),settingIndex+1);
            }else{
                if(up)category=Math.max(0,category-1);
                if(down)category=Math.min(CATEGORIES.length-1,category+1);
                settingIndex=0;
            }
        }
        animateFocus();updateDescription();
    }
    void activate(){
        host.lastInteraction=SystemClock.elapsedRealtime();
        if(screen==Screen.HOME){
            if(moving){moving=false;notifyText("Порядок сохранён");return;}
            if(prayerFocused){host.prayerSettings();return;}
            if(recentFocused){List<WatchCard> list=shelfCards();if(!list.isEmpty())host.openWatchCard(list.get(Math.min(recentIndex,list.size()-1)));return;}
            if(clockFocused){open(Screen.WEATHER);host.refreshWeather(true);return;}
            if(topFocused){
                if(ambient()){if(topIndex==0)host.inputs();else if(topIndex==1)host.wifi();else if(topIndex==2)open(Screen.APPS);else open(Screen.SETTINGS);}
                else if(couch()){if(topIndex<0)host.profiles();else if(topIndex==0)host.timer();else if(topIndex==1)host.chooseScene();else if(topIndex==2)open(Screen.CONTROL);else host.inputs();}
                else {if(topIndex==0)host.wifi();else if(topIndex==1)host.profiles();else open(Screen.CONTROL);}return;
            }
            List<AppEntry> d=dockApps();
            if(selected<d.size())host.launch(d.get(selected));
            else if(couch()){if(selected==d.size())open(Screen.SETTINGS);else open(Screen.APPS);}
            else if(selected==d.size())host.inputs();
            else if(selected==d.size()+1)open(Screen.SETTINGS);
            else open(Screen.APPS);
        }else if(screen==Screen.APPS){List<AppEntry>a=visibleApps();if(!a.isEmpty())host.launch(a.get(Math.min(gridIndex,a.size()-1)));}
        else if(screen==Screen.CONTROL)host.control(controlIndex);
        else if(screen==Screen.SETTINGS){if(!settingsRight){settingsRight=true;animateFocus();}else{List<MainActivity.SettingRow>r=host.rows(category);if(!r.isEmpty())r.get(Math.min(settingIndex,r.size()-1)).action.run();}}
        else if(screen==Screen.WEATHER)host.refreshWeather(true);
        else if(screen==Screen.SAVER)home();
    }
    void longActivate(){
        if(moving){moving=false;notifyText("Порядок сохранён");return;}
        if(screen==Screen.HOME&&prayerFocused){host.prayerSettings();return;}
        if(screen==Screen.HOME&&recentFocused){List<WatchCard> list=shelfCards();if(!list.isEmpty())host.appMenu(list.get(Math.min(recentIndex,list.size()-1)).app,false);}
        else if(screen==Screen.HOME&&!topFocused&&!clockFocused){List<AppEntry>d=dockApps();if(selected<d.size())host.appMenu(d.get(selected),true);else open(Screen.CONTROL);}
        else if(screen==Screen.APPS){List<AppEntry>a=visibleApps();if(!a.isEmpty())host.appMenu(a.get(Math.min(gridIndex,a.size()-1)),false);}
        else if(screen==Screen.HOME)open(Screen.CONTROL);
    }
    void updateDescription(){
        String label="Bravia Glass";
        if(screen==Screen.HOME){
            List<AppEntry>d=dockApps();
            if(prayerFocused)label="Время намаза, Махачкала. OK — настройки. "+host.prayerDescription();
            else if(recentFocused&&!shelfCards().isEmpty())label="Продолжить: "+shelfCards().get(Math.min(recentIndex,shelfCards().size()-1)).title;
            else if(topFocused)label=ambient()?ColorHome.TOP_LABELS[Math.max(0,Math.min(3,topIndex))]:couch()?(topIndex<0?"Профили":new String[]{"Таймер заставки","Сцены","Пункт управления","Входы ТВ"}[topIndex]):new String[]{"Wi-Fi","Профили","Пункт управления"}[topIndex];
            else if(clockFocused)label=homeWeatherSummary();
            else if(selected<d.size())label=store.label(d.get(selected));
            else if(couch())label=selected==d.size()?"Настройки":"Все приложения";
            else label=selected==d.size()?"Входы ТВ":selected==d.size()+1?"Настройки":"Все приложения";
        }
        else if(screen==Screen.APPS&&!visibleApps().isEmpty())label=store.label(visibleApps().get(Math.min(gridIndex,visibleApps().size()-1)));
        else if(screen==Screen.SETTINGS)label=settingsRight?host.rows(category).get(settingIndex).title:CATEGORIES[category];
        else if(screen==Screen.CONTROL)label=new String[]{"Wi-Fi","Bluetooth","Память","Звук","Таймер заставки","Чёрный экран","Входы ТВ","Настройки"}[controlIndex];
        setContentDescription(label);sendAccessibilityEvent(AccessibilityEvent.TYPE_VIEW_SELECTED);
    }
    @Override public boolean onTouchEvent(MotionEvent e){if(screen==Screen.SAVER){if(e.getAction()==MotionEvent.ACTION_UP){host.lastInteraction=SystemClock.elapsedRealtime();home();}return true;}return gestures.onTouchEvent(e);}
    @Override public boolean performClick(){super.performClick();activate();return true;}
    void tap(float x,float y,boolean isLong){
        host.lastInteraction=SystemClock.elapsedRealtime();
        float sx=(x-offsetX)/scale,sy=(y-offsetY)/scale;
        for(int i=hits.size()-1;i>=0;i--){
            Hit hit=hits.get(i);if(!hit.rect.contains(sx,sy))continue;
            prayerFocused=false;
            switch(hit.action){
                case "prayer":prayerFocused=true;recentFocused=false;clockFocused=false;topFocused=false;break;
                case "showRecents":recentFocused=true;clockFocused=false;topFocused=false;animateFocus();updateDescription();return;
                case "showPrayers":prayerFocused=true;recentFocused=false;clockFocused=false;topFocused=false;animateFocus();updateDescription();return;
                case "allApps":open(Screen.APPS);return;
                case "dock":selected=hit.index;topFocused=false;clockFocused=false;recentFocused=false;break;
                case "top":topFocused=true;clockFocused=false;recentFocused=false;topIndex=hit.index;break;
                case "profile":topFocused=true;clockFocused=false;recentFocused=false;topIndex=-1;break;
                case "recent":recentFocused=true;topFocused=false;clockFocused=false;recentIndex=hit.index;break;
                case "clock":clockFocused=true;topFocused=false;recentFocused=false;break;
                case "grid":gridIndex=hit.index;break;
                case "control":controlIndex=hit.index;break;
                case "category":category=hit.index;settingsRight=false;settingIndex=0;refresh();return;
                case "setting":settingsRight=true;settingIndex=hit.index;break;
                case "weather":break;
            }
            if(isLong)longActivate();else performClick();animateFocus();return;
        }
        if(screen==Screen.CONTROL&&sx<1266)home();
    }
    @Override protected void onDetachedFromWindow(){if(animator!=null)animator.cancel();scenic.dispose();super.onDetachedFromWindow();}
}
