package com.usman.braviaglass;

import android.content.Intent;
import android.net.Uri;

/** Requests Android's confirmation UI; never removes a package silently. */
final class AppUninstaller {
    static final int REQUEST=92,DETAILS=93;
    interface Launcher { void start(Intent intent,int requestCode); }
    static boolean request(String packageName,Launcher launcher){
        if(packageName==null||packageName.isEmpty())return false;
        for(String action:new String[]{Intent.ACTION_UNINSTALL_PACKAGE,Intent.ACTION_DELETE}){
            Intent intent=new Intent(action,Uri.fromParts("package",packageName,null))
                .putExtra(Intent.EXTRA_RETURN_RESULT,true);
            // Keep the result in this Activity's task. NEW_TASK can break the result on TV.
            try{launcher.start(intent,REQUEST);return true;}catch(RuntimeException ignored){}
        }
        return false;
    }
}
