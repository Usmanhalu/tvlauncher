package com.usman.braviaglass;

import android.content.ComponentName;
import android.graphics.Bitmap;

final class AppEntry {
    final String id;
    final String label;
    final ComponentName component;
    final Bitmap icon;
    final Bitmap banner;
    final int accent;
    final boolean system;

    AppEntry(String id, String label, ComponentName component, Bitmap icon, boolean system) {
        this(id,label,component,icon,null,system);
    }

    AppEntry(String id,String label,ComponentName component,Bitmap icon,Bitmap banner,boolean system) {
        this.id = id;
        this.label = label;
        this.component = component;
        this.icon = icon;
        this.banner = banner;
        this.accent = AppPalette.color(id,banner!=null?banner:icon);
        this.system = system;
    }
}
