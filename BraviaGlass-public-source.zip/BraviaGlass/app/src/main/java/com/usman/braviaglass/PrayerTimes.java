package com.usman.braviaglass;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.text.Html;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

/** Actual Sajda timetable for Makhachkala; never substitutes a different calculation. */
final class PrayerTimes {
    static final String BASE="https://sajda.com/ru/prayer-times/russia/dagestan-makhachkala/532096/";
    static final String[] LABELS={"Фаджр","Восход","Зухр","Аср","Магриб","Иша"};
    static final TimeZone ZONE=TimeZone.getTimeZone("Europe/Moscow");
    static final String CACHE="prayers.sajda.months.v1";
    final TreeMap<String,Day> days=new TreeMap<>();
    final SharedPreferences prefs;
    static final class Day {
        final String date;final String[] times;final int[] minutes=new int[6];
        Day(String date,String[] values)throws IllegalArgumentException{
            parseDate(date);if(values.length!=6)throw new IllegalArgumentException("Нужно шесть времён");
            this.date=date;this.times=values.clone();int previous=-1;
            for(int i=0;i<6;i++){
                if(!times[i].matches("(?:[01][0-9]|2[0-3]):[0-5][0-9]"))throw new IllegalArgumentException("Неверное время");
                minutes[i]=Integer.parseInt(times[i].substring(0,2))*60+Integer.parseInt(times[i].substring(3));
                if(minutes[i]<=previous)throw new IllegalArgumentException("Нарушен порядок времени");previous=minutes[i];
            }
        }
        int active(int minute){
            if(minute<minutes[0]||minute>=minutes[1]&&minute<minutes[2])return -1;
            for(int i=5;i>=0;i--)if(i!=1&&minute>=minutes[i])return i;
            return -1;
        }
    }
    static final class Display {
        final Day day;final int active;final boolean previousNight;
        Display(Day day,int active,boolean previousNight){this.day=day;this.active=active;this.previousNight=previousNight;}
    }
    PrayerTimes(Context context,SharedPreferences prefs){
        this.prefs=prefs;
        try(InputStream in=context.getAssets().open("prayers/sajda-makhachkala.json")){
            JSONObject json=new JSONObject(read(in));if(json.getInt("cityId")!=532096||!"Europe/Moscow".equals(json.getString("zone")))throw new JSONException("Неверный город");
            merge(parseRows(json.getJSONArray("rows")));
        }catch(Exception ignored){}
        try{merge(parseRows(new JSONArray(prefs.getString(CACHE,"[]"))));}catch(Exception ignored){}
    }
    static String read(InputStream input)throws IOException{
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buffer=new byte[8192];int n;
        while((n=input.read(buffer))!=-1){out.write(buffer,0,n);if(out.size()>256*1024)throw new IOException("Слишком большой календарь");}
        return out.toString("UTF-8");
    }
    static TreeMap<String,Day> parseRows(JSONArray rows)throws JSONException{
        if(rows.length()>800)throw new JSONException("Слишком много дней");TreeMap<String,Day> result=new TreeMap<>();
        for(int i=0;i<rows.length();i++){
            JSONArray row=rows.getJSONArray(i);if(row.length()!=7)throw new JSONException("Неполная строка");
            String[] values=new String[6];for(int j=0;j<6;j++)values[j]=row.getString(j+1);
            Day day=new Day(row.getString(0),values);if(result.put(day.date,day)!=null)throw new JSONException("Повтор даты");
        }
        return result;
    }
    void merge(Map<String,Day> values){days.putAll(values);}
    static Date parseDate(String date){
        if(date==null||!date.matches("[0-9]{4}-[0-9]{2}-[0-9]{2}"))throw new IllegalArgumentException("Неверная дата");
        SimpleDateFormat format=format("yyyy-MM-dd");format.setLenient(false);
        try{return format.parse(date);}catch(ParseException e){throw new IllegalArgumentException("Неверная дата",e);}
    }
    static SimpleDateFormat format(String pattern){SimpleDateFormat f=new SimpleDateFormat(pattern,new Locale("ru"));f.setTimeZone(ZONE);return f;}
    static String date(long wall){return format("yyyy-MM-dd").format(new Date(wall));}
    static String month(long wall){return format("yyyy-MM").format(new Date(wall));}
    Display display(long wall){
        String today=date(wall);Day day=days.get(today);if(day==null)return null;
        Calendar now=Calendar.getInstance(ZONE);now.setTimeInMillis(wall);int minute=now.get(Calendar.HOUR_OF_DAY)*60+now.get(Calendar.MINUTE);
        if(minute<day.minutes[0]){
            now.add(Calendar.DAY_OF_MONTH,-1);Day yesterday=days.get(date(now.getTimeInMillis()));
            if(yesterday!=null)return new Display(yesterday,5,true);
        }
        return new Display(day,day.active(minute),false);
    }
    String coverage(){if(days.isEmpty())return "Расписание не загружено";return "Сохранено по "+format("d MMMM yyyy").format(parseDate(days.lastKey()));}
    static String monthFromUrl(String raw){
        Uri u=Uri.parse(raw==null?"":raw);
        if(!"https".equals(u.getScheme())||!"sajda.com".equalsIgnoreCase(u.getHost())||u.getPort()!=-1)return "";
        String prefix="/ru/prayer-times/russia/dagestan-makhachkala/532096/",path=u.getPath();
        if(path==null||!path.startsWith(prefix))return "";String value=path.substring(prefix.length());
        if(value.endsWith("/pdf"))value=value.substring(0,value.length()-4);
        if(!value.matches("20[0-9]{2}-(?:0[1-9]|1[0-2])"))return "";
        // This timetable matches Sajda's local Makhachkala / standard-Asr setting.
        String asr=u.getQueryParameter("asr"),method=u.getQueryParameter("method");
        if(asr!=null&&!asr.equals("standard")||method!=null&&!method.equals("678"))return "";
        return value;
    }
    static TreeMap<String,Day> parseHtml(String html,String month){
        if(html==null||html.length()>240000||!month.matches("20[0-9]{2}-(?:0[1-9]|1[0-2])"))throw new IllegalArgumentException("Неверный месяц");
        Matcher table=Pattern.compile("(?is)<table\\b[^>]*\\bid=[\"']prayer-times-monthly-table[\"'][^>]*>(.*?)</table>").matcher(html);
        if(!table.find())throw new IllegalArgumentException("Дождитесь загрузки таблицы Sajda");String body=table.group(1);
        Matcher head=Pattern.compile("(?is)<thead\\b[^>]*>(.*?)</thead>").matcher(body);
        if(!head.find())throw new IllegalArgumentException("Нет заголовка расписания");
        Matcher columns=Pattern.compile("(?is)<th\\b[^>]*>(.*?)</th>").matcher(head.group(1));
        if(!columns.find()||!plain(columns.group(1)).equals("Дата"))throw new IllegalArgumentException("Неверные столбцы расписания");
        for(String label:LABELS)if(!columns.find()||!plain(columns.group(1)).equals(label))throw new IllegalArgumentException("Неверный порядок столбцов расписания");
        TreeMap<String,Day> values=new TreeMap<>();Matcher rows=Pattern.compile("(?is)<tr\\b[^>]*\\bdata-date=[\"']([0-9-]+)[\"'][^>]*>(.*?)</tr>").matcher(body);
        while(rows.find()){
            String date=rows.group(1);if(!date.startsWith(month+"-"))throw new IllegalArgumentException("В таблице другой месяц");
            Matcher cells=Pattern.compile("(?is)<td\\b[^>]*>(.*?)</td>").matcher(rows.group(2));ArrayList<String> times=new ArrayList<>();
            while(cells.find()&&times.size()<6)times.add(plain(cells.group(1)));
            Day day=new Day(date,times.toArray(new String[0]));if(values.put(date,day)!=null)throw new IllegalArgumentException("Повтор даты");
        }
        Calendar calendar=Calendar.getInstance(ZONE);calendar.setTime(parseDate(month+"-01"));int count=calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
        if(values.size()!=count)throw new IllegalArgumentException("Нажмите на странице «Показать все», затем «Сохранить месяц»");
        for(int day=1;day<=count;day++)if(!values.containsKey(String.format(Locale.US,"%s-%02d",month,day)))throw new IllegalArgumentException("Неполный месяц");
        return values;
    }
    static String plain(String html){return Html.fromHtml(html,Html.FROM_HTML_MODE_LEGACY).toString().replace('\u00a0',' ').trim();}
    void importHtml(String sourceUrl,String html){
        String month=monthFromUrl(sourceUrl);if(month.isEmpty())throw new IllegalArgumentException("Откройте Махачкалу: метод Махачкала, Аср — стандартный");
        TreeMap<String,Day> incoming=parseHtml(html,month);TreeMap<String,Day> all=new TreeMap<>(days);all.putAll(incoming);
        while(all.size()>800)all.pollFirstEntry();JSONArray json=new JSONArray();
        for(Day day:all.values()){JSONArray row=new JSONArray();row.put(day.date);for(String time:day.times)row.put(time);json.put(row);}
        prefs.edit().putString(CACHE,json.toString()).putString("prayers.sajda.lastSource",sourceUrl).apply();days.clear();days.putAll(all);
    }
}
