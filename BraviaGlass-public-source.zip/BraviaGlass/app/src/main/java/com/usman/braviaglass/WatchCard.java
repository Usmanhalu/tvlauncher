package com.usman.braviaglass;

import android.graphics.Bitmap;

final class WatchCard {
    final String title,subtitle,link;
    final AppEntry app;
    final Bitmap poster;
    final float progress;
    final boolean program;
    WatchCard(String title,String subtitle,String link,AppEntry app,Bitmap poster,float progress,boolean program){
        this.title=title;this.subtitle=subtitle;this.link=link;this.app=app;this.poster=poster;this.progress=progress;this.program=program;
    }
    static WatchCard recent(AppEntry app,String label){return new WatchCard(label,"Открыть снова","",app,null,0,false);}
}
