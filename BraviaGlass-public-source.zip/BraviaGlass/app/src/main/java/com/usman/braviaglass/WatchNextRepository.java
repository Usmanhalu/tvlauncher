package com.usman.braviaglass;

import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.*;
import android.net.Uri;
import android.os.Build;
import java.io.*;
import java.net.*;
import java.util.*;

/** Android's real Watch Next list, read only. Missing permission/provider yields an empty list. */
final class WatchNextRepository {
    static final Uri URI=Uri.parse("content://android.media.tv/watch_next_program");
    static String permission(){return Build.VERSION.SDK_INT>=29?"android.permission.READ_TV_LISTINGS":"com.android.providers.tv.permission.READ_EPG_DATA";}
    static boolean allowed(Context context){return context.checkSelfPermission(permission())==PackageManager.PERMISSION_GRANTED;}
    static List<WatchCard> load(Context context,List<AppEntry> apps,Store store,boolean pictures){
        ArrayList<WatchCard> result=new ArrayList<>();if(Build.VERSION.SDK_INT<26||!allowed(context))return result;
        String[] columns={"_id","package_name","title","episode_title","poster_art_uri","thumbnail_uri","last_playback_position_millis","duration_millis","intent_uri"};
        try(Cursor cursor=context.getContentResolver().query(URI,columns,null,null,"last_engagement_time_utc_millis DESC")){
            if(cursor==null)return result;
            while(cursor.moveToNext()&&result.size()<10){
                String owner=cursor.getString(1),title=cursor.getString(2);if(title==null||title.trim().isEmpty()||store.hidden(owner))continue;
                AppEntry app=null;for(AppEntry candidate:apps)if(candidate.id.equals(owner)){app=candidate;break;}if(app==null)continue;
                long position=cursor.getLong(6),duration=cursor.getLong(7);String art=cursor.getString(5);if(art==null||art.isEmpty())art=cursor.getString(4);
                Bitmap poster=pictures?picture(context,art):null;
                result.add(new WatchCard(title,cursor.isNull(3)?"Продолжить просмотр":cursor.getString(3),cursor.isNull(8)?"":cursor.getString(8),app,poster,duration>0?Math.max(0,Math.min(1,position/(float)duration)):0,true));
            }
        }catch(RuntimeException ignored){}
        return result;
    }
    static Bitmap picture(Context context,String raw){
        if(raw==null||raw.isEmpty())return null;
        HttpURLConnection connection=null;
        try{
            Uri uri=Uri.parse(raw);InputStream stream;
            if("content".equals(uri.getScheme())||"android.resource".equals(uri.getScheme()))stream=context.getContentResolver().openInputStream(uri);
            else if("https".equals(uri.getScheme())){connection=(HttpURLConnection)new URL(raw).openConnection();connection.setConnectTimeout(3000);connection.setReadTimeout(4000);stream=connection.getInputStream();}
            else return null;
            if(stream==null)return null;
            byte[] bytes;
            try(InputStream in=stream;ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1){out.write(buf,0,n);if(out.size()>4*1024*1024)return null;}bytes=out.toByteArray();
            }
            BitmapFactory.Options opts=new BitmapFactory.Options();opts.inJustDecodeBounds=true;BitmapFactory.decodeByteArray(bytes,0,bytes.length,opts);
            opts.inSampleSize=1;while(opts.outWidth/opts.inSampleSize>640||opts.outHeight/opts.inSampleSize>400)opts.inSampleSize*=2;
            opts.inJustDecodeBounds=false;return BitmapFactory.decodeByteArray(bytes,0,bytes.length,opts);
        }catch(Exception ignored){return null;}finally{if(connection!=null)connection.disconnect();}
    }
    static Intent intent(WatchCard card){
        try{
            Intent result=Intent.parseUri(card.link,Intent.URI_INTENT_SCHEME);result.setSelector(null);
            if(result.getComponent()!=null&&!result.getComponent().getPackageName().equals(card.app.id))result.setComponent(null);
            result.setPackage(card.app.id);result.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);result.setAction(Intent.ACTION_VIEW);return result;
        }catch(Exception ignored){return null;}
    }
}
