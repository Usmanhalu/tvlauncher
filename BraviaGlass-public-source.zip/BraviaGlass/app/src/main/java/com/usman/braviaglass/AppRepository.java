package com.usman.braviaglass;

import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import java.text.Collator;
import java.util.*;

final class AppRepository {
    static List<AppEntry> load(Context context) {
        PackageManager pm = context.getPackageManager();
        LinkedHashMap<String, ResolveInfo> found = new LinkedHashMap<>();
        for (String category : new String[]{Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER}) {
            List<ResolveInfo> activities = pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(category), 0);
            for (ResolveInfo ri : activities) {
                ActivityInfo a = ri.activityInfo;
                if (a == null || !a.enabled || !a.exported || a.packageName.equals(context.getPackageName())) continue;
                if (!found.containsKey(a.packageName)) found.put(a.packageName, ri);
            }
        }
        ArrayList<AppEntry> apps = new ArrayList<>();
        for (ResolveInfo ri : found.values()) {
            ActivityInfo a = ri.activityInfo;
            Bitmap icon = null;
            try {
                Drawable d = ri.loadIcon(pm);
                icon = Bitmap.createBitmap(144, 144, Bitmap.Config.ARGB_8888);
                d.setBounds(0, 0, 144, 144);
                d.draw(new Canvas(icon));
            } catch (RuntimeException ignored) { }
            Bitmap banner=null;
            try {
                Drawable d=a.loadBanner(pm);
                if(d==null&&a.applicationInfo!=null)d=a.applicationInfo.loadBanner(pm);
                if(d!=null){banner=Bitmap.createBitmap(320,180,Bitmap.Config.ARGB_8888);d.setBounds(0,0,320,180);d.draw(new Canvas(banner));}
            }catch(RuntimeException ignored){}
            CharSequence label = ri.loadLabel(pm);
            apps.add(new AppEntry(a.packageName, label == null ? a.packageName : label.toString(),
                    new ComponentName(a.packageName, a.name), icon, banner,
                    a.applicationInfo != null && (a.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0));
        }
        Collator collator = Collator.getInstance(new Locale("ru"));
        apps.sort((a,b) -> collator.compare(a.label, b.label));
        return apps;
    }
}
