package com.usman.braviaglass;

import android.animation.ValueAnimator;
import android.graphics.*;
import android.os.SystemClock;
import java.text.SimpleDateFormat;
import java.util.*;

/** Native adaptation of the Couch TV Night look; original artwork and licence are bundled. */
final class ScenicHome {
    final GlassView v;
    final Typeface clockFont;
    SceneSet.Frame frame,previous;
    float blend=1;
    ValueAnimator fade;
    ScenicHome(GlassView view){v=view;clockFont=Typeface.createFromAsset(v.getContext().getAssets(),"fonts/Antonio-Light.ttf");}
    void setFrame(SceneSet.Frame value){
        if(fade!=null)fade.cancel();previous=frame;frame=value;
        if(previous==null||!v.store.bool("animations",true)){blend=1;previous=null;v.invalidate();return;}
        fade=ValueAnimator.ofFloat(0,1);fade.setDuration(1600);
        fade.addUpdateListener(a->{blend=(float)a.getAnimatedValue();if(blend>=1)previous=null;v.invalidate();});fade.start();
    }
    void dispose(){if(fade!=null)fade.cancel();}
    void draw(Canvas c){
        if(frame==null){v.backdrop(c,v.wallpaper);header(c,null);if(v.showPrayer())v.drawPrayers(c);dock(c);return;}
        if(previous!=null&&blend<1){scene(c,previous);int layer=c.saveLayerAlpha(0,0,1920,1080,Math.round(blend*255));scene(c,frame);c.restoreToCount(layer);}
        else scene(c,frame);
        if(v.store.number("darkness",0)>0)v.rect(c,0,0,1920,1080,Color.argb(v.store.number("darkness",0),0,0,0));
        header(c,frame);
        if(v.showPrayer()&&v.prayersAtTop()){v.drawPrayers(c);if(v.hasRecents())recent(c);}
        else if(v.showPrayer()&&!v.recentFocused)v.drawPrayers(c);else recent(c);
        dock(c);
    }
    void scene(Canvas c,SceneSet.Frame f){
        Paint p=v.paint;
        p.setShader(null);p.setStyle(Paint.Style.FILL);p.setAlpha(255);p.setColor(Color.WHITE);p.setColorFilter(f.sceneTone);
        c.drawBitmap(f.photo,null,new RectF(0,0,1920,1080),p);p.setColorFilter(null);
        if(v.store.bool("showClock",true))clock(c,f);
        if(f.foreground!=null){p.setShader(null);p.setColor(Color.WHITE);p.setAlpha(255);p.setColorFilter(f.sceneTone);c.drawBitmap(f.foreground,null,new RectF(0,0,1920,1080),p);p.setColorFilter(null);}
        if(f.id.equals("water")||f.id.equals("dawn")){
            p.setShader(new LinearGradient(0,0,0,650,new int[]{f.id.equals("water")?0x59000c18:0x49321c0c,0x00000000},null,Shader.TileMode.CLAMP));p.setAlpha(255);c.drawRect(0,0,1920,650,p);p.setShader(null);
        }
        p.setShader(new LinearGradient(0,620,0,1080,new int[]{0x00000000,0x85000000},null,Shader.TileMode.CLAMP));p.setAlpha(255);c.drawRect(0,620,1920,1080,p);p.setShader(null);p.setColorFilter(null);
    }
    ColorMatrixColorFilter brightness(float value){return new ColorMatrixColorFilter(new float[]{value,0,0,0,0,0,value,0,0,0,0,0,value,0,0,0,0,0,1,0});}
    void clock(Canvas c,SceneSet.Frame f){
        Paint p=v.paint;float size=f.fontSize*v.store.number("clockSize",100)/100f;
        String time=new SimpleDateFormat(v.store.bool("clock24",true)?"HH:mm":"h:mm",Locale.US).format(new Date(v.now()));
        p.setTypeface(clockFont);p.setTextSize(size);p.setTextAlign(f.id.equals("fog")?Paint.Align.LEFT:Paint.Align.CENTER);
        float x=f.id.equals("fog")?96:960,y=f.clockTop+size*.92f;
        if(f.id.equals("water")){
            c.save();c.clipPath(f.clockSky);clockPass(c,f,time,x,y,1);c.restore();
            c.save();c.clipRect(0,594,1920,790);clockPass(c,f,time,x+5,y,.78f);c.restore();
        }else clockPass(c,f,time,x,y,1);
        p.setTextAlign(Paint.Align.LEFT);p.setTypeface(v.regular);p.setShader(null);p.setColorFilter(null);p.setAlpha(255);
    }
    void clockPass(Canvas c,SceneSet.Frame f,String time,float x,float y,float alpha){
        Paint p=v.paint;p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);p.setColorFilter(null);p.setShader(f.shader);p.setAlpha(Math.round(218*alpha));c.drawText(time,x,y,p);
        p.setShader(null);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.25f);p.setColor(Color.WHITE);p.setAlpha(Math.round(92*alpha));c.drawText(time,x,y,p);
        p.setStyle(Paint.Style.FILL);p.setShader(new LinearGradient(x-500,y-400,x+500,y+50,new int[]{0x30ffffff,0x00ffffff,0x00ffffff,0x16ffffff},new float[]{0,.38f,.7f,1},Shader.TileMode.CLAMP));p.setAlpha(Math.round(255*alpha));c.drawText(time,x,y,p);
        p.setShader(null);p.setAlpha(255);
    }
    void header(Canvas c,SceneSet.Frame f){
        int ink=f!=null&&f.id.equals("fog")?0xff16201d:GlassView.WHITE;
        String date=new SimpleDateFormat("EEEE, d MMMM",new Locale("ru")).format(new Date(v.now()));
        date=Character.toUpperCase(date.charAt(0))+date.substring(1);
        if(v.store.bool("showWeather",true)){
            if(v.weather!=null)date+="   ·   "+Weather.place(v.store).city+"  "+Weather.degrees(v.weather.temperature)+"  "+Weather.description(v.weather.code)+(v.weatherLoading?"  ↻":v.weatherFailed?" (сохранено)":"");
            else date+="   ·   "+Weather.place(v.store).city+"  "+(v.weatherLoading?"погода загружается…":!v.weatherError.isEmpty()?"нет связи с погодой":"загрузка погоды…");
        }
        float dateY=f==null?128:f.dateTop+30;
        boolean left=f!=null&&f.id.equals("fog");float x=left?104:960,size=30;
        while(v.measure(date,size)>(left?1160:1450)&&size>21)size--;
        v.text(c,date,x,dateY,size,ink,v.regular,left?Paint.Align.LEFT:Paint.Align.CENTER);
        RectF line=new RectF(left?90:230,dateY-40,left?1290:1640,dateY+20);
        if(v.clockFocused&&v.screen==GlassView.Screen.HOME)v.round(c,line,18,0x12ffffff,0xb3ffffff,2);
        if(v.screen==GlassView.Screen.HOME)v.hits.add(new GlassView.Hit(line,"clock",0));
        RectF profile=new RectF(80,60,80+Math.min(380,v.measure(v.store.name(),25)+48),107);
        v.glass(c,profile,24,0x70251b23);
        boolean selected=v.topFocused&&v.topIndex== -1&&v.screen==GlassView.Screen.HOME;
        if(selected)v.round(c,profile,24,0xeef5f7fa,0xffffffff,2);
        v.text(c,v.store.name(),profile.centerX(),92,25,selected?0xff172b39:GlassView.WHITE,v.medium,Paint.Align.CENTER);
        if(v.screen==GlassView.Screen.HOME)v.hits.add(new GlassView.Hit(profile,"profile",0));
        String[] icons={"moon","image","control","input"};
        for(int i=0;i<4;i++){
            RectF r=new RectF(1472+i*96,60,1556+i*96,144);boolean active=v.topFocused&&v.topIndex==i&&v.screen==GlassView.Screen.HOME;
            v.glass(c,r,42,active?0xf0f5f8fa:0x6b1e202b);v.icon(c,icons[i],r.centerX(),r.centerY(),33,active?0xff1e3748:GlassView.WHITE);
            if(active)v.round(c,r,42,0,GlassView.WHITE,2);
            if(v.screen==GlassView.Screen.HOME)v.hits.add(new GlassView.Hit(r,"top",i));
        }
    }
    void recent(Canvas c){
        if(!v.store.bool("showRecents",true))return;
        List<WatchCard> list=v.shelfCards();
        v.text(c,!list.isEmpty()&&list.get(0).program?"Продолжить просмотр":"Недавно открытые",80,658,25,0xcdf5f5f7,v.medium);
        if(v.showPrayer()&&!v.prayersAtTop()&&v.screen==GlassView.Screen.HOME){
            RectF back=new RectF(1350,618,1780,680);
            v.text(c,"Время намаза ↓",1760,658,25,GlassView.WHITE,v.regular,Paint.Align.RIGHT);
            v.hits.add(new GlassView.Hit(back,"showPrayers",0));
        }
        if(list.isEmpty()){
            v.text(c,"Здесь появятся приложения, которые вы открываете",80,722,24,0xbaf5f5f7,v.regular);return;
        }
        int start=Math.max(0,v.recentIndex-2);
        for(int i=start;i<Math.min(list.size(),start+3);i++){
            float x=80+(i-start)*550;RectF card=new RectF(x,692,x+520,838);v.glass(c,card,30,0x6b1e141c);
            boolean selected=v.recentFocused&&v.recentIndex==i&&v.screen==GlassView.Screen.HOME;
            if(selected)v.round(c,card,30,0x20ffffff,GlassView.WHITE,3);
            WatchCard cardData=list.get(i);RectF thumb=new RectF(x+18,710,x+152,820);
            if(cardData.poster!=null){v.paint.setShader(null);v.paint.setColor(Color.WHITE);v.paint.setAlpha(255);c.save();Path path=new Path();path.addRoundRect(thumb,18,18,Path.Direction.CW);c.clipPath(path);c.drawBitmap(cardData.poster,null,thumb,v.paint);c.restore();}
            else v.appIcon(c,cardData.app,thumb,false);
            v.text(c,v.ellipsize(v.store.label(cardData.app).toUpperCase(new Locale("ru")),310,18),x+174,731,18,0xb3f5f5f7,v.regular);
            v.text(c,v.ellipsize(cardData.title,315,28),x+174,774,28,GlassView.WHITE,v.medium);
            v.text(c,v.ellipsize(cardData.subtitle,310,21),x+174,807,21,0xc6f5f5f7,v.regular);
            if(cardData.program&&cardData.progress>0){v.round(c,new RectF(x+174,824,x+499,829),3,0x55ffffff,0,0);v.round(c,new RectF(x+174,824,x+174+325*cardData.progress,829),3,GlassView.WHITE,0,0);}
            if(v.screen==GlassView.Screen.HOME)v.hits.add(new GlassView.Hit(card,"recent",i));
        }
    }
    void dock(Canvas c){
        List<AppEntry> list=v.dockApps();int count=list.size()+2,capacity=v.store.number("dockSize",100)>=115?10:12;
        int shown=Math.min(count,capacity),start=Math.max(0,Math.min(v.selected-shown/2,count-shown));
        float size=v.store.number("dockSize",100)>=115?126:112,gap=26,width=shown*size+(shown-1)*gap+56,x=(1920-width)/2;
        v.glass(c,new RectF(x,878,x+width,1034),44,0x721e141c);
        for(int n=0;n<shown;n++){
            int index=start+n;float tx=x+28+n*(size+gap),ty=900+(112-size)/2;
            boolean selected=index==v.selected&&!v.topFocused&&!v.clockFocused&&!v.recentFocused&&!v.prayerFocused&&v.screen==GlassView.Screen.HOME;
            RectF r=new RectF(tx,ty,tx+size,ty+size);
            if(selected){
                float grow=4+3*v.focusAmount();r.inset(-grow,-grow);r.offset(0,-6*v.focusAmount());
                RectF ring=new RectF(r);ring.inset(-5,-5);v.round(c,ring,31,0x30ffffff,v.moving?0xffb9e7ff:GlassView.WHITE,3);
                String label=index<list.size()?v.store.label(list.get(index)):index==list.size()?"Настройки":"Все приложения";
                v.text(c,(v.moving?"↔  ":"")+label,r.centerX(),857,24,GlassView.WHITE,v.medium,Paint.Align.CENTER);
            }
            if(index<list.size())v.appIcon(c,list.get(index),r,selected);
            else{v.round(c,r,25,0x3dffffff,0x24ffffff,1);v.icon(c,index==list.size()?"gear":"more",r.centerX(),r.centerY(),48,GlassView.WHITE);}
            if(v.screen==GlassView.Screen.HOME)v.hits.add(new GlassView.Hit(new RectF(tx-8,ty-12,tx+size+8,ty+size+12),"dock",index));
        }
        if(start>0)v.text(c,"‹",x-29,974,35,GlassView.WHITE,v.regular);
        if(start+shown<count)v.text(c,"›",x+width+19,974,35,GlassView.WHITE,v.regular);
    }
}
