package com.usman.braviaglass;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.*;
import org.json.JSONArray;

final class Store {
    final SharedPreferences prefs;
    Store(Context context) { prefs = context.getSharedPreferences("glass", Context.MODE_PRIVATE); }

    void migrateAmbientDesign() {
        if(number("ambientDesignVersion",0)>=1)return;
        put("previousLook",text("look","couch"));
        put("look","ambient");
        put("ambientDesignVersion",1);
    }
    String profile() { return prefs.getString("profile", "p0"); }
    String key(String name) { return profile() + "." + name; }
    String text(String name, String fallback) { return prefs.getString(key(name), fallback); }
    boolean bool(String name, boolean fallback) { return prefs.getBoolean(key(name), fallback); }
    int number(String name, int fallback) { return prefs.getInt(key(name), fallback); }
    void put(String name, String value) { prefs.edit().putString(key(name), value).apply(); }
    void put(String name, boolean value) { prefs.edit().putBoolean(key(name), value).apply(); }
    void put(String name, int value) { prefs.edit().putInt(key(name), value).apply(); }
    String name() { return text("name", profile().equals("p0") ? "Усман" : "Гость"); }
    String label(AppEntry app) { return text("label." + app.id, app.label); }

    List<String> list(String name) {
        ArrayList<String> values = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(text(name, "[]"));
            for (int i = 0; i < a.length(); i++) {
                String value = a.optString(i);
                if (!value.isEmpty() && !values.contains(value)) values.add(value);
            }
        } catch (Exception ignored) { }
        return values;
    }
    void list(String name, List<String> values) { put(name, new JSONArray(values).toString()); }
    boolean hidden(String id) { return list("hidden").contains(id); }
    void hide(String id, boolean hide) {
        List<String> values = list("hidden");
        values.remove(id);
        if (hide) values.add(id);
        list("hidden", values);
    }
    boolean favorite(String id) { return list("favorites").contains(id); }
    void favorite(String id, boolean enabled) {
        List<String> values = list("favorites");
        values.remove(id);
        if (enabled) values.add(id);
        list("favorites", values);
    }
    void seed(List<AppEntry> apps) {
        if (prefs.contains(key("favorites"))) return;
        ArrayList<String> ids = new ArrayList<>();
        String[] priority = {"youtube", "smarttube", "lampa", "ivi", "kinopoisk", "netflix", "amazon", "apple", "file"};
        for (String name : priority)
            for (AppEntry app : apps)
                if (matchesPriority(app.id, name) && !ids.contains(app.id) && ids.size() < 9) ids.add(app.id);
        for (AppEntry app : apps) if (!ids.contains(app.id) && ids.size() < 9) ids.add(app.id);
        list("favorites", ids);
    }
    static boolean matchesPriority(String id,String keyword) {
        String value=id.toLowerCase(Locale.ROOT);
        if(keyword.equals("ivi"))return value.startsWith("ru.ivi")||value.startsWith("com.ivi")||value.contains(".ivi.");
        return value.contains(keyword);
    }
    List<AppEntry> visible(List<AppEntry> apps, boolean favorites) {
        ArrayList<AppEntry> result = new ArrayList<>();
        if (favorites) {
            for (String id : list("favorites"))
                for (AppEntry app : apps) if (id.equals(app.id) && !hidden(id)) { result.add(app); break; }
        } else {
            for (AppEntry app : apps) if (!hidden(app.id)) result.add(app);
        }
        return result;
    }
    void move(String id, int delta) {
        List<String> values = list("favorites");
        int index = values.indexOf(id), target = index + delta;
        if (index < 0 || target < 0 || target >= values.size()) return;
        Collections.swap(values, index, target);
        list("favorites", values);
    }
    List<String> profiles() {
        ArrayList<String> values = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs.getString("profiles", "[\"p0\"]"));
            for (int i = 0; i < a.length(); i++) values.add(a.getString(i));
        } catch (Exception ignored) { values.add("p0"); }
        return values;
    }
    void selectProfile(String id) { if (profiles().contains(id)) prefs.edit().putString("profile", id).apply(); }
    void addProfile(String name) {
        List<String> values = profiles();
        String id = "p" + UUID.randomUUID().toString().replace("-", "");
        values.add(id);
        prefs.edit().putString("profiles", new JSONArray(values).toString()).putString("profile", id).putString(id + ".name", name).apply();
    }
    String profileName(String id) { return prefs.getString(id + ".name", id.equals("p0") ? "Усман" : "Гость"); }
    void resetLayout() {
        prefs.edit().remove(key("favorites")).remove(key("hidden")).apply();
    }
}
