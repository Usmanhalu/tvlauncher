package com.usman.braviaglass;

import android.graphics.*;

/** Frosted, slightly refracted wallpaper material. No scene-specific clock colours. */
final class ClockGlass {
    static final int WIDTH=256,HEIGHT=144;
    static Bitmap make(Bitmap photo,ColorFilter tone){
        Bitmap small=Bitmap.createBitmap(WIDTH,HEIGHT,Bitmap.Config.ARGB_8888);
        Paint paint=new Paint(Paint.FILTER_BITMAP_FLAG);paint.setColorFilter(tone);
        new Canvas(small).drawBitmap(photo,null,new Rect(0,0,WIDTH,HEIGHT),paint);
        int[] pixels=new int[WIDTH*HEIGHT],work=new int[pixels.length];small.getPixels(pixels,0,WIDTH,0,0,WIDTH,HEIGHT);
        for(int pass=0;pass<3;pass++){blur(pixels,work,WIDTH,HEIGHT,5,true);blur(work,pixels,WIDTH,HEIGHT,5,false);}
        long red=0,green=0,blue=0,weight=0;
        for(int y=HEIGHT/6;y<HEIGHT*5/12;y++)for(int x=WIDTH/5;x<WIDTH*4/5;x++){
            int c=pixels[y*WIDTH+x],r=Color.red(c),g=Color.green(c),b=Color.blue(c),w=1+(r+g+b)/32;
            red+=r*w;green+=g*w;blue+=b*w;weight+=w;
        }
        float rAccent=red/(float)weight,gAccent=green/(float)weight,bAccent=blue/(float)weight;
        boolean bright=.2126f*rAccent+.7152f*gAccent+.0722f*bAccent>195;
        for(int i=0;i<pixels.length;i++){
            int c=pixels[i];float r=.82f*Color.red(c)+.18f*rAccent,g=.82f*Color.green(c)+.18f*gAccent,b=.82f*Color.blue(c)+.18f*bAccent;
            float l=.2126f*r+.7152f*g+.0722f*b;
            r=l+(r-l)*1.3f;g=l+(g-l)*1.3f;b=l+(b-l)*1.3f;
            pixels[i]=Color.rgb(channel(bright?r*.47f:r*1.12f+32),channel(bright?g*.47f:g*1.12f+32),channel(bright?b*.47f:b*1.12f+32));
        }
        small.setPixels(pixels,0,WIDTH,0,0,WIDTH,HEIGHT);return small;
    }
    static int channel(float value){return Math.max(0,Math.min(255,Math.round(value)));}
    static void blur(int[] input,int[] output,int width,int height,int radius,boolean horizontal){
        int major=horizontal?height:width,minor=horizontal?width:height;
        for(int line=0;line<major;line++){
            int r=0,g=0,b=0;
            for(int k=-radius;k<=radius;k++){int at=Math.max(0,Math.min(minor-1,k)),c=input[horizontal?line*width+at:at*width+line];r+=Color.red(c);g+=Color.green(c);b+=Color.blue(c);}
            for(int at=0;at<minor;at++){
                int count=radius*2+1;output[horizontal?line*width+at:at*width+line]=Color.rgb(r/count,g/count,b/count);
                int remove=Math.max(0,at-radius),add=Math.min(minor-1,at+radius+1);
                int a=input[horizontal?line*width+remove:remove*width+line],z=input[horizontal?line*width+add:add*width+line];
                r+=Color.red(z)-Color.red(a);g+=Color.green(z)-Color.green(a);b+=Color.blue(z)-Color.blue(a);
            }
        }
    }
}
