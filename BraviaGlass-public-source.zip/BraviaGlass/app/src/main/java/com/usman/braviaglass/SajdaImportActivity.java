package com.usman.braviaglass;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.view.View;
import android.webkit.*;
import android.widget.*;
import java.util.Calendar;
import org.json.*;

/** A visible, ordinary Sajda browser. Only a complete, validated public month is saved. */
public final class SajdaImportActivity extends Activity {
    WebView web;
    TextView status;
    Button save;
    Calendar month=Calendar.getInstance(PrayerTimes.ZONE);
    boolean saving=false,closed=false;

    @SuppressLint("SetJavaScriptEnabled") // Required by the public site; no native JS bridge is exposed.
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        if(state!=null){String value=state.getString("month","");if(value.matches("20[0-9]{2}-(?:0[1-9]|1[0-2])"))month.setTime(PrayerTimes.parseDate(value+"-01"));}
        month.set(Calendar.DAY_OF_MONTH,1);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(0xff132b36);
        LinearLayout bar=new LinearLayout(this);
        button(bar,"Назад",this::finish);
        button(bar,"‹ Месяц",()->changeMonth(-1));
        button(bar,"Месяц ›",()->changeMonth(1));
        button(bar,"Показать все",()->web.evaluateJavascript("(()=>{const b=Array.from(document.querySelectorAll('button')).find(x=>x.textContent.trim()==='Показать все');if(b)b.click();})()",null));
        save=button(bar,"Сохранить месяц",this::saveMonth);
        root.addView(bar);
        status=new TextView(this);status.setTextSize(16);status.setTextColor(Color.WHITE);status.setPadding(16,6,16,6);root.addView(status);
        try{web=new WebView(this);}catch(RuntimeException unavailable){
            status.setText(R.string.sajda_no_webview);for(int i=1;i<bar.getChildCount();i++)bar.getChildAt(i).setEnabled(false);
            setContentView(root);return;
        }
        web.setBackgroundColor(Color.WHITE);
        WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportZoom(true);settings.setBuiltInZoomControls(true);settings.setDisplayZoomControls(false);
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return request.isForMainFrame()&&!allowedNavigation(request.getUrl().toString());}
            @Override public void onReceivedSslError(WebView view,SslErrorHandler handler,SslError error){handler.cancel();status.setText(R.string.sajda_ssl_error);}
            @Override public void onReceivedError(WebView view,WebResourceRequest request,WebResourceError error){if(request.isForMainFrame())status.setText(R.string.sajda_network_error);}
            @Override public void onPageFinished(WebView view,String url){if(!closed&&!saving)status.setText(getString(R.string.sajda_instructions,PrayerTimes.month(month.getTimeInMillis())));}
        });
        root.addView(web,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);loadMonth();
    }
    Button button(LinearLayout bar,String text,Runnable action){
        Button b=new Button(this);b.setText(text);b.setTextSize(14);b.setOnClickListener(v->action.run());
        bar.addView(b,new LinearLayout.LayoutParams(0,-2,1));return b;
    }
    static boolean allowedNavigation(String url){
        Uri u=Uri.parse(url==null?"":url);String path=u.getPath();
        return "https".equals(u.getScheme())&&"sajda.com".equalsIgnoreCase(u.getHost())&&u.getPort()==-1&&path!=null&&
            (path.startsWith("/ru/prayer-times/russia/dagestan-makhachkala/532096/")||path.startsWith("/cdn-cgi/"));
    }
    void changeMonth(int delta){if(saving)return;month.add(Calendar.MONTH,delta);loadMonth();}
    void loadMonth(){
        status.setText(getString(R.string.sajda_loading,PrayerTimes.month(month.getTimeInMillis())));
        if(!MainActivity.disableNetworkForTests)web.loadUrl(PrayerTimes.BASE+PrayerTimes.month(month.getTimeInMillis()));
    }
    void saveMonth(){
        if(saving)return;saving=true;save.setEnabled(false);status.setText(R.string.sajda_checking);
        web.evaluateJavascript("JSON.stringify({url:location.href,html:(document.querySelector('#prayer-times-monthly-table')||{outerHTML:''}).outerHTML})",this::acceptResult);
    }
    void acceptResult(String raw){
        if(closed)return;
        try{
            Object decoded=new JSONTokener(raw==null?"null":raw).nextValue();
            if(!(decoded instanceof String))throw new IllegalArgumentException("Дождитесь загрузки таблицы Sajda");
            JSONObject value=new JSONObject((String)decoded);
            new PrayerTimes(this,getSharedPreferences("glass",0)).importHtml(value.getString("url"),value.getString("html"));
            setResult(RESULT_OK,new Intent());finish();
        }catch(Exception ex){status.setText(ex instanceof IllegalArgumentException?ex.getMessage():"Таблица Sajda не распознана. Расписание не изменено.");}
        finally{saving=false;if(!closed)save.setEnabled(true);}
    }
    @Override public void onSaveInstanceState(Bundle state){super.onSaveInstanceState(state);state.putString("month",PrayerTimes.month(month.getTimeInMillis()));}
    @Override protected void onDestroy(){closed=true;if(web!=null){web.stopLoading();web.destroy();}super.onDestroy();}
}
