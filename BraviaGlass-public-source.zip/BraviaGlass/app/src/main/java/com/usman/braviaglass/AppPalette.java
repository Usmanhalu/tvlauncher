package com.usman.braviaglass;

import android.graphics.Bitmap;
import android.graphics.Color;
import java.util.Locale;

/** Deterministic brand colours, with a small saturation-weighted palette for other installed apps. */
final class AppPalette {
    static int color(String id,Bitmap artwork){
        String name=id.toLowerCase(Locale.ROOT);
        if(name.contains("youtube")||name.contains("smarttube"))return 0xffe62041;
        if(name.contains("rutube"))return 0xff7640e4;
        if(name.contains("kinopub")||name.contains("kino.pub"))return 0xff00a9e3;
        if(name.contains("videolan")||name.contains("vlc"))return 0xffe9791c;
        if(name.contains("dedproxy")||name.contains("ded.proxy"))return 0xffadb830;
        if(name.contains("livetv")||name.contains("live.tv")||name.equals("com.sony.dtv.tvx"))return 0xff265bff;
        if(artwork==null||artwork.isRecycled())return 0xff438abb;
        long[] weights=new long[36];long[] rs=new long[36],gs=new long[36],bs=new long[36];float[] hsv=new float[3];
        for(int y=0;y<24;y++)for(int x=0;x<24;x++){
            int c=artwork.getPixel(x*artwork.getWidth()/24,y*artwork.getHeight()/24);
            if(Color.alpha(c)<180)continue;
            Color.colorToHSV(c,hsv);
            if(hsv[1]<.24f||hsv[2]<.22f)continue;
            int bucket=Math.min(35,(int)(hsv[0]/10));long weight=Math.max(1,Math.round(hsv[1]*hsv[2]*100));
            weights[bucket]+=weight;rs[bucket]+=Color.red(c)*weight;gs[bucket]+=Color.green(c)*weight;bs[bucket]+=Color.blue(c)*weight;
        }
        int best=0;for(int i=1;i<36;i++)if(weights[i]>weights[best])best=i;
        if(weights[best]==0)return 0xff438abb;
        int value=Color.rgb((int)(rs[best]/weights[best]),(int)(gs[best]/weights[best]),(int)(bs[best]/weights[best]));
        Color.colorToHSV(value,hsv);hsv[1]=Math.min(.88f,Math.max(.45f,hsv[1]));hsv[2]=Math.max(.68f,hsv[2]);return Color.HSVToColor(hsv);
    }
    static int blend(int from,int to,float amount){
        float t=Math.max(0,Math.min(1,amount));return Color.rgb(Math.round(Color.red(from)+(Color.red(to)-Color.red(from))*t),Math.round(Color.green(from)+(Color.green(to)-Color.green(from))*t),Math.round(Color.blue(from)+(Color.blue(to)-Color.blue(from))*t));
    }
    private AppPalette(){}
}
