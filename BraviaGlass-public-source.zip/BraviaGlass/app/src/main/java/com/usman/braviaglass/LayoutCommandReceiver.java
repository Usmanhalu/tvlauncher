package com.usman.braviaglass;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

/** Small ADB configuration endpoint, restricted to senders holding system DUMP permission. */
public final class LayoutCommandReceiver extends BroadcastReceiver {
    static final String ACTION="com.usman.braviaglass.CONFIGURE";
    @Override public void onReceive(Context context,Intent intent){
        if(intent==null||!ACTION.equals(intent.getAction())){reply(1,"Unknown action");return;}
        try{
            Bundle extras=intent.getExtras();
            if(extras==null||extras.isEmpty())throw new IllegalArgumentException("Specify weather_position, weather_background or prayer_layout");
            for(String key:extras.keySet())if(!key.equals("weather_position")&&!key.equals("weather_background")&&!key.equals("prayer_layout"))throw new IllegalArgumentException("Unknown option: "+key);
            Object position=extras.get("weather_position"),background=extras.get("weather_background"),prayer=extras.get("prayer_layout");
            if(extras.containsKey("weather_position")&&(!(position instanceof String)||!position.equals("under_clock")&&!position.equals("top_right")))throw new IllegalArgumentException("weather_position: under_clock or top_right");
            if(extras.containsKey("weather_background")&&!(background instanceof Boolean))throw new IllegalArgumentException("weather_background requires --ez true or false");
            if(extras.containsKey("prayer_layout")&&(!(prayer instanceof String)||!prayer.equals("top_text")&&!prayer.equals("shelf_card")))throw new IllegalArgumentException("prayer_layout: top_text or shelf_card");
            Store store=new Store(context);
            android.content.SharedPreferences.Editor edit=store.prefs.edit();
            if(position!=null)edit.putString(store.key("weatherPosition"),(String)position);
            if(background!=null)edit.putBoolean(store.key("weatherBackground"),(Boolean)background);
            if(prayer!=null)edit.putString(store.key("prayerLayout"),(String)prayer);
            if(!edit.commit()){reply(2,"Could not save settings");return;}
            reply(0,"Saved: weather_position="+store.text("weatherPosition","under_clock")+", weather_background="+store.bool("weatherBackground",false)+"; prayer_layout="+store.text("prayerLayout","top_text")+"; profile="+store.profile());
        }catch(RuntimeException ex){reply(1,ex.getMessage()==null?"Invalid options":ex.getMessage());}
    }
    private void reply(int code,String message){if(isOrderedBroadcast()){setResultCode(code);setResultData(message);}}
}
