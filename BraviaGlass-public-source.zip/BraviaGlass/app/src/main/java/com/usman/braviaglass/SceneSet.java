package com.usman.braviaglass;

import android.content.Context;
import android.graphics.*;
import java.io.*;
import java.util.*;

/** Scene artwork, Antonio font and geometry adapted from Couch TV (c) 2026 Seagey, MIT.
 * See assets/scenes/LICENSE-Couch-TV.txt and CREDITS.md. Rendering here is native Canvas. */
final class SceneSet {
    static final String[] IDS={"night","golden","water","fog","dawn","sunset"};
    static final String[] NAMES={"Ночь у озера","Золотой час","Горное озеро","Туманные холмы","Рассвет","Закат у гор"};
    static final class Frame {
        final String id;
        final Bitmap photo,glass,foreground;
        final BitmapShader shader;
        final ColorMatrixColorFilter sceneTone;
        final Path clockSky;
        final int clockTop,fontSize,dateTop;
        Frame(String id,Bitmap photo,Bitmap fg){
            this.id=id;this.photo=photo;this.foreground=fg;
            int index=index(id);
            clockTop=new int[]{150,152,268,172,230,150}[index];
            fontSize=new int[]{400,390,420,470,400,400}[index];
            dateTop=new int[]{96,106,216,116,176,96}[index];
            clockSky=id.equals("water")?waterSky():null;
            float r=id.equals("sunset")?1.28f:id.equals("night")?.86f:1;
            float g=id.equals("sunset")?.77f:r,b=id.equals("sunset")?.64f:r;
            sceneTone=new ColorMatrixColorFilter(new float[]{r,0,0,0,0,0,g,0,0,0,0,0,b,0,0,0,0,0,1,0});
            this.glass=ClockGlass.make(photo,sceneTone);
            Bitmap glass=this.glass;
            shader=new BitmapShader(glass,Shader.TileMode.CLAMP,Shader.TileMode.CLAMP);
            Matrix m=new Matrix();m.setScale(1920f/glass.getWidth(),1080f/glass.getHeight());m.postTranslate(12,-6);shader.setLocalMatrix(m);
        }
    }
    /** Skyline of the bundled 1920x1080 lake scene. Only sky can show the upper clock;
     * the existing underwater pass stays separate. Coordinates never move the clock. */
    static Path waterSky(){
        float[] ridge={
            0,282,16,290,27,301,41,303,63,316,86,326,108,341,128,353,
            151,334,175,322,190,318,207,320,227,332,249,342,272,360,
            289,345,307,341,319,344,334,334,349,330,362,322,383,328,
            406,321,426,313,440,317,461,317,473,314,487,325,500,304,
            513,287,525,290,538,293,549,287,561,285,575,291,588,301,
            601,313,615,326,632,325,647,332,662,329,678,339,694,324,
            706,328,722,338,735,354,746,365,759,369,777,368,789,366,
            803,366,817,360,830,365,843,359,852,355,864,354,875,358,
            888,371,901,379,909,375,922,388,935,397,952,400,963,407,
            975,396,986,391,996,395,1004,400,1014,392,1023,397,
            1031,389,1043,385,1055,385,1063,382,1069,390,1076,389,
            1083,398,1094,389,1106,380,1120,371,1136,363,1152,355,
            1166,347,1178,351,1190,340,1200,339,1211,344,1225,353,
            1240,362,1253,365,1267,359,1281,349,1297,344,1312,338,
            1328,330,1344,326,1357,310,1372,299,1384,290,1397,286,
            1410,288,1421,299,1437,300,1450,298,1457,295,1464,304,
            1475,303,1490,317,1502,331,1519,329,1533,335,1544,334,
            1556,341,1569,341,1582,331,1598,331,1613,322,1627,316,
            1640,316,1654,310,1668,309,1684,301,1697,303,1706,298,
            1715,306,1727,300,1741,309,1755,317,1772,313,1789,306,
            1805,300,1821,292,1838,281,1854,275,1870,264,1884,253,
            1898,250,1911,244,1920,238
        };
        Path sky=new Path();sky.moveTo(0,0);sky.lineTo(1920,0);
        for(int i=ridge.length-2;i>=0;i-=2)sky.lineTo(ridge[i],ridge[i+1]);
        sky.close();return sky;
    }
    static int index(String id){for(int i=0;i<IDS.length;i++)if(IDS[i].equals(id))return i;return 0;}
    static Frame load(Context context,String id)throws IOException{
        id=IDS[index(id)];String asset=id.equals("sunset")?"night":id;
        Bitmap photo=read(context,"scene-"+asset+".jpg",false);
        Bitmap fg=id.equals("water")?null:read(context,"scene-"+asset+"-fg.webp",true);
        return new Frame(id,photo,fg);
    }
    static Bitmap read(Context context,String file,boolean alpha)throws IOException{
        BitmapFactory.Options opts=new BitmapFactory.Options();opts.inPreferredConfig=alpha?Bitmap.Config.ARGB_8888:Bitmap.Config.RGB_565;
        try(InputStream in=context.getAssets().open("scenes/"+file)){Bitmap b=BitmapFactory.decodeStream(in,null,opts);if(b==null)throw new IOException("Invalid scene "+file);return b;}
    }
    static void migrate(Store store){
        if(!store.prefs.getBoolean("look.couch.v110",false))store.prefs.edit().putString(store.key("look"),"couch").putString(store.key("sceneMode"),"cycle")
            .putInt(store.key("sceneSeconds"),20).putString(store.key("fixedScene"),"night")
            .putBoolean("look.couch.v110",true).apply();
        if(!store.prefs.getBoolean("look.glass.v112",false))store.prefs.edit()
            .putString(store.key("look"),"couch").putString(store.key("sceneMode"),"fixed")
            .putString(store.key("fixedScene"),"sunset").putBoolean("look.glass.v112",true).apply();
    }
    static String choose(Store store,Weather.Place place,Weather weather,long wall,long elapsed){
        String mode=store.text("sceneMode","cycle");
        if(mode.equals("fixed"))return IDS[index(store.text("fixedScene","night"))];
        if(mode.equals("sun"))try{return sun(Double.parseDouble(place.latitude),Double.parseDouble(place.longitude),wall,weather==null?-1:weather.code);}catch(NumberFormatException ignored){return "water";}
        int seconds=Math.max(10,Math.min(300,store.number("sceneSeconds",20)));
        return IDS[(int)(Math.max(0,elapsed)/(seconds*1000L)%IDS.length)];
    }
    /** Solar calculation and scene thresholds translated from Couch TV app.js (MIT). */
    static String sun(double lat,double lon,long wall,int code){
        Calendar utc=Calendar.getInstance(TimeZone.getTimeZone("UTC"));utc.setTimeInMillis(wall);
        double b=Math.toRadians(360/365.25*(utc.get(Calendar.DAY_OF_YEAR)-81));
        double eot=9.87*Math.sin(2*b)-7.53*Math.cos(b)-1.5*Math.sin(b),decl=Math.toRadians(23.45*Math.sin(b));
        double hours=utc.get(Calendar.HOUR_OF_DAY)+utc.get(Calendar.MINUTE)/60.0+utc.get(Calendar.SECOND)/3600.0;
        double solar=(hours+lon/15+eot/60+24)%24,angle=Math.toRadians((solar-12)*15),latitude=Math.toRadians(lat);
        double altitude=Math.toDegrees(Math.asin(Math.max(-1,Math.min(1,Math.sin(latitude)*Math.sin(decl)+Math.cos(latitude)*Math.cos(decl)*Math.cos(angle)))));
        if(altitude< -6)return "night";
        if(altitude<10)return angle<0?"dawn":"golden";
        return code==3||code==45||code==48||code>=51&&code<=67||code>=80&&code<=82?"fog":"water";
    }
}
