package com.usman.braviaglass;

import java.util.*;

/** Offline photographs; catalog and shuffle do not depend on Android. */
final class TravelCatalog {
    static final class Photo {
        final String asset,title,subtitle;
        final boolean nature;
        Photo(String id,String title,String subtitle,boolean nature){
            this.asset="travel/"+id+".jpg";this.title=title;this.subtitle=subtitle;this.nature=nature;
        }
    }
    static final List<Photo> PHOTOS=Collections.unmodifiableList(Arrays.asList(
        new Photo("paris","Париж","Франция · Эйфелева башня",false),
        new Photo("fuji","Гора Фудзи","Япония · весеннее цветение",true),
        new Photo("istanbul","Стамбул","Турция · Галатская башня",false),
        new Photo("alpine-lake","Озеро Брайес","Италия · Доломитовые Альпы",true),
        new Photo("dubai","Дубай","ОАЭ · Бурдж-Халифа",false),
        new Photo("lake","Озеро в горах","Тихое утро · горный пейзаж",true),
        new Photo("venice","Венеция","Италия · Гранд-канал",false),
        new Photo("mountain","Горная долина","Лес и горные вершины",true),
        new Photo("newyork","Нью-Йорк","США · Манхэттен",false),
        new Photo("night-mountain","Звёздная ночь","Млечный Путь над горами",true),
        new Photo("london","Лондон","Великобритания · Темза",false),
        new Photo("santorini","Санторини","Греция · Эгейское море",false)
    ));
    static String categoryName(String category){
        return "nature".equals(category)?"Только природа":"cities".equals(category)?"Города и достопримечательности":"Природа и города";
    }
    static int intervalSeconds(int seconds){return Math.max(30,Math.min(300,seconds));}
    static final class Deck {
        final Random random;
        final ArrayList<Photo> remaining=new ArrayList<>();
        Photo last;
        String category="";
        Deck(Random random){this.random=random;}
        Photo next(String filter){
            String valid="nature".equals(filter)||"cities".equals(filter)?filter:"all";
            if(!category.equals(valid)){remaining.clear();category=valid;}
            if(remaining.isEmpty()){
                for(Photo photo:PHOTOS)if(category.equals("all")||photo.nature==category.equals("nature"))remaining.add(photo);
                Collections.shuffle(remaining,random);
                if(remaining.size()>1&&remaining.get(remaining.size()-1)==last)Collections.swap(remaining,0,remaining.size()-1);
            }
            last=remaining.remove(remaining.size()-1);return last;
        }
    }
}
