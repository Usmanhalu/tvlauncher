package com.usman.braviaglass;

import android.graphics.*;
import android.os.SystemClock;
import android.view.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.*;

/** The approved colour-adaptive home screen, rendered natively for a television remote. */
final class ColorHome {
    final GlassView v;
    static final int BASE=0xff080c14;
    static final String[] TOP_LABELS={"Источники","Подключение","Все приложения","Настройки"};
    private final IdentityHashMap<Bitmap,Integer> customPalette=new IdentityHashMap<>();
    int fromColor=0xff00a9e3,targetColor=fromColor;
    long colorStarted=0,rowStarted=0;
    float rowFrom=0,rowTarget=0;
    String network="Не подключено";
    long networkChecked=-10000;
    ColorHome(GlassView view){v=view;}
    int currentColor(long at){
        if(!v.store.bool("animations",true))return targetColor;
        float t=Math.max(0,Math.min(1,(at-colorStarted)/800f));t=t*t*(3-2*t);
        return AppPalette.blend(fromColor,targetColor,t);
    }
    int selectedColor(){
        List<AppEntry> list=v.dockApps();
        if(list.isEmpty()||!v.store.bool("ambientColors",true))return 0xff438abb;
        AppEntry app=list.get(Math.min(v.selected,list.size()-1));Bitmap custom=v.host.customIcon(app.id);
        if(custom==null||custom.isRecycled())return app.accent;
        Integer color=customPalette.get(custom);if(color==null){if(customPalette.size()>32)customPalette.clear();color=AppPalette.color("",custom);customPalette.put(custom,color);}return color;
    }
    void background(Canvas c){
        long now=SystemClock.uptimeMillis();int target=selectedColor();
        if(target!=targetColor){fromColor=currentColor(now);targetColor=target;colorStarted=now;}
        int color=currentColor(now);float strength=Math.max(0,Math.min(1.3f,v.store.number("ambientStrength",100)/100f));
        Paint p=v.paint;c.drawColor(BASE);p.setStyle(Paint.Style.FILL);p.setAlpha(255);p.setColor(Color.WHITE);
        int bright=Color.argb(Math.round(92*strength),Color.red(color),Color.green(color),Color.blue(color));
        int dim=Color.argb(Math.round(36*strength),Color.red(color),Color.green(color),Color.blue(color));
        // Scaled radial gradients form a broad, soft pool of light, without bitmaps or blur allocations.
        c.save();c.scale(1,.72f);
        p.setShader(new RadialGradient(570,480,990,new int[]{bright,Color.TRANSPARENT},new float[]{0,1},Shader.TileMode.CLAMP));c.drawRect(0,0,1920,1500,p);c.restore();
        p.setShader(new RadialGradient(1470,1020,900,new int[]{dim,Color.TRANSPARENT},null,Shader.TileMode.CLAMP));c.drawRect(0,0,1920,1080,p);p.setShader(null);
        p.setShader(new LinearGradient(0,0,0,1080,new int[]{0x3d060911,0x00000000,0x6605080e},new float[]{0,.3f,1},Shader.TileMode.CLAMP));c.drawRect(0,0,1920,1080,p);p.setShader(null);
        if(v.store.bool("animations",true)&&now-colorStarted<800)v.postInvalidateOnAnimation();
    }
    void draw(Canvas c){
        header(c);
        if(v.showPrayer())v.drawPrayers(c);
        if(v.recentFocused&&v.hasRecents())recents(c);
        dock(c);
        v.text(c,"BRAVIAGLASS",1836,1030,17,0xff657288,v.regular,Paint.Align.RIGHT);
    }
    void header(Canvas c){
        Date date=new Date(v.now());Calendar cal=Calendar.getInstance();cal.setTime(date);int h=cal.get(Calendar.HOUR_OF_DAY);
        String greet=h>=5&&h<12?"ДОБРОЕ УТРО":h>=12&&h<18?"ДОБРЫЙ ДЕНЬ":h>=18&&h<23?"ДОБРЫЙ ВЕЧЕР":"ДОБРОЙ НОЧИ";
        boolean clock=v.store.bool("showClock",true);
        if(clock){
            v.text(c,greet,84,85,18,0xffadb8cb,v.medium);
            float size=70*v.store.number("clockSize",100)/100f;
            v.text(c,new SimpleDateFormat(v.store.bool("clock24",true)?"HH:mm":"h:mm",Locale.US).format(date),82,165,size,GlassView.WHITE,v.light);
        }
        float dateX=clock?Math.max(306,84+v.measure("00:00",70*v.store.number("clockSize",100)/100f)+36):84;
        String weekday=new SimpleDateFormat("EEEE",new Locale("ru")).format(date).toUpperCase(new Locale("ru"));
        v.text(c,weekday,dateX,109,19,0xffc1c9d7,v.medium);
        v.text(c,new SimpleDateFormat("d MMMM",new Locale("ru")).format(date),dateX,141,22,0xffa6b2c6,v.regular);
        if(v.store.bool("showWeather",true))weather(c,dateX);
        RectF clockArea=new RectF(72,58,Math.min(900,dateX+500),210);
        if(v.clockFocused&&v.screen==GlassView.Screen.HOME)v.round(c,clockArea,16,0x08ffffff,0x90ffffff,2);
        if(v.screen==GlassView.Screen.HOME&&(clock||v.store.bool("showWeather",true)))v.hits.add(new GlassView.Hit(clockArea,"clock",0));
        if(SystemClock.uptimeMillis()-networkChecked>=3000){network=v.host.networkLabel();networkChecked=SystemClock.uptimeMillis();}
        boolean connected=network.startsWith("Подключено")||network.equals("Есть подключение"),cable=network.contains("кабелю");
        topButton(c,new RectF(1084,82,1314,145),"input","Источники",0,false);
        RectF net=new RectF(1328,82,1550,145);boolean active=v.topFocused&&v.topIndex==1&&v.screen==GlassView.Screen.HOME;
        v.round(c,net,32,active?0x3ae7edff:0x12e7edff,active?0xffe8f4ff:0x16ffffff,active?2:1);
        v.icon(c,"wifi",1357,113,25,GlassView.WHITE);v.text(c,cable?"LAN":"Wi-Fi",1382,122,21,GlassView.WHITE,v.regular);
        v.round(c,new RectF(1470,102,1532,126),12,connected?0xff22d78c:0xff485365,0,0);
        v.text(c,connected?"ON":"OFF",1501,120,15,connected?0xff07271b:0xffe1e7ef,v.medium,Paint.Align.CENTER);
        if(v.screen==GlassView.Screen.HOME)v.hits.add(new GlassView.Hit(net,"top",1));
        topButton(c,new RectF(1564,82,1627,145),"apps","",2,false);
        topButton(c,new RectF(1641,82,1836,145),"gear","Настройки",3,false);
    }
    void topButton(Canvas c,RectF r,String icon,String label,int index,boolean ignored){
        boolean active=v.topFocused&&v.topIndex==index&&v.screen==GlassView.Screen.HOME;
        v.round(c,r,32,active?0x3ae7edff:0x12e7edff,active?0xffe8f4ff:0x16ffffff,active?2:1);
        v.icon(c,icon,label.isEmpty()?r.centerX():r.left+32,r.centerY(),25,GlassView.WHITE);
        if(!label.isEmpty())v.text(c,label,r.left+56,r.centerY()+8,21,GlassView.WHITE,v.regular);
        if(v.screen==GlassView.Screen.HOME)v.hits.add(new GlassView.Hit(r,"top",index));
    }
    RectF weatherBounds(){return new RectF(306,153,900,207);}
    void weather(Canvas c,float x){
        v.icon(c,v.weather!=null&&v.weather.code==0?"sun":"cloud",x+13,177,23,0xffd1dae8);
        String line=v.weather==null?(v.weatherFailed?"Нет связи с погодой":"Погода загружается…"):
            Weather.degrees(v.weather.temperature)+"  "+Weather.description(v.weather.code)+(v.weatherLoading?"  ↻":v.weatherFailed||v.now()-v.weather.updated>=Weather.FRESH_MS?" · сохранено":"");
        v.text(c,v.ellipsize(line,630,21),x+37,184,21,0xffc9d3e3,v.regular);
    }
    float rowOffset(long now){if(!v.store.bool("animations",true))return rowTarget;float t=Math.min(1,Math.max(0,(now-rowStarted)/420f));return rowFrom+(rowTarget-rowFrom)*(1-(float)Math.pow(1-t,3));}
    void dock(Canvas c){
        List<AppEntry> apps=v.dockApps();long now=SystemClock.uptimeMillis();float size=v.store.number("dockSize",100)>=115?320:280,height=size*.59285f,gap=26;
        float total=apps.size()*size+Math.max(0,apps.size()-1)*gap,available=1752;
        float desired=Math.max(0,Math.min(v.selected*(size+gap)+size/2-available/2,Math.max(0,total-available)));
        if(desired!=rowTarget){rowFrom=rowOffset(now);rowTarget=desired;rowStarted=now;}
        float scroll=rowOffset(now);boolean dockFocus=!v.topFocused&&!v.clockFocused&&!v.prayerFocused&&!v.recentFocused&&v.screen==GlassView.Screen.HOME;
        String name=apps.isEmpty()?(v.loading?"Загрузка приложений…":"Добавьте избранные приложения"):v.store.label(apps.get(Math.min(v.selected,apps.size()-1)));
        v.text(c,(v.moving?"↔  ":"")+v.ellipsize(name,1600,58),84,750,58,GlassView.WHITE,v.regular);
        c.save();c.clipRect(60,774,1860,1010);
        for(int i=0;i<apps.size();i++){
            float x=84+i*(size+gap)-scroll;if(x+size<60||x>1860)continue;
            RectF normal=new RectF(x,812,x+size,812+height),r=new RectF(normal);
            boolean selected=i==v.selected&&dockFocus;
            if(selected){float grow=.03f*(.5f+.5f*v.focusAmount());r.inset(-size*grow,-height*grow);r.offset(0,-3*v.focusAmount());v.round(c,new RectF(r.left-7,r.top-7,r.right+7,r.bottom+7),21,0x0cd6edff,0,0);}
            tile(c,apps.get(i),r);
            if(selected)v.round(c,r,17,Color.TRANSPARENT,v.moving?0xffb9e7ff:0xffe8f4ff,3);
            if(v.screen==GlassView.Screen.HOME){RectF hit=new RectF(normal);hit.intersect(72,786,1848,1000);v.hits.add(new GlassView.Hit(hit,"dock",i));}
        }
        c.restore();
        if(apps.isEmpty()){
            v.text(c,"Вниз — все приложения · удерживайте OK, чтобы добавить на панель",84,861,26,0xffa6b2c6,v.regular);
            if(v.screen==GlassView.Screen.HOME)v.hits.add(new GlassView.Hit(new RectF(72,774,1848,1000),"allApps",0));
        }
        if(v.store.bool("animations",true)&&now-rowStarted<420)v.postInvalidateOnAnimation();
    }
    void tile(Canvas c,AppEntry app,RectF r){
        Bitmap custom=v.host.customIcon(app.id);boolean initials=v.store.bool("initials."+app.id,false);
        v.round(c,r,17,AppPalette.blend(BASE,app.accent,.23f),0x20ffffff,1);
        if(app.banner!=null&&custom==null&&!initials){
            c.save();Path path=new Path();path.addRoundRect(r,17,17,Path.Direction.CW);c.clipPath(path);
            v.paint.setColor(Color.WHITE);v.paint.setShader(null);v.paint.setAlpha(255);c.drawBitmap(app.banner,null,r,v.paint);c.restore();return;
        }
        float side=r.height()*.68f;RectF icon=new RectF(r.centerX()-side/2,r.top+12,r.centerX()+side/2,r.top+12+side);
        v.appIcon(c,app,icon,false);
        v.text(c,v.ellipsize(v.store.label(app),r.width()-24,22),r.centerX(),r.bottom-12,22,GlassView.WHITE,v.medium,Paint.Align.CENTER);
    }
    void recents(Canvas c){
        List<WatchCard> cards=v.shelfCards();v.text(c,"Продолжить просмотр",84,423,25,0xffb8c3d5,v.regular);
        int start=Math.max(0,v.recentIndex-2);
        for(int i=start;i<Math.min(cards.size(),start+3);i++){
            WatchCard data=cards.get(i);float x=84+(i-start)*584;RectF r=new RectF(x,448,x+558,612);
            v.round(c,r,20,0xff182232,i==v.recentIndex?GlassView.WHITE:0x1affffff,i==v.recentIndex?3:1);
            RectF image=new RectF(x+18,468,x+146,592);
            if(data.poster!=null){v.paint.setColor(Color.WHITE);v.paint.setShader(null);c.drawBitmap(data.poster,null,image,v.paint);}else v.appIcon(c,data.app,image,false);
            v.text(c,v.ellipsize(v.store.label(data.app),365,20),x+170,490,20,0xffadb9ce,v.regular);
            v.text(c,v.ellipsize(data.title,365,27),x+170,536,27,GlassView.WHITE,v.medium);
            v.text(c,v.ellipsize(data.subtitle,365,21),x+170,578,21,0xffadb9ce,v.regular);
            if(v.screen==GlassView.Screen.HOME)v.hits.add(new GlassView.Hit(r,"recent",i));
        }
    }
    void navigate(int code){
        boolean left=code==KeyEvent.KEYCODE_DPAD_LEFT,right=code==KeyEvent.KEYCODE_DPAD_RIGHT,up=code==KeyEvent.KEYCODE_DPAD_UP,down=code==KeyEvent.KEYCODE_DPAD_DOWN;
        if(v.moving){if(left||right){v.store.move(v.moveId,left?-1:1);List<AppEntry> list=v.dockApps();for(int i=0;i<list.size();i++)if(list.get(i).id.equals(v.moveId))v.selected=i;}return;}
        if(v.prayerFocused){if(up){v.prayerFocused=false;v.topFocused=true;v.topIndex=0;}if(down){v.prayerFocused=false;v.recentFocused=v.hasRecents();}return;}
        if(v.recentFocused){if(left)v.recentIndex=Math.max(0,v.recentIndex-1);if(right)v.recentIndex=Math.min(Math.max(0,v.shelfCards().size()-1),v.recentIndex+1);if(up){v.recentFocused=false;if(v.showPrayer())v.prayerFocused=true;else{v.topFocused=true;v.topIndex=0;}}if(down)v.recentFocused=false;return;}
        if(v.clockFocused){if(right){v.clockFocused=false;v.topFocused=true;v.topIndex=0;}if(down)v.clockFocused=false;return;}
        if(v.topFocused){if(left){if(v.topIndex>0)v.topIndex--;else{v.topFocused=false;v.clockFocused=true;}}if(right)v.topIndex=Math.min(3,v.topIndex+1);if(down){v.topFocused=false;if(v.showPrayer())v.prayerFocused=true;else if(v.hasRecents())v.recentFocused=true;}return;}
        if(left)v.selected=Math.max(0,v.selected-1);if(right)v.selected=Math.min(Math.max(0,v.dockApps().size()-1),v.selected+1);
        if(up){if(v.hasRecents())v.recentFocused=true;else if(v.showPrayer())v.prayerFocused=true;else{v.topFocused=true;v.topIndex=0;}}
        if(down)v.open(GlassView.Screen.APPS);
    }
}
