package com.usman.braviaglass;

import android.app.*;
import android.app.role.RoleManager;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.*;
import android.os.*;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public final class MainActivity extends Activity {
    static boolean disableNetworkForTests=false;
    static final int PICK_WALLPAPER=80,PICK_ICON=81,IMPORT_PRAYERS=94,PICK_UPDATE_APK=95,UPDATE_PERMISSION=96;
    Store store;
    PrayerTimes prayers;
    GlassView glass;
    TravelSaver travelSaver;
    final Handler handler=new Handler(Looper.getMainLooper());
    final ExecutorService workers=Executors.newFixedThreadPool(3);
    final HashMap<String,Bitmap> customIcons=new HashMap<>();
    List<AppEntry> applications=new ArrayList<>();
    long sceneEpoch=SystemClock.elapsedRealtime();
    boolean sceneBusy=false,watchBusy=false;
    long lastWatchLoad=0;
    List<WatchCard> watchCards=new ArrayList<>();
    boolean catalogBusy=false,catalogDirty=true,weatherBusy=false,destroyed=false,blackOnly=false,awaitingUpdatePermission=false;
    long lastInteraction=SystemClock.elapsedRealtime(),saverStarted=0;
    String pendingIcon="",pendingProfile="";
    String pendingUninstall="",pendingUninstallLabel="";
    private boolean receiverRegistered=false;
    final WeatherRetry weatherRetry=new WeatherRetry();
    interface WeatherLoader { Weather load(Weather.Place place) throws Exception; }
    WeatherLoader weatherLoader=place->Weather.fetch(place,store.prefs);
    ConnectivityManager networkMonitor;
    boolean networkValidated=false;
    private final ConnectivityManager.NetworkCallback weatherNetwork=new ConnectivityManager.NetworkCallback(){
        @Override public void onCapabilitiesChanged(Network network,NetworkCapabilities caps){
            if(caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED))handler.post(()->{
                if(destroyed)return;
                if(!networkValidated){networkValidated=true;weatherRetry.reset();refreshWeather(false);}
            });
        }
        @Override public void onLost(Network network){handler.post(()->{networkValidated=false;});}
    };
    private final BroadcastReceiver packages=new BroadcastReceiver(){
        @Override public void onReceive(Context context,Intent intent){
            if(Intent.ACTION_PACKAGE_REMOVED.equals(intent.getAction())&&!intent.getBooleanExtra(Intent.EXTRA_REPLACING,false)&&intent.getData()!=null){
                String id=intent.getData().getSchemeSpecificPart();
                if(id.equals(pendingUninstall))uninstallConfirmed(id);
            }
            catalogDirty=true;reloadApps();
        }
    };
    private final BroadcastReceiver clockReceiver=new BroadcastReceiver(){
        @Override public void onReceive(Context context,Intent intent){glass.invalidate();}
    };
    private final Runnable tick=new Runnable(){
        @Override public void run(){
            if(destroyed)return;
            long now=SystemClock.elapsedRealtime();
            int idle=store.number("idleMinutes",10);
            long deadline=store.prefs.getLong("saverDeadline",0);
            if(glass.screen!=GlassView.Screen.SAVER&&((deadline>0&&System.currentTimeMillis()>=deadline)||(idle>0&&now-lastInteraction>=idle*60000L))){
                store.prefs.edit().remove("saverDeadline").apply();screensaver(false);
            }
            if(wantsWeather()&&weatherRetry.due(SystemClock.elapsedRealtime()))refreshWeather(false);
            if(glass.screen==GlassView.Screen.SAVER){if(!blackOnly)travelSaver.update();}
            else updateScenery();
            glass.invalidate();handler.postDelayed(this,1000);
        }
    };

    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);store=new Store(this);Weather.migrateMakhachkala(store);SceneSet.migrate(store);store.migrateAmbientDesign();
        prayers=new PrayerTimes(this,store.prefs);
        if(saved!=null){pendingIcon=saved.getString("pendingIcon","");pendingProfile=saved.getString("pendingProfile","");pendingUninstall=saved.getString("pendingUninstall","");pendingUninstallLabel=saved.getString("pendingUninstallLabel","");}
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        immersive();glass=new GlassView(this,store);setContentView(glass);glass.requestFocus();
        IntentFilter filter=new IntentFilter();filter.addAction(Intent.ACTION_PACKAGE_ADDED);filter.addAction(Intent.ACTION_PACKAGE_REMOVED);filter.addAction(Intent.ACTION_PACKAGE_CHANGED);filter.addDataScheme("package");
        if(Build.VERSION.SDK_INT>=33)registerReceiver(packages,filter,Context.RECEIVER_EXPORTED);else registerReceiver(packages,filter);
        IntentFilter time=new IntentFilter();time.addAction(Intent.ACTION_TIME_CHANGED);time.addAction(Intent.ACTION_TIMEZONE_CHANGED);time.addAction(Intent.ACTION_DATE_CHANGED);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(clockReceiver,time,Context.RECEIVER_EXPORTED);else registerReceiver(clockReceiver,time);
        receiverRegistered=true;
        try{networkMonitor=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);networkMonitor.registerDefaultNetworkCallback(weatherNetwork);}catch(RuntimeException ignored){networkMonitor=null;}
        travelSaver=new TravelSaver(this);travelSaver.prepare();
        loadWallpaper();updateScenery();reloadApps();glass.setWeather(Weather.cached(store),false);
        if(UpdateManager.INSTALL_ACTION.equals(getIntent().getAction()))handler.post(()->installResult(getIntent()));
    }
    @Override protected void onResume(){
        super.onResume();immersive();lastInteraction=SystemClock.elapsedRealtime();
        if(glass!=null){if(catalogDirty)reloadApps();glass.refresh();}
        if(!pendingUninstall.isEmpty()){String id=pendingUninstall;handler.postDelayed(()->verifyUninstall(id),700);}
        if(glass.screen==GlassView.Screen.SAVER&&!blackOnly)travelSaver.start();
        if(awaitingUpdatePermission&&UpdateManager.canInstall(this)){awaitingUpdatePermission=false;handler.post(()->installPrepared(UpdateManager.cacheApk(this)));}
        handler.removeCallbacks(tick);handler.post(tick);refreshWeather(false);refreshWatchNext(false);
    }
    @Override protected void onPause(){handler.removeCallbacks(tick);if(travelSaver!=null)travelSaver.stop();super.onPause();}
    @Override protected void onDestroy(){
        destroyed=true;handler.removeCallbacksAndMessages(null);workers.shutdownNow();
        if(receiverRegistered){unregisterReceiver(packages);unregisterReceiver(clockReceiver);}
        if(networkMonitor!=null)try{networkMonitor.unregisterNetworkCallback(weatherNetwork);}catch(RuntimeException ignored){}
        super.onDestroy();
    }
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);if(UpdateManager.INSTALL_ACTION.equals(intent.getAction())){installResult(intent);return;}if(glass!=null)glass.home();}
    @Override public void onWindowFocusChanged(boolean focus){super.onWindowFocusChanged(focus);if(focus)immersive();}
    @Override protected void onSaveInstanceState(Bundle out){super.onSaveInstanceState(out);out.putString("pendingIcon",pendingIcon);out.putString("pendingProfile",pendingProfile);out.putString("pendingUninstall",pendingUninstall);out.putString("pendingUninstallLabel",pendingUninstallLabel);}
    void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);}
    @Override public boolean dispatchKeyEvent(KeyEvent event){if(glass!=null&&glass.handleKey(event))return true;return super.dispatchKeyEvent(event);}
    @Override public void onBackPressed(){glass.home();}

    void reloadApps(){
        if(catalogBusy||destroyed)return;catalogBusy=true;catalogDirty=false;
        workers.execute(()->{
            List<AppEntry> loaded;
            try{loaded=AppRepository.load(this);}catch(RuntimeException ex){loaded=new ArrayList<>();}
            final List<AppEntry> result=loaded;
            handler.post(()->{if(destroyed)return;catalogBusy=false;applications=result;if(!result.isEmpty())store.seed(result);glass.setApps(result);loadCustomIcons();refreshWatchNext(true);if(catalogDirty)reloadApps();});
        });
    }
    void loadCustomIcons(){
        String profile=store.profile();HashMap<String,String> paths=new HashMap<>();
        for(AppEntry app:applications){String path=store.text("icon."+app.id,"");if(!path.isEmpty())paths.put(app.id,path);}
        workers.execute(()->{
            HashMap<String,Bitmap> loaded=new HashMap<>();
            for(Map.Entry<String,String> item:paths.entrySet())try{
                BitmapFactory.Options opts=new BitmapFactory.Options();opts.inSampleSize=1;
                File file=safeFile(item.getValue());if(file!=null){Bitmap b=BitmapFactory.decodeFile(file.getPath(),opts);if(b!=null)loaded.put(item.getKey(),b);}
            }catch(RuntimeException ignored){}
            handler.post(()->{if(!destroyed&&profile.equals(store.profile())){customIcons.clear();customIcons.putAll(loaded);glass.invalidate();}});
        });
    }
    Bitmap customIcon(String id){return customIcons.get(id);}
    File safeFile(String name){return name.matches("[a-zA-Z0-9_-]+\\.(jpg|png)")?new File(getFilesDir(),name):null;}
    void loadWallpaper(){
        String profile=store.profile(),path=store.text("wallpaper","");
        workers.execute(()->{
            Bitmap image=null;
            try{File file=safeFile(path);if(file!=null&&file.isFile())image=decode(file,2560,1440);if(image==null)try(InputStream in=getAssets().open("forest.jpg")){image=BitmapFactory.decodeStream(in);}}
            catch(Exception ignored){}
            final Bitmap photo=image,blur=blur(image);
            handler.post(()->{if(!destroyed&&profile.equals(store.profile()))glass.setWallpaper(photo,blur);});
        });
    }
    static Bitmap decode(File file,int width,int height){
        BitmapFactory.Options opts=new BitmapFactory.Options();opts.inJustDecodeBounds=true;BitmapFactory.decodeFile(file.getPath(),opts);
        if(opts.outWidth<=0||opts.outHeight<=0)return null;
        opts.inSampleSize=1;while(opts.outWidth/opts.inSampleSize>width*2||opts.outHeight/opts.inSampleSize>height*2)opts.inSampleSize*=2;
        opts.inJustDecodeBounds=false;opts.inPreferredConfig=Bitmap.Config.ARGB_8888;
        Bitmap b=BitmapFactory.decodeFile(file.getPath(),opts);if(b==null)return null;
        float factor=Math.min(1f,Math.min(width/(float)b.getWidth(),height/(float)b.getHeight()));
        if(factor<1){Bitmap scaled=Bitmap.createScaledBitmap(b,Math.max(1,Math.round(b.getWidth()*factor)),Math.max(1,Math.round(b.getHeight()*factor)),true);if(scaled!=b)b.recycle();return scaled;}return b;
    }
    static Bitmap blur(Bitmap source){
        if(source==null)return null;
        int w=120,h=Math.max(1,Math.round(source.getHeight()*120f/source.getWidth()));
        Bitmap small=Bitmap.createScaledBitmap(source,w,h,true).copy(Bitmap.Config.ARGB_8888,true);
        int[] pixels=new int[w*h],out=new int[w*h];small.getPixels(pixels,0,w,0,0,w,h);
        for(int pass=0;pass<3;pass++){
            for(int y=0;y<h;y++)for(int x=0;x<w;x++){
                int r=0,g=0,b=0,n=0;
                for(int yy=Math.max(0,y-2);yy<=Math.min(h-1,y+2);yy++)for(int xx=Math.max(0,x-2);xx<=Math.min(w-1,x+2);xx++){int value=pixels[yy*w+xx];r+=Color.red(value);g+=Color.green(value);b+=Color.blue(value);n++;}
                out[y*w+x]=Color.rgb(r/n,g/n,b/n);
            }
            int[] temp=pixels;pixels=out;out=temp;
        }
        small.setPixels(pixels,0,w,0,0,w,h);return small;
    }
    boolean wantsWeather(){return store.bool("showWeather",true)||(glass!=null&&glass.screen==GlassView.Screen.SAVER&&!blackOnly&&store.bool("saverWeather",true));}
    void refreshWeather(boolean force){
        if(disableNetworkForTests||destroyed||(!force&&!wantsWeather()))return;
        if(weatherBusy)return;
        Weather.Place place=Weather.place(store);
        String requestKey=store.profile()+"."+place.requestKey();
        Weather cached=Weather.cached(place,store.prefs);
        long elapsed=SystemClock.elapsedRealtime(),wall=System.currentTimeMillis();
        if(!force&&Weather.fresh(cached,wall)){
            glass.setWeather(cached,false);weatherRetry.success(elapsed,Weather.FRESH_MS-(wall-cached.updated));return;
        }
        if(!force&&!weatherRetry.due(elapsed))return;
        weatherBusy=true;glass.weatherLoading=true;glass.weatherError="";glass.invalidate();
        if(force)glass.notifyText("Обновление погоды…");
        WeatherLoader loader=weatherLoader;
        workers.execute(()->{
            Weather fresh=null;Exception problem=null;
            try{fresh=loader.load(place);}catch(Exception ex){problem=ex;}
            final Weather result=fresh;final Exception error=problem;
            handler.post(()->{
                if(destroyed)return;weatherBusy=false;
                String activeKey=store.profile()+"."+Weather.place(store).requestKey();
                if(!requestKey.equals(activeKey)){
                    glass.weatherLoading=false;weatherRetry.reset();refreshWeather(false);return;
                }
                boolean failed=result==null;
                glass.setWeather(failed?Weather.cached(place,store.prefs):result,failed);
                glass.weatherError=failed?Weather.errorMessage(error):"";
                if(failed)weatherRetry.failure(SystemClock.elapsedRealtime());
                else weatherRetry.success(SystemClock.elapsedRealtime(),Weather.FRESH_MS);
                if(force)glass.notifyText(failed?glass.weatherError:"Погода обновлена: "+place.city);
                glass.invalidate();
            });
        });
    }
    void updateScenery(){
        if(destroyed||glass==null||!glass.couch()||sceneBusy)return;
        String target=SceneSet.choose(store,Weather.place(store),glass.weather,System.currentTimeMillis(),SystemClock.elapsedRealtime()-sceneEpoch);
        if(glass.scenic.frame!=null&&glass.scenic.frame.id.equals(target))return;
        if(glass.scenic.frame!=null&&(glass.screen!=GlassView.Screen.HOME||SystemClock.elapsedRealtime()-lastInteraction<2500))return;
        sceneBusy=true;
        workers.execute(()->{
            SceneSet.Frame frame=null;try{frame=SceneSet.load(this,target);}catch(Exception ignored){}
            final SceneSet.Frame loaded=frame;
            handler.post(()->{if(destroyed)return;sceneBusy=false;if(loaded!=null&&glass.couch())glass.scenic.setFrame(loaded);});
        });
    }
    void chooseScene(){
        String[] options=new String[SceneSet.IDS.length+4];options[0]="Цвета приложений · новый дизайн";options[1]="Пейзажи: смена каждые 20 секунд";options[2]="По солнцу и погоде";
        System.arraycopy(SceneSet.NAMES,0,options,3,SceneSet.NAMES.length);options[options.length-1]="Прежнее оформление Bravia Glass";
        choice("Оформление и сцены",options,index->{
            if(index==0){store.put("look","ambient");glass.home();return;}
            if(index==options.length-1){store.put("look","classic");glass.refresh();return;}
            store.put("look","couch");sceneEpoch=SystemClock.elapsedRealtime();
            if(index==1)store.put("sceneMode","cycle");
            else if(index==2)store.put("sceneMode","sun");
            else {store.put("sceneMode","fixed");store.put("fixedScene",SceneSet.IDS[index-3]);}
            lastInteraction=0;updateScenery();glass.refresh();
        });
    }
    void refreshWatchNext(boolean force){
        if(destroyed||glass==null||(!glass.couch()&&!glass.ambient())||watchBusy||!store.bool("useWatchNext",true))return;
        if(!force&&SystemClock.elapsedRealtime()-lastWatchLoad<30000)return;
        if(!WatchNextRepository.allowed(this)){watchCards=new ArrayList<>();return;}
        watchBusy=true;lastWatchLoad=SystemClock.elapsedRealtime();String profile=store.profile();List<AppEntry> snapshot=new ArrayList<>(applications);
        workers.execute(()->{
            List<WatchCard> loaded=WatchNextRepository.load(this,snapshot,store,!disableNetworkForTests);
            handler.post(()->{if(destroyed)return;watchBusy=false;if(profile.equals(store.profile())){watchCards=loaded;glass.refresh();}});
        });
    }
    void requestWatchNext(){
        if(WatchNextRepository.allowed(this)){refreshWatchNext(true);glass.notifyText("Обновляю «Продолжить просмотр»");return;}
        try{requestPermissions(new String[]{WatchNextRepository.permission()},91);}catch(RuntimeException ignored){glass.notifyText("Телевизор не предложил доступ к списку просмотра");}
    }
    @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] grants){super.onRequestPermissionsResult(request,permissions,grants);if(request==91)refreshWatchNext(true);}
    void openWatchCard(WatchCard card){
        if(card.program&&!card.link.isEmpty())try{Intent intent=WatchNextRepository.intent(card);if(intent!=null){startActivity(intent);return;}}catch(RuntimeException ignored){}
        launch(card.app);
    }
    void launch(AppEntry app){
        try{Intent intent=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(app.component).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);startActivity(intent);
            List<String> recent=store.list("recents");recent.remove(app.id);recent.add(0,app.id);while(recent.size()>10)recent.remove(recent.size()-1);store.list("recents",recent);
        }
        catch(RuntimeException ex){catalogDirty=true;glass.notifyText("Не удалось открыть приложение. Обновляю список.");reloadApps();}
    }
    void wifi(){system(new Intent(Settings.ACTION_WIFI_SETTINGS),new Intent(Settings.ACTION_WIRELESS_SETTINGS));}
    void inputs(){system(new Intent("com.sony.dtv.intent.action.TVINPUT"),new Intent("android.intent.action.VIEW").setData(Uri.parse("content://android.media.tv/passthrough")),new Intent("android.settings.TV_INPUT_SETTINGS"));}
    void system(Intent... intents){
        for(Intent intent:intents){try{startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));return;}catch(RuntimeException ignored){}}
        try{startActivity(new Intent(Settings.ACTION_SETTINGS));glass.notifyText("Нужный раздел откройте в настройках телевизора");}catch(RuntimeException ignored){glass.notifyText("Этот раздел недоступен на устройстве");}
    }
    String networkLabel(){
        try{ConnectivityManager manager=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);NetworkCapabilities caps=manager.getNetworkCapabilities(manager.getActiveNetwork());
            if(caps==null)return "Не подключено";return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)?"Подключено по Wi-Fi":caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)?"Подключено по кабелю":"Есть подключение";
        }catch(RuntimeException ex){return "Открыть настройки";}
    }
    String memoryLabel(){
        ActivityManager manager=(ActivityManager)getSystemService(ACTIVITY_SERVICE);ActivityManager.MemoryInfo info=new ActivityManager.MemoryInfo();manager.getMemoryInfo(info);
        return String.format(Locale.US,"ОЗУ: свободно %.1f ГБ",info.availMem/(1024f*1024*1024));
    }
    String timerLabel(){long deadline=store.prefs.getLong("saverDeadline",0);return deadline>System.currentTimeMillis()?"Через "+Math.max(1,(deadline-System.currentTimeMillis()+59999)/60000)+" мин":"Не установлен";}
    void control(int index){
        switch(index){
            case 0:wifi();break;
            case 1:system(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));break;
            case 2:system(new Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS),new Intent(Settings.ACTION_MEMORY_CARD_SETTINGS));break;
            case 3:system(new Intent(Settings.ACTION_SOUND_SETTINGS));break;
            case 4:timer();break;
            case 5:screensaver(true);break;
            case 6:inputs();break;
            case 7:glass.open(GlassView.Screen.SETTINGS);break;
        }
    }
    void screensaver(boolean black){blackOnly=black;saverStarted=SystemClock.uptimeMillis();glass.open(GlassView.Screen.SAVER);if(!black){travelSaver.start();refreshWeather(false);}}
    void timer(){
        choice("Таймер заставки",new String[]{"Выключить таймер","Через 15 минут","Через 30 минут","Через 60 минут","Через 90 минут"},which->{
            int[] minutes={0,15,30,60,90};long deadline=which==0?0:System.currentTimeMillis()+minutes[which]*60000L;
            store.prefs.edit().putLong("saverDeadline",deadline).apply();glass.notifyText(which==0?"Таймер выключен":"Заставка через "+minutes[which]+" мин, когда открыт лаунчер");
        });
    }
    void defaultHome(){
        if(Build.VERSION.SDK_INT>=29){
            RoleManager manager=(RoleManager)getSystemService(ROLE_SERVICE);
            if(manager!=null&&manager.isRoleAvailable(RoleManager.ROLE_HOME)){
                if(manager.isRoleHeld(RoleManager.ROLE_HOME)){glass.notifyText("Bravia Glass уже выбран главным экраном");return;}
                try{startActivityForResult(manager.createRequestRoleIntent(RoleManager.ROLE_HOME),90);return;}catch(RuntimeException ignored){}
            }
        }
        info("Главный экран и кнопка HOME","В следующем окне выберите Bravia Glass и «Всегда», если телевизор предлагает выбор. Если Sony не показывает выбор лаунчера, кнопка HOME останется привязана к штатному экрану. В этой версии штатный лаунчер автоматически не отключается.",()->system(new Intent(Settings.ACTION_HOME_SETTINGS),new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)));
    }
    void appMenu(AppEntry app,boolean fromDock){
        boolean fav=store.favorite(app.id);
        String[] labels={"Открыть",fav?"Убрать с нижней панели":"Добавить на нижнюю панель","Переместить на панели","Переименовать","Изменить значок","Скрыть приложение","Сведения о приложении",app.system?"Настройки системного приложения":"Удалить приложение"};
        choice(store.label(app),labels,index->{
            switch(index){
                case 0:launch(app);break;
                case 1:store.favorite(app.id,!fav);glass.refresh();break;
                case 2:
                    if(!fav)store.favorite(app.id,true);glass.home();glass.moving=true;glass.moveId=app.id;
                    List<AppEntry>d=glass.dockApps();for(int i=0;i<d.size();i++)if(d.get(i).id.equals(app.id))glass.selected=i;
                    glass.notifyText("Влево / вправо — переместить, OK — сохранить");break;
                case 3:edit("Название приложения",store.label(app),value->{if(!value.isEmpty())store.put("label."+app.id,value);glass.refresh();});break;
                case 4:changeIcon(app);break;
                case 5:store.hide(app.id,true);glass.refresh();glass.notifyText("Приложение скрыто. Вернуть можно в настройках.");break;
                case 6:system(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+app.id)));break;
                case 7:uninstall(app);break;
            }
        });
    }
    void uninstall(AppEntry app){
        if(app.system){glass.notifyText("Системное приложение: откроются его настройки");system(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.fromParts("package",app.id,null)));return;}
        if(AppUninstaller.request(app.id,this::startActivityForResult)){
            pendingUninstall=app.id;pendingUninstallLabel=store.label(app);catalogDirty=true;return;
        }
        info("Не удалось открыть удаление","Прошивка не открыла системное окно удаления. Нажмите «Открыть» и выберите «Удалить» в сведениях о приложении.",()->uninstallDetails(app));
    }
    void uninstallDetails(AppEntry app){
        try{
            startActivityForResult(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.fromParts("package",app.id,null)),AppUninstaller.DETAILS);
            pendingUninstall=app.id;pendingUninstallLabel=store.label(app);catalogDirty=true;
        }catch(RuntimeException ex){glass.notifyText("Откройте настройки ТВ → Приложения → "+store.label(app)+" → Удалить");}
    }
    void verifyUninstall(String id){
        if(destroyed||!id.equals(pendingUninstall))return;
        try{
            getPackageManager().getApplicationInfo(id,0);
            pendingUninstall="";pendingUninstallLabel="";
            glass.notifyText("Приложение осталось установлено");
        }catch(android.content.pm.PackageManager.NameNotFoundException removed){uninstallConfirmed(id);}
        catch(RuntimeException unavailable){pendingUninstall="";pendingUninstallLabel="";glass.notifyText("Не удалось проверить удаление. Обновляю список приложений.");}
        catalogDirty=true;reloadApps();
    }
    void uninstallConfirmed(String id){
        if(!id.equals(pendingUninstall))return;
        String name=pendingUninstallLabel;pendingUninstall="";pendingUninstallLabel="";
        List<AppEntry> remaining=new ArrayList<>(applications);remaining.removeIf(a->a.id.equals(id));applications=remaining;
        watchCards=new ArrayList<>(watchCards);watchCards.removeIf(card->card.app.id.equals(id));customIcons.remove(id);
        glass.setApps(remaining);glass.notifyText((name.isEmpty()?"Приложение":name)+" удалено");
    }
    void changeIcon(AppEntry app){
        choice("Значок: "+store.label(app),new String[]{"Оригинальный значок","Буквы на цветной плитке","Выбрать картинку из файла"},index->{
            if(index==2){pendingIcon=app.id;pick(PICK_ICON);return;}
            store.put("icon."+app.id,"");store.put("initials."+app.id,index==1);customIcons.remove(app.id);glass.invalidate();
        });
    }
    void hiddenApps(){
        List<AppEntry> hidden=new ArrayList<>();for(AppEntry app:applications)if(store.hidden(app.id))hidden.add(app);
        if(hidden.isEmpty()){glass.notifyText("Скрытых приложений нет");return;}
        String[] labels=new String[hidden.size()];for(int i=0;i<labels.length;i++)labels[i]="Показать: "+store.label(hidden.get(i));
        choice("Скрытые приложения",labels,index->{store.hide(hidden.get(index).id,false);glass.refresh();});
    }
    void profiles(){
        List<String> ids=store.profiles();String[] labels=new String[ids.size()+2];
        for(int i=0;i<ids.size();i++)labels[i]=(ids.get(i).equals(store.profile())?"✓  ":"")+store.profileName(ids.get(i));
        labels[ids.size()]="Добавить профиль";labels[ids.size()+1]="Переименовать текущий";
        choice("Профили",labels,index->{
            if(index<ids.size()){store.selectProfile(ids.get(index));profileChanged();}
            else if(index==ids.size())edit("Имя нового профиля","",value->{if(!value.isEmpty()){store.addProfile(value);profileChanged();}});
            else edit("Имя профиля",store.name(),value->{if(!value.isEmpty())store.put("name",value);glass.refresh();});
        });
    }
    void profileChanged(){store.migrateAmbientDesign();travelSaver.reset();if(!applications.isEmpty())store.seed(applications);customIcons.clear();loadCustomIcons();loadWallpaper();glass.setWeather(Weather.cached(store),false);weatherRetry.reset();watchCards=new ArrayList<>();glass.home();refreshWeather(false);refreshWatchNext(true);}
    void chooseCity(){
        String[] cities=new String[Weather.PLACES.length+1];
        for(int i=0;i<Weather.PLACES.length;i++)cities[i]=Weather.PLACES[i].city;
        cities[cities.length-1]="Свой город по координатам";
        choice("Город для погоды",cities,index->{
            if(index<Weather.PLACES.length){Weather.Place p=Weather.PLACES[index];setCity(p.city,p.latitude,p.longitude);}
            else edit("Название города",Weather.place(store).city,name->{if(name.isEmpty())return;edit("Широта",Weather.place(store).latitude,latitude->edit("Долгота",Weather.place(store).longitude,longitude->{
                try{double la=Double.parseDouble(latitude.replace(',','.')),lo=Double.parseDouble(longitude.replace(',','.'));if(!Double.isFinite(la)||!Double.isFinite(lo)||la< -90||la>90||lo< -180||lo>180)throw new NumberFormatException();setCity(name,Double.toString(la),Double.toString(lo));}
                catch(NumberFormatException ex){glass.notifyText("Неверные координаты. Город не изменён.");}
            }));});
        });
    }
    void setCity(String name,String latitude,String longitude){
        store.put("city",name);store.put("latitude",latitude);store.put("longitude",longitude);store.put("weatherZone","auto");
        Weather.Place place=Weather.place(store);
        store.put("latitude",place.latitude);store.put("longitude",place.longitude);store.put("weatherZone",place.zone);
        weatherRetry.reset();glass.setWeather(Weather.cached(store),false);refreshWeather(true);glass.invalidate();
    }

    void prayerSettings(){glass.open(GlassView.Screen.SETTINGS);glass.category=8;glass.settingIndex=0;glass.settingsRight=true;glass.refresh();}
    void importPrayers(){
        try{startActivityForResult(new Intent(this,SajdaImportActivity.class),IMPORT_PRAYERS);}
        catch(RuntimeException ex){glass.notifyText("Не удалось открыть Sajda. Проверьте Android System WebView в настройках ТВ.");}
    }
    String prayerDescription(){
        PrayerTimes.Display value=prayers.display(glass.now());
        if(value==null)return "На сегодня нет расписания. Откройте «Обновить из Sajda».\n\n"+prayers.coverage();
        StringBuilder text=new StringBuilder("Махачкала · "+PrayerTimes.format("d MMMM yyyy").format(PrayerTimes.parseDate(value.day.date))+"\n");
        for(int i=0;i<6;i++)text.append("\n").append(PrayerTimes.LABELS[i]).append("   ").append(value.day.times[i]).append(i==value.active?"   ●":"");
        text.append("\n\nИсточник: Sajda.com. Метод: Махачкала. Аср: стандартный. Часовой пояс: Москва (UTC+3).\nЗелёный — текущий намаз; восход не подсвечивается.");
        if(value.previousNight)text.append("\nДо Фаджра показана Иша и расписание предыдущего дня.");
        return text.toString();
    }

    static final class SettingRow {
        final String title,detail;final Runnable action;
        SettingRow(String title,String detail,Runnable action){this.title=title;this.detail=detail;this.action=action;}
    }
    List<SettingRow> rows(int category){
        ArrayList<SettingRow> r=new ArrayList<>();
        switch(category){
            case 0:
                r.add(row("Оформление как в видео",glass.ambient()?"Цвета приложений · прямоугольные плитки":glass.couch()?"Couch TV: стеклянные часы и пейзажи":"Прежний Bravia Glass",this::chooseScene));
                r.add(row("Своё фото / прежний вид",sceneName(),()->choice("Фон и сцена",new String[]{"Туманный лес","Ночной лес","Тёплый свет","Выбрать фото из файла","Вернуть исходный фон"},i->{if(i==3){pick(PICK_WALLPAPER);return;}store.put("look","classic");if(i==4){store.put("wallpaper","");store.put("scene","forest");loadWallpaper();}else store.put("scene",new String[]{"forest","night","warm"}[i]);glass.refresh();})));
                r.add(row("Размер часов",store.number("clockSize",100)+"%",()->choice("Размер часов",new String[]{"Компактные — 80%","Как в макете — 100%","Крупные — 120%"},i->{store.put("clockSize",new int[]{80,100,120}[i]);glass.refresh();})));
                r.add(toggle("Показывать часы","showClock",true));
                r.add(toggle("Белый текст часов","lightText",false));
                r.add(row("Размер иконок",store.number("dockSize",100)+"%",()->choice("Размер иконок",new String[]{"Обычные","Крупные"},i->{store.put("dockSize",i==0?100:120);glass.refresh();})));
                r.add(row("Затемнение фона",store.number("darkness",0)==0?"Выключено":Math.round(store.number("darkness",0)/255f*100)+"%",()->choice("Затемнение",new String[]{"Нет","Небольшое — 20%","Среднее — 40%","Сильное — 60%"},i->{store.put("darkness",new int[]{0,51,102,153}[i]);glass.refresh();})));
                r.add(toggle("Анимация выделения","animations",true));
                r.add(toggle("Формат времени 24 часа","clock24",true));
                r.add(toggle("Адаптивная подсветка приложений","ambientColors",true));
                r.add(row("Интенсивность подсветки",store.number("ambientStrength",100)+"%",()->choice("Подсветка фона",new String[]{"Мягкая — 70%","Как в макете — 100%","Яркая — 130%"},i->{store.put("ambientStrength",new int[]{70,100,130}[i]);glass.refresh();})));break;
            case 1:
                r.add(row("Все приложения",applications.size()+" установлено",()->glass.open(GlassView.Screen.APPS)));
                r.add(row("Настроить нижнюю панель","Удерживайте OK на приложении: добавить, убрать, переместить",()->info("Нижняя панель","Откройте «Все приложения». Удерживайте OK на нужном приложении и выберите «Добавить на нижнюю панель». Для изменения порядка выберите «Переместить на панели», затем используйте стрелки и OK.",null)));
                r.add(row("Продолжить просмотр",WatchNextRepository.allowed(this)?"Есть доступ к списку Android TV":"Разрешить чтение списка просмотра Android TV",this::requestWatchNext));
                r.add(toggle("Показывать продолжение просмотра","useWatchNext",true));
                r.add(toggle("Недавно открытые на главном экране","showRecents",true));
                r.add(row("Очистить недавно открытые","Только история запуска приложений",()->{store.list("recents",new ArrayList<>());glass.refresh();}));
                r.add(row("Скрытые приложения",store.list("hidden").size()+" скрыто",this::hiddenApps));
                r.add(row("Обновить список","Найти недавно установленные приложения",()->{catalogDirty=true;reloadApps();glass.notifyText("Обновление списка приложений…");}));
                r.add(row("Сбросить порядок и скрытие","Только для текущего профиля",()->confirm("Сбросить панель?","Порядок приложений и список скрытых будут сброшены для этого профиля.",()->{store.resetLayout();store.seed(applications);glass.refresh();})));
                break;
            case 2:
                r.add(row("Текущий профиль",store.name(),this::profiles));
                r.add(row("Имя в приветствии",store.name(),()->edit("Ваше имя",store.name(),name->{if(!name.isEmpty())store.put("name",name);glass.refresh();})));
                r.add(row("Добавить профиль","Свои приложения, подписи, фон и оформление",()->edit("Имя профиля","",name->{if(!name.isEmpty()){store.addProfile(name);profileChanged();}})));break;
            case 3:
                r.add(toggle("Показывать погоду","showWeather",true));
                r.add(row("Город",Weather.place(store).city,this::chooseCity));
                r.add(row("Обновить сейчас","Раз в 30 минут; при ошибке повтор через 30 секунд",()->refreshWeather(true)));
                r.add(row("Прогноз погоды","До 5 дней: температура и состояние неба",()->{glass.open(GlassView.Screen.WEATHER);refreshWeather(false);}));
                r.add(row("Положение погоды · прежний вид",store.text("weatherPosition","under_clock").equals("under_clock")?"Под часами слева":"Вверху справа",()->choice("Положение погоды",new String[]{"Под часами слева","Вверху справа"},i->{store.put("weatherPosition",i==0?"under_clock":"top_right");glass.refresh();})));
                r.add(toggle("Фон погоды · прежний вид","weatherBackground",false));
                r.add(row("Источник погоды","Open-Meteo.com + резерв wttr.in",()->info("Погода","Основной источник: Open-Meteo.com (CC BY 4.0). Если он недоступен, используется wttr.in с прогнозом на 3 дня. Передаются только выбранные координаты города. Геолокация не запрашивается. Без сети показываются сохранённые данные и отметка времени. При ошибке выполняются автоматические повторные попытки.",null)));break;
            case 4:
                r.add(row("Назначить главным экраном","Выбрать Bravia Glass для кнопки HOME",this::defaultHome));
                r.add(row("Системные настройки ТВ","Wi-Fi, звук, экран и приложения",()->system(new Intent(Settings.ACTION_SETTINGS))));
                r.add(row("Штатный главный экран","Открыть другой установленный лаунчер",this::otherHomes));
                r.add(row("О кнопке HOME на Sony","Поведение зависит от прошивки телевизора",()->info("Кнопка HOME","Bravia Glass зарегистрирован как главный экран Android. Если прошивка Sony разрешает выбор, назначьте его через «Назначить главным экраном». Некоторые прошивки сохраняют штатный лаунчер для HOME. Проверка именно на телевизоре обязательна. Автоматического отключения системных пакетов в этой версии нет.",null)));break;
            case 5:
                r.add(row("Заставка при бездействии",store.number("idleMinutes",10)==0?"Отключена":"Через "+store.number("idleMinutes",10)+" мин",()->choice("Заставка при бездействии",new String[]{"Отключить","Через 5 минут","Через 10 минут","Через 20 минут","Через 30 минут"},i->{store.put("idleMinutes",new int[]{0,5,10,20,30}[i]);lastInteraction=SystemClock.elapsedRealtime();glass.refresh();})));
                r.add(row("Таймер заставки",timerLabel(),this::timer));
                r.add(row("Фотографии заставки",TravelCatalog.categoryName(store.text("saverCategory","all")),()->choice("Фотографии заставки",new String[]{"Природа и города","Только природа","Города и достопримечательности"},i->{store.put("saverCategory",new String[]{"all","nature","cities"}[i]);travelSaver.reset();glass.refresh();})));
                r.add(row("Смена фотографий","Каждые "+TravelCatalog.intervalSeconds(store.number("saverSeconds",60))+" сек",()->choice("Смена фотографий",new String[]{"30 секунд","1 минута","2 минуты","5 минут"},i->{store.put("saverSeconds",new int[]{30,60,120,300}[i]);glass.refresh();})));
                r.add(toggle("Погода на заставке","saverWeather",true));
                r.add(row("Показать заставку","Фотографии мира · часы · дата · погода",()->screensaver(false)));
                r.add(row("Чёрный экран","Возврат любой кнопкой · телевизор остаётся включён",()->screensaver(true)));
                r.add(row("Сон и заставка телевизора","Открыть системный раздел",()->system(new Intent(Settings.ACTION_DREAM_SETTINGS),new Intent("android.settings.SLEEP_SETTINGS"))));break;
            case 6:
                r.add(row("Как пользоваться пультом","Стрелки, OK, удержание OK и кнопка Назад",()->info("Управление","Влево / вправо — выбор приложения. OK — запуск. Удержание OK или кнопка меню — действия с приложением. Вверх — верхние кнопки. Вниз — все приложения. Назад — главный экран. В настройках стрелки влево / вправо переключают разделы и параметры. Громкость регулируется обычными кнопками пульта.",null)));
                r.add(row("Пункт управления","Wi-Fi, Bluetooth, память, звук и входы",()->glass.open(GlassView.Screen.CONTROL)));
                r.add(row("Входы телевизора","HDMI и телевидение",this::inputs));break;
            case 8:
                r.add(toggle("Виджет времени намаза","showPrayer",true));
                r.add(row("Расписание · Махачкала","Sajda · местное время UTC+3",()->info("Время намаза",prayerDescription(),null)));
                r.add(row("Обновить из Sajda",prayers.coverage(),this::importPrayers));
                r.add(row("Вид виджета намаза",glass.prayersAtTop()?"Вверху по центру · только текст · на 40% меньше":"Прежняя карточка над панелью",()->choice("Вид намазов",new String[]{"Вверху по центру · без фона · меньше на 40%","Прежняя карточка над панелью"},i->{store.put("prayerLayout",i==0?"top_text":"shelf_card");glass.refresh();})));
                r.add(row("Как обновить расписание","Открыть месяц → «Показать все» → «Сохранить месяц»",()->info("Расписание Sajda","Виджет использует опубликованную таблицу Sajda для Махачкалы. Проверенное расписание за ноябрь и декабрь 2026 уже сохранено. Для следующего месяца откройте «Обновить из Sajda», дождитесь таблицы и нажмите на странице «Показать все», затем сверху «Сохранить месяц».\n\nМетод должен оставаться «Махачкала», Аср — «Стандартный». Настройки Sajda на телефоне автоматически не считываются. Без расписания на нужную дату виджет предложит обновление.\n\nВверх с панели — недавно открытые приложения, затем виджет намаза и верхние кнопки. Если недавно открытых нет, сразу выбирается намаз. OK на виджете — настройки.",null)));break;
            default:
                r.add(row("Bravia Glass "+UpdateManager.installedVersion(this),"Нативный лаунчер для Android TV · создан для Усмана",()->info("Bravia Glass "+UpdateManager.installedVersion(this),"Самостоятельное приложение, созданное с нуля по согласованному макету. На панели показываются реальные установленные приложения. Работает без аккаунта и рекламы. Сеть нужна для погоды и обновления расписания Sajda. Пакет: com.usman.braviaglass.",null)));
                r.add(row("Обновить BraviaGlass","Проверить новую версию или выбрать APK",this::updateOptions));
                r.add(row("Телевизор",Build.MANUFACTURER+" "+Build.MODEL+" · Android "+Build.VERSION.RELEASE,()->info("Устройство",Build.MANUFACTURER+" "+Build.MODEL+"\nAndroid "+Build.VERSION.RELEASE+" (API "+Build.VERSION.SDK_INT+")\n"+networkLabel()+"\n"+memoryLabel(),null)));
                r.add(row("Сцены и оформление Couch TV","Seagey · MIT · исходные сцены из видеореференса",()->info("Оформление","Сцены, шрифт Antonio и геометрия часов взяты из открытого проекта Couch TV: github.com/Seagey/couch-tv (c) 2026 Seagey, MIT. Здесь они отрисовываются нативно в Bravia Glass. Полный текст лицензии включён в приложение. Пульт на телефоне, Claude и мост Couch TV в эту версию не входят.",null)));
                r.add(row("Открыть системные сведения","Версия прошивки и параметры устройства",()->system(new Intent(Settings.ACTION_DEVICE_INFO_SETTINGS))));break;
        }
        return r;
    }
    private final UpdateManager.Listener updateListener=new UpdateManager.Listener(){
        public void message(String text){handler.post(()->{if(!destroyed)glass.notifyText(text);});}
        public void error(String text){handler.post(()->{if(!destroyed)info("Обновление BraviaGlass",text,null);});}
        public void newer(UpdateManager.Release release){handler.post(()->{if(destroyed)return;
            AlertDialog dialog=new AlertDialog.Builder(MainActivity.this).setTitle("Доступна BraviaGlass "+release.version)
              .setMessage("Скачать официальную сборку и установить поверх текущей? Все настройки и избранное останутся на телевизоре.")
              .setPositiveButton("Скачать",(d,w)->{glass.notifyText("Загружаю обновление…");workers.execute(()->UpdateManager.download(MainActivity.this,release,updateListener));})
              .setNegativeButton("Отмена",null).create();style(dialog);
        });}
        public void prepared(File apk){handler.post(()->{if(destroyed)return;
            AlertDialog dialog=new AlertDialog.Builder(MainActivity.this).setTitle("APK проверен")
              .setMessage("Версия новее, пакет и цифровая подпись совпадают с установленным BraviaGlass. Установить обновление? Android TV запросит подтверждение. Настройки сохранятся.")
              .setPositiveButton("Установить",(d,w)->installPrepared(apk))
              .setNegativeButton("Позже",null).create();style(dialog);
        });}
    };

    void updateOptions(){
        choice("Обновление BraviaGlass",new String[]{"Проверить обновление онлайн","Выбрать APK из файлов телевизора"},i->{
            if(i==0){glass.notifyText("Проверяю версию в GitHub Releases…");workers.execute(()->UpdateManager.checkOnline(this,updateListener));}
            else{
                Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/vnd.android.package-archive");
                try{startActivityForResult(pick,PICK_UPDATE_APK);}catch(RuntimeException ex){
                    try{startActivityForResult(new Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE),PICK_UPDATE_APK);}
                    catch(RuntimeException noPicker){info("Нет файлового менеджера","На телевизоре не найден выбор файлов. Установите файловый менеджер или передайте APK на ТВ.",null);}
                }
            }
        });
    }
    void installPrepared(File file){
        if(!UpdateManager.canInstall(this)){
            info("Разрешение Android TV","Разрешите установку приложений из BraviaGlass. После возврата установка продолжится.",()->{
                try{awaitingUpdatePermission=true;startActivityForResult(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+getPackageName())),UPDATE_PERMISSION);}
                catch(RuntimeException ex){awaitingUpdatePermission=false;info("Установка","В настройках телевизора разрешите установку приложений из BraviaGlass.",null);}
            });return;
        }
        try{glass.notifyText("Передаю обновление Android TV…");workers.execute(()->{
            try{UpdateManager.install(this,file);}catch(Exception ex){updateListener.error("Не удалось установить APK: "+ex.getMessage());}
        });}catch(RuntimeException ex){info("Ошибка",ex.getMessage(),null);}
    }
    @SuppressWarnings("deprecation")
    void installResult(Intent intent){
        String expected=getSharedPreferences(UpdateManager.TOKEN_PREFERENCES,MODE_PRIVATE).getString(UpdateManager.TOKEN_KEY,"");
        if(expected.isEmpty()||!expected.equals(intent.getStringExtra(UpdateManager.TOKEN_EXTRA)))return;
        int status=intent.getIntExtra(android.content.pm.PackageInstaller.EXTRA_STATUS,Integer.MIN_VALUE);
        if(status!=android.content.pm.PackageInstaller.STATUS_PENDING_USER_ACTION)
            getSharedPreferences(UpdateManager.TOKEN_PREFERENCES,MODE_PRIVATE).edit().remove(UpdateManager.TOKEN_KEY).apply();
        if(status==android.content.pm.PackageInstaller.STATUS_PENDING_USER_ACTION){
            Intent confirm=(Intent)intent.getParcelableExtra(Intent.EXTRA_INTENT);
            if(confirm!=null){try{startActivity(confirm);}catch(RuntimeException ex){info("Установка","Не удалось открыть подтверждение Android TV.",null);}}
        }else if(status==android.content.pm.PackageInstaller.STATUS_SUCCESS){
            glass.notifyText("BraviaGlass успешно обновлён");
            UpdateManager.cacheApk(this).delete();
        }else{
            String detail=intent.getStringExtra(android.content.pm.PackageInstaller.EXTRA_STATUS_MESSAGE);
            info("Обновление не установлено",detail==null?"Android TV отклонил установку.":detail,null);
        }
    }

    SettingRow row(String title,String detail,Runnable action){return new SettingRow(title,detail,action);}
    SettingRow toggle(String title,String key,boolean fallback){return row(title,store.bool(key,fallback)?"Включено":"Выключено",()->{store.put(key,!store.bool(key,fallback));glass.refresh();if(key.equals("showWeather")&&store.bool(key,fallback)){weatherRetry.reset();refreshWeather(true);}});}
    String sceneName(){return !store.text("wallpaper","").isEmpty()?"Своя фотография":store.text("scene","forest").equals("night")?"Ночной лес":store.text("scene","forest").equals("warm")?"Тёплый свет":"Туманный лес";}
    void otherHomes(){
        List<android.content.pm.ResolveInfo> found=getPackageManager().queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),0);
        List<android.content.pm.ResolveInfo> candidates=new ArrayList<>();for(android.content.pm.ResolveInfo r:found)if(r.activityInfo!=null&&!getPackageName().equals(r.activityInfo.packageName)&&r.activityInfo.exported)candidates.add(r);
        if(candidates.isEmpty()){system(new Intent(Settings.ACTION_HOME_SETTINGS));return;}
        String[] labels=new String[candidates.size()];for(int i=0;i<labels.length;i++)labels[i]=candidates.get(i).loadLabel(getPackageManager()).toString();
        choice("Открыть главный экран",labels,i->{android.content.pm.ActivityInfo a=candidates.get(i).activityInfo;system(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).setComponent(new ComponentName(a.packageName,a.name)));});
    }

    interface Selection{void selected(int index);}
    interface TextValue{void value(String value);}
    void choice(String title,String[] labels,Selection action){
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(title).setItems(labels,(d,i)->{action.selected(i);glass.refresh();}).setNegativeButton("Назад",null).create();style(dialog);
    }
    void info(String title,String message,Runnable action){AlertDialog dialog=new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton(action==null?"Понятно":"Открыть",(d,w)->{if(action!=null)action.run();}).setNegativeButton(action==null?null:"Назад",null).create();style(dialog);}
    void confirm(String title,String message,Runnable action){AlertDialog dialog=new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("Сбросить",(d,w)->action.run()).setNegativeButton("Отмена",null).create();style(dialog);}
    void edit(String title,String initial,TextValue action){
        EditText input=new EditText(this);input.setText(initial);input.setSingleLine(true);input.setSelectAllOnFocus(true);input.setTextColor(GlassView.WHITE);input.setTextSize(20);input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(60)});
        LinearLayout layout=new LinearLayout(this);int pad=Math.round(24*getResources().getDisplayMetrics().density);layout.setPadding(pad,0,pad,0);layout.addView(input,new LinearLayout.LayoutParams(-1,-2));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(title).setView(layout).setPositiveButton("Сохранить",(d,w)->{action.value(input.getText().toString().trim());glass.refresh();}).setNegativeButton("Отмена",null).create();style(dialog);
        input.requestFocus();
    }
    void style(AlertDialog dialog){
        dialog.show();Window window=dialog.getWindow();if(window!=null){
            GradientDrawable bg=new GradientDrawable();bg.setColor(0xf51c3447);bg.setCornerRadius(24*getResources().getDisplayMetrics().density);bg.setStroke(1,0x554d738e);window.setBackgroundDrawable(bg);
            int width=Math.min(Math.round(640*getResources().getDisplayMetrics().density),Math.round(getResources().getDisplayMetrics().widthPixels*0.86f));window.setLayout(width,WindowManager.LayoutParams.WRAP_CONTENT);
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }
    void pick(int request){
        pendingProfile=store.profile();Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*");
        try{startActivityForResult(intent,request);}catch(RuntimeException ex){glass.notifyText("На телевизоре нет выбора файлов. Установите файловый менеджер.");}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==PICK_UPDATE_APK){if(result==RESULT_OK&&data!=null&&data.getData()!=null){Uri uri=data.getData();workers.execute(()->UpdateManager.importLocal(this,uri,updateListener));}return;}
        if(request==UPDATE_PERMISSION){if(awaitingUpdatePermission&&UpdateManager.canInstall(this)){awaitingUpdatePermission=false;installPrepared(UpdateManager.cacheApk(this));}else awaitingUpdatePermission=false;return;}
        if(request==IMPORT_PRAYERS){if(result==RESULT_OK){prayers=new PrayerTimes(this,store.prefs);glass.refresh();glass.notifyText("Расписание Sajda сохранено");}return;}
        if(request==AppUninstaller.REQUEST||request==AppUninstaller.DETAILS){
            catalogDirty=true;reloadApps();
            if(!pendingUninstall.isEmpty()){String id=pendingUninstall;handler.postDelayed(()->verifyUninstall(id),700);}
            return;
        }
        if((request!=PICK_WALLPAPER&&request!=PICK_ICON)||result!=RESULT_OK||data==null||data.getData()==null)return;
        final Uri uri=data.getData();final String iconId=pendingIcon,profile=pendingProfile;
        glass.notifyText("Загружаю изображение…");
        workers.execute(()->{
            File temp=null;String name="";boolean success=false;
            try{
                temp=File.createTempFile("image-import-",".tmp",getCacheDir());
                try(InputStream in=getContentResolver().openInputStream(uri);FileOutputStream out=new FileOutputStream(temp)){
                    if(in==null)throw new IOException("Cannot open image");byte[] buf=new byte[16384];int n,total=0;
                    while((n=in.read(buf))!=-1){total+=n;if(total>25*1024*1024)throw new IOException("Image is too large");out.write(buf,0,n);}
                }
                Bitmap image=decode(temp,request==PICK_ICON?192:2560,request==PICK_ICON?192:1440);
                if(image==null)throw new IOException("Invalid image");
                name="image-"+UUID.randomUUID().toString()+".png";
                try(FileOutputStream out=new FileOutputStream(new File(getFilesDir(),name))){success=image.compress(Bitmap.CompressFormat.PNG,100,out);}
                image.recycle();
            }catch(Exception ignored){}finally{if(temp!=null)temp.delete();}
            final boolean ok=success;final String saved=name;
            handler.post(()->{
                if(destroyed)return;
                if(!ok){glass.notifyText("Не удалось открыть изображение. Выберите JPG или PNG до 25 МБ.");return;}
                if(!profile.equals(store.profile())){glass.notifyText("Профиль изменён. Выберите изображение ещё раз.");return;}
                if(request==PICK_WALLPAPER){store.put("wallpaper",saved);store.put("look","classic");loadWallpaper();}
                else{store.put("icon."+iconId,saved);store.put("initials."+iconId,false);loadCustomIcons();}
                glass.notifyText("Изображение сохранено");
            });
        });
    }
}
