package com.usman.braviaglass;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Locale;

/** On-demand updates. Does not touch the profiles, layout or other user preferences. */
final class UpdateManager {
    static final String INSTALL_ACTION = "com.usman.braviaglass.INSTALL_RESULT";
    // Owned by the BraviaGlass developer. Publish future signed APKs as GitHub Release assets.
    static final String RELEASE_API = "https://api.github.com/repos/Usmanhalu/tvlauncher/releases/latest";
    private static final int MAX_APK_SIZE = 150 * 1024 * 1024;
    static final String CACHE_APK = "braviaglass-pending-update.apk";
    static final String TOKEN_PREFERENCES="braviaglass_installer";
    static final String TOKEN_KEY="pending_token";
    static final String TOKEN_EXTRA="com.usman.braviaglass.INSTALL_TOKEN";

    interface Listener {
        void message(String status);
        void error(String message);
        void newer(Release release);
        void prepared(File apk);
    }

    static final class Release {
        final String version, url, sha256;
        Release(String version, String url, String sha256) {
            this.version=version; this.url=url; this.sha256=sha256;
        }
    }

    static File cacheApk(Context context) { return new File(context.getCacheDir(),CACHE_APK); }

    static String installedVersion(Context context) {
        try { return context.getPackageManager().getPackageInfo(context.getPackageName(),0).versionName; }
        catch (Exception e) { return "неизвестна"; }
    }

    static void checkOnline(Context context, Listener listener) {
        try {
            JSONObject json=readJson(RELEASE_API);
            if(json.optBoolean("draft",false) || json.optBoolean("prerelease",false))
                throw new IllegalArgumentException("Опубликован только предварительный релиз");
            String version=json.optString("tag_name","").replaceFirst("^[vV]","");
            if(!newer(version,installedVersion(context))) {
                listener.message("Установлена актуальная версия BraviaGlass «"+installedVersion(context)+"»");
                return;
            }
            JSONArray assets=json.optJSONArray("assets");
            if(assets==null) throw new IllegalArgumentException("В релизе нет APK");
            for(int i=0;i<assets.length();i++) {
                JSONObject asset=assets.optJSONObject(i);
                if(asset==null) continue;
                String name=asset.optString("name","");
                String url=asset.optString("browser_download_url","");
                if(!name.matches("(?i)BraviaGlass[-_].*\\.apk") || !safeReleaseUrl(url)) continue;
                long length=asset.optLong("size",0);
                if(length<=0 || length>MAX_APK_SIZE) continue;
                String digest=asset.optString("digest","");
                String sha=digest.matches("(?i)sha256:[0-9a-f]{64}")?digest.substring(7):"";
                listener.newer(new Release(version,url,sha));
                return;
            }
            throw new IllegalArgumentException("Релиз найден, но подходящий BraviaGlass APK отсутствует");
        } catch (java.io.FileNotFoundException e) {
            listener.error("Онлайн-обновления ещё не опубликованы. Можно выбрать APK из файлов телевизора.");
        } catch (Exception e) {
            listener.error("Не удалось проверить обновления: "+message(e));
        }
    }

    static boolean newer(String candidate, String current) {
        if(!candidate.matches("\\d+(\\.\\d+){1,3}") || !current.matches("\\d+(\\.\\d+){1,3}")) return false;
        String[] a=candidate.split("\\."), b=current.split("\\.");
        for(int i=0;i<Math.max(a.length,b.length);i++) {
            long x=i<a.length?Long.parseLong(a[i]):0, y=i<b.length?Long.parseLong(b[i]):0;
            if(x!=y)return x>y;
        }
        return false;
    }

    private static boolean safeReleaseUrl(String address) {
        try { URL url=new URL(address);return "https".equalsIgnoreCase(url.getProtocol()) && "github.com".equalsIgnoreCase(url.getHost()) && url.getPath().startsWith("/Usmanhalu/tvlauncher/releases/download/"); }
        catch(Exception e) {return false;}
    }

    private static JSONObject readJson(String address) throws Exception {
        HttpURLConnection conn=(HttpURLConnection)new URL(address).openConnection();
        try {
            conn.setConnectTimeout(10000);conn.setReadTimeout(12000);
            conn.setRequestProperty("Accept","application/vnd.github+json");
            conn.setRequestProperty("User-Agent","BraviaGlass-AndroidTV");
            int status=conn.getResponseCode();
            if(status==404)throw new java.io.FileNotFoundException("No release");
            if(status!=200)throw new java.io.IOException("Сервер вернул "+status);
            try(InputStream in=conn.getInputStream()) {
                byte[] bytes=readLimited(in,200000);
                return new JSONObject(new String(bytes,java.nio.charset.StandardCharsets.UTF_8));
            }
        } finally {conn.disconnect();}
    }

    static void download(Context context, Release release, Listener listener) {
        if(!safeReleaseUrl(release.url)){listener.error("Недопустимый адрес обновления");return;}
        File file=cacheApk(context);
        try {
            listener.message("Скачиваю BraviaGlass "+release.version+"…");
            HttpURLConnection conn=(HttpURLConnection)new URL(release.url).openConnection();
            try {
                conn.setConnectTimeout(15000);conn.setReadTimeout(30000);
                conn.setInstanceFollowRedirects(true);
                conn.setRequestProperty("User-Agent","BraviaGlass-AndroidTV");
                if(conn.getResponseCode()!=200)throw new java.io.IOException("Ошибка загрузки: "+conn.getResponseCode());
                int size=conn.getContentLength();
                if(size>MAX_APK_SIZE)throw new java.io.IOException("Слишком большой APK");
                MessageDigest hash=MessageDigest.getInstance("SHA-256");
                try(InputStream in=conn.getInputStream();OutputStream out=new FileOutputStream(file,false)) {
                    byte[] buf=new byte[32768];int n;long total=0;
                    while((n=in.read(buf))!=-1){total+=n;if(total>MAX_APK_SIZE)throw new java.io.IOException("Превышен размер APK");hash.update(buf,0,n);out.write(buf,0,n);}
                    if(total<10000)throw new java.io.IOException("Загруженный файл не похож на APK");
                }
                String actual=hex(hash.digest());
                if(!release.sha256.isEmpty()&&!release.sha256.equalsIgnoreCase(actual))throw new SecurityException("Контрольная сумма SHA-256 не совпадает");
                verifyArchive(context,file);
                listener.prepared(file);
            } finally {conn.disconnect();}
        } catch(Exception e){file.delete();listener.error("Обновление отменено: "+message(e));}
    }

    static void importLocal(Context context, Uri uri, Listener listener) {
        File file=cacheApk(context);
        try {
            listener.message("Проверяю выбранный APK…");
            try(InputStream in=context.getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(file,false)) {
                if(in==null)throw new java.io.IOException("Файл не открылся");
                byte[] buf=new byte[32768];int n;long total=0;
                while((n=in.read(buf))!=-1){total+=n;if(total>MAX_APK_SIZE)throw new java.io.IOException("APK слишком большой");out.write(buf,0,n);}
            }
            verifyArchive(context,file);
            listener.prepared(file);
        }catch(Exception e){file.delete();listener.error("APK не подходит: "+message(e));}
    }

    @SuppressWarnings("deprecation")
    static void verifyArchive(Context context,File apk) throws Exception {
        PackageManager pm=context.getPackageManager();
        final int flag=Build.VERSION.SDK_INT>=28?PackageManager.GET_SIGNING_CERTIFICATES:PackageManager.GET_SIGNATURES;
        PackageInfo candidate=pm.getPackageArchiveInfo(apk.getAbsolutePath(),flag);
        PackageInfo installed=pm.getPackageInfo(context.getPackageName(),flag);
        if(candidate==null||!context.getPackageName().equals(candidate.packageName))throw new SecurityException("Другой пакет приложения");
        long next=Build.VERSION.SDK_INT>=28?candidate.getLongVersionCode():candidate.versionCode;
        long old=Build.VERSION.SDK_INT>=28?installed.getLongVersionCode():installed.versionCode;
        if(next<=old)throw new IllegalArgumentException("Нужна версия новее установленной ("+installed.versionName+")");
        Signature[] a=signatures(candidate),b=signatures(installed);
        if(a==null||b==null||a.length!=1||b.length!=1||!Arrays.equals(a[0].toByteArray(),b[0].toByteArray()))
            throw new SecurityException("Подпись APK не совпадает с установленным BraviaGlass");
    }

    @SuppressWarnings("deprecation")
    private static Signature[] signatures(PackageInfo pkg) {
        if(Build.VERSION.SDK_INT>=28)return pkg.signingInfo==null?null:pkg.signingInfo.getApkContentsSigners();
        return pkg.signatures;
    }

    static boolean canInstall(Context context){return Build.VERSION.SDK_INT<26||context.getPackageManager().canRequestPackageInstalls();}

    static void install(Context context,File apk) throws Exception {
        verifyArchive(context,apk);
        if(!canInstall(context))throw new SecurityException("Разрешите установку из этого приложения в настройках Sony TV");
        PackageInstaller installer=context.getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams params=new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        params.setAppPackageName(context.getPackageName());
        int id=installer.createSession(params);
        PackageInstaller.Session session=null;
        try {
            session=installer.openSession(id);
            try(InputStream in=new java.io.FileInputStream(apk);OutputStream out=session.openWrite("base.apk",0,apk.length())){
                byte[] buffer=new byte[32768];int n;
                while((n=in.read(buffer))!=-1)out.write(buffer,0,n);
                session.fsync(out);
            }
            byte[] random=new byte[24];new java.security.SecureRandom().nextBytes(random);
            String token=hex(random);
            if(!context.getSharedPreferences(TOKEN_PREFERENCES,Context.MODE_PRIVATE).edit().putString(TOKEN_KEY,token).commit())
                throw new java.io.IOException("Не удалось сохранить токен установки");
            Intent callback=new Intent(context,MainActivity.class).setAction(INSTALL_ACTION)
                .putExtra(TOKEN_EXTRA,token)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
            int flags=PendingIntent.FLAG_UPDATE_CURRENT;
            if(Build.VERSION.SDK_INT>=31)flags|=PendingIntent.FLAG_MUTABLE;
            PendingIntent pending=PendingIntent.getActivity(context,801,callback,flags);
            session.commit(pending.getIntentSender());
        }catch(Exception e){context.getSharedPreferences(TOKEN_PREFERENCES,Context.MODE_PRIVATE).edit().remove(TOKEN_KEY).apply();installer.abandonSession(id);throw e;}
        finally{if(session!=null)session.close();}
    }

    private static byte[] readLimited(InputStream in,int max) throws Exception {
        java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();byte[] b=new byte[8192];int n;
        while((n=in.read(b))!=-1){if(out.size()+n>max)throw new java.io.IOException("Слишком большой ответ сервера");out.write(b,0,n);}
        return out.toByteArray();
    }
    private static String hex(byte[] bytes){StringBuilder s=new StringBuilder();for(byte b:bytes)s.append(String.format(Locale.ROOT,"%02x",b&255));return s.toString();}
    private static String message(Exception e){String m=e.getMessage();return m==null?e.getClass().getSimpleName():m;}
}
