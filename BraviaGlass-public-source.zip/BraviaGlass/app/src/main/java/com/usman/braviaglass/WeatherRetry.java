package com.usman.braviaglass;

/** Uses elapsed time, so changing the TV clock cannot suppress retries. */
final class WeatherRetry {
    long nextAttempt=0;
    int failures=0;
    boolean due(long now){return now>=nextAttempt;}
    void reset(){nextAttempt=0;failures=0;}
    void success(long now,long remainingFreshMs){failures=0;nextAttempt=now+Math.max(1000,remainingFreshMs);}
    void failure(long now){failures=Math.min(5,failures+1);nextAttempt=now+Math.min(300000,30000L<<(failures-1));}
}
