package com.usman.braviaglass;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.SystemClock;
import java.io.InputStream;
import java.util.Random;

/** Only two decoded Full HD photos are retained, and no network is used. */
final class TravelSaver {
    final MainActivity host;
    final TravelCatalog.Deck deck=new TravelCatalog.Deck(new Random());
    Bitmap current,previous;
    TravelCatalog.Photo photo;
    boolean active,loading;
    int generation;
    long changedAt,lastAttempt;
    TravelSaver(MainActivity host){this.host=host;}
    void prepare(){if(current==null&&!loading)load();}
    void start(){active=true;changedAt=SystemClock.uptimeMillis();prepare();}
    void stop(){active=false;previous=null;}
    void reset(){generation++;loading=false;current=null;previous=null;photo=null;lastAttempt=0;prepare();}
    void update(){
        if(!active||loading)return;
        long now=SystemClock.uptimeMillis();
        long interval=TravelCatalog.intervalSeconds(host.store.number("saverSeconds",60))*1000L;
        if((current==null||now-changedAt>=interval)&&(lastAttempt==0||now-lastAttempt>=3000))load();
    }
    void load(){
        if(host.destroyed||loading)return;
        loading=true;lastAttempt=SystemClock.uptimeMillis();
        int request=generation;
        TravelCatalog.Photo next=deck.next(host.store.text("saverCategory","all"));
        host.workers.execute(()->{
            Bitmap decoded=null;
            BitmapFactory.Options options=new BitmapFactory.Options();
            options.inPreferredConfig=Bitmap.Config.RGB_565;
            try(InputStream in=host.getAssets().open(next.asset)){
                decoded=BitmapFactory.decodeStream(in,null,options);
            }catch(Exception|OutOfMemoryError ignored){/* Retain the last good photograph. */}
            final Bitmap ready=decoded;
            host.handler.post(()->{
                if(host.destroyed||request!=generation){if(ready!=null)ready.recycle();return;}
                loading=false;
                if(ready==null)return;
                previous=active?current:null;current=ready;photo=next;changedAt=SystemClock.uptimeMillis();
                host.glass.invalidate();
            });
        });
    }
    float fade(){
        float fraction=Math.max(0,Math.min(1,(SystemClock.uptimeMillis()-changedAt)/1400f));
        if(fraction>=1)previous=null;
        return fraction;
    }
}
