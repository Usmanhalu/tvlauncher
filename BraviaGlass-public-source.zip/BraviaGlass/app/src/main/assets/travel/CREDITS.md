# Photographs for Bravia Glass travel screensaver

Source: Unsplash. License: https://unsplash.com/license (checked 2026-11-14).

The Unsplash License permits downloading, modifying, distributing and using these photographs, including commercial use. The photos are bundled within this launcher for its offline screensaver. They are not offered as a stock-photo service. Photographer attribution is appreciated by Unsplash but is not required. All images below are public Unsplash CDN photographs, not Unsplash+ assets.

Each image was requested with auto=format, fit=crop, w=1920, h=1080, q=85. Verified JPEG / 1920×1080. Names without a verified exact location use descriptive landscape labels.

| Local file | Source photograph | SHA-256 |
| --- | --- | --- |
| paris.jpg | https://images.unsplash.com/photo-1502602898657-3e91760cbb34 | e643394ff57cf686e05514cd20786e0ad7da9930f42e453edde6d5fdb9f4e400 |
| london.jpg | https://images.unsplash.com/photo-1513635269975-59663e0ac1ad | cdb0f9ce139d78cb940d3494811604e2f2729a0d40f45a3a189292b3d0470e35 |
| dubai.jpg | https://images.unsplash.com/photo-1512453979798-5ea266f8880c | fedbb6a671c1c921c340bb82b6a7d46f7f45f4c2e7b08a0243b69dcb19b8612d |
| newyork.jpg | https://images.unsplash.com/photo-1485871981521-5b1fd3805eee | f9c7022630931f1faa3d5bd40f23346ed7056cb2defa28e53874727219d13d56 |
| istanbul.jpg | https://images.unsplash.com/photo-1524231757912-21f4fe3a7200 | 024b4a01fa0a41a98868e2eb46872e4e8437362a60d481342e4cca6e74800a09 |
| santorini.jpg | https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e | 5fde762a1e0f6e699ae513ec07f382927a104e80a478c48b74e3ec9f2f732d45 |
| venice.jpg | https://images.unsplash.com/photo-1514890547357-a9ee288728e0 | 9c1fd513600dd423ac2acaa769d2c20fa8a4464162d25535c3695a7463db5311 |
| alpine-lake.jpg | https://images.unsplash.com/photo-1501785888041-af3ef285b470 | c195d708ffef3b4523625dd04a1535e2fc1c8602075ef378cf84f51581c921b1 |
| mountain.jpg | https://images.unsplash.com/photo-1464822759023-fed622ff2c3b | 529f2e6f96a16a5884b54ddb6df6156a4d799d02849cb01f73538a210d793b75 |
| lake.jpg | https://images.unsplash.com/photo-1470770841072-f978cf4d019e | e2f9f9154d7b86e4a3ff20dd1ae7c44c28f10cd692ae63568e2f00e320a91713 |
| night-mountain.jpg | https://images.unsplash.com/photo-1519681393784-d120267933ba | 182bcb285c85c0234e8325f8fc7bee3cdc8f28ee5ff046e7346fa78148e9e3b0 |
| fuji.jpg | https://images.unsplash.com/photo-1490806843957-31f4c9a91c65 | f36e5f62ba0bff1a57f109e4a85fef41e6eaff324b15eed5f1c301d4bc0a2322 |
