package com.usman.braviaglass;

import static org.junit.Assert.*;
import android.app.Activity;
import android.content.*;
import android.graphics.*;
import android.view.*;
import java.io.*;
import java.util.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,qualifiers="w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class PrayerFlowTest {
    ActivityController<MainActivity> controller;MainActivity host;GlassView view;TimeZone originalZone;
    @Before public void setup()throws Exception{
        originalZone=TimeZone.getDefault();TimeZone.setDefault(PrayerTimes.ZONE);
        MainActivity.disableNetworkForTests=true;RuntimeEnvironment.getApplication().getSharedPreferences("glass",0).edit().clear().commit();
        controller=Robolectric.buildActivity(MainActivity.class).create().start().resume().visible();host=controller.get();view=host.glass;host.store.put("look","couch");
        host.store.put("animations",false);host.store.put("idleMinutes",0);host.store.put("sceneMode","fixed");host.store.put("fixedScene","sunset");host.store.put("prayerLayout","shelf_card");
        for(int i=0;i<20;i++){Shadows.shadowOf(android.os.Looper.getMainLooper()).idle();Thread.yield();}
        view.setApps(LauncherTest.samples(9));host.applications=new ArrayList<>(view.apps);host.store.seed(view.apps);view.scenic.setFrame(SceneSet.load(host,"sunset"));
        view.nowOverride=PrayerTimesTest.wall("2026-11-13",17,50);
    }
    @After public void cleanup(){controller.pause().stop().destroy();MainActivity.disableNetworkForTests=false;TimeZone.setDefault(originalZone);}
    void press(int key){view.handleKey(new KeyEvent(KeyEvent.ACTION_DOWN,key));view.handleKey(new KeyEvent(KeyEvent.ACTION_UP,key));}
    Bitmap render(String name)throws IOException{
        view.measure(View.MeasureSpec.makeMeasureSpec(1920,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(1080,View.MeasureSpec.EXACTLY));view.layout(0,0,1920,1080);
        Bitmap b=Bitmap.createBitmap(1920,1080,Bitmap.Config.ARGB_8888);view.draw(new Canvas(b));
        if(name!=null){File f=new File("build/reports/screens/"+name+".png");f.getParentFile().mkdirs();try(FileOutputStream out=new FileOutputStream(f)){assertTrue(b.compress(Bitmap.CompressFormat.PNG,100,out));}}
        return b;
    }
    @Test public void legacyWidgetRendersActualIshaInGreenWithoutChangingClock()throws Exception{
        assertTrue(view.showPrayer());int clockTop=view.scenic.frame.clockTop,clockSize=host.store.number("clockSize",100);
        Bitmap b=render("prayers-sajda-isha");assertEquals(0xff079b75,b.getPixel(1500,760));assertNotEquals(0xff079b75,b.getPixel(240,760));assertTrue(view.hits.stream().anyMatch(h->h.action.equals("prayer")));b.recycle();
        view.nowOverride=PrayerTimesTest.wall("2026-11-13",6,37);b=render(null);for(int i=0;i<6;i++)assertNotEquals(0xff079b75,b.getPixel(220+i*253,760));b.recycle();
        assertEquals(clockTop,view.scenic.frame.clockTop);assertEquals(clockSize,host.store.number("clockSize",100));
    }
    @Test public void remoteCanReachWidgetRecentsSettingsAndReturn()throws Exception{
        host.store.list("recents",Arrays.asList(view.apps.get(0).id));press(KeyEvent.KEYCODE_DPAD_UP);assertTrue(view.prayerFocused);
        press(KeyEvent.KEYCODE_DPAD_UP);assertTrue(view.recentFocused);assertFalse(view.prayerFocused);Bitmap b=render(null);assertTrue(view.hits.stream().anyMatch(h->h.action.equals("recent")));b.recycle();
        press(KeyEvent.KEYCODE_DPAD_DOWN);assertTrue(view.prayerFocused);press(KeyEvent.KEYCODE_DPAD_CENTER);assertEquals(GlassView.Screen.SETTINGS,view.screen);assertEquals(8,view.category);
        b=render("prayers-settings");b.recycle();press(KeyEvent.KEYCODE_BACK);assertEquals(GlassView.Screen.HOME,view.screen);assertFalse(view.prayerFocused);
        host.rows(8).get(0).action.run();assertFalse(view.showPrayer());press(KeyEvent.KEYCODE_DPAD_UP);assertTrue(view.recentFocused);
    }
    @Test public void expiredCalendarAndClassicThemeRemainUsable()throws Exception{
        view.nowOverride=PrayerTimesTest.wall("2027-01-01",12,0);Bitmap b=render("prayers-expired");assertTrue(view.hits.stream().anyMatch(h->h.action.equals("prayer")));b.recycle();
        host.store.put("look","classic");view.nowOverride=PrayerTimesTest.wall("2026-11-13",14,9);b=render("prayers-classic");assertEquals(0xff079b75,b.getPixel(980,760));b.recycle();
        press(KeyEvent.KEYCODE_DPAD_UP);assertTrue(view.prayerFocused);press(KeyEvent.KEYCODE_DPAD_DOWN);assertFalse(view.prayerFocused);
    }
    @Test public void importerRequiresValidatedVisiblePageAndMainReloadsSavedData()throws Exception{
        ActivityController<SajdaImportActivity> importController=Robolectric.buildActivity(SajdaImportActivity.class).create().start().resume().visible();
        SajdaImportActivity importer=importController.get();
        org.json.JSONObject bad=new org.json.JSONObject().put("url",PrayerTimes.BASE+"2027-01").put("html",PrayerTimesTest.table("2027-01",7));
        importer.acceptResult(org.json.JSONObject.quote(bad.toString()));assertFalse(importer.isFinishing());assertTrue(importer.status.getText().toString().contains("Показать все"));
        org.json.JSONObject good=new org.json.JSONObject().put("url",PrayerTimes.BASE+"2027-01").put("html",PrayerTimesTest.table("2027-01",31));
        importer.acceptResult(org.json.JSONObject.quote(good.toString()));assertTrue(importer.isFinishing());assertEquals(Activity.RESULT_OK,Shadows.shadowOf(importer).getResultCode());
        host.onActivityResult(MainActivity.IMPORT_PRAYERS,Activity.RESULT_OK,new Intent());assertNotNull(host.prayers.days.get("2027-01-31"));
        importController.pause().stop().destroy();
    }
    @Test public void weatherCommandMovesWidgetUnderClockWithNoCardAndKeepsPrayerAndClock()throws Exception{
        host.store.put("look","classic");host.store.put("lightText",true);
        try(InputStream in=host.getAssets().open("forest.jpg")){Bitmap wallpaper=BitmapFactory.decodeStream(in);view.setWallpaper(wallpaper,MainActivity.blur(wallpaper));}
        host.store.put("showWeather",false);Bitmap empty=render(null);
        host.store.put("showWeather",true);view.setWeather(new Weather(12,3,view.now(),"Махачкала",Collections.emptyList()),false);
        new LayoutCommandReceiver().onReceive(host,new Intent(LayoutCommandReceiver.ACTION).putExtra("weather_position","under_clock").putExtra("weather_background",false));
        Bitmap clear=render("weather-under-clock");RectF box=view.homeWeatherBounds();
        assertEquals(66,box.left,0);assertTrue(box.top>366);assertTrue(box.bottom<650);
        assertEquals(empty.getPixel(566,(int)box.top+7),clear.getPixel(566,(int)box.top+7));
        for(int y=180;y<390;y+=11)for(int x=1330;x<1840;x+=11)assertEquals("Old weather card leaves no pixels",empty.getPixel(x,y),clear.getPixel(x,y));
        assertTrue(view.hits.stream().anyMatch(h->h.action.equals("clock")&&h.rect.equals(box)));
        assertTrue(view.hits.stream().anyMatch(h->h.action.equals("prayer")));
        host.store.put("weatherBackground",true);Bitmap backed=render(null);assertNotEquals(clear.getPixel(566,(int)box.top+7),backed.getPixel(566,(int)box.top+7));
        for(int size:new int[]{80,100,120}){host.store.put("clockSize",size);RectF r=view.homeWeatherBounds();assertTrue(r.top>354*size/100f+12);assertTrue(r.bottom<670);}
        host.store.put("showClock",false);assertEquals(174,view.homeWeatherBounds().top,0);
        empty.recycle();clear.recycle();backed.recycle();
    }
    @Test public void compactTopTextHasNoPanelAndDoesNotCoverGreetingIconsOrOldShelf()throws Exception{
        host.store.prefs.edit().remove(host.store.key("prayerLayout")).commit();assertTrue(view.prayersAtTop());
        host.store.put("look","classic");host.store.put("showPrayer",false);Bitmap empty=render(null);
        host.store.put("showPrayer",true);Bitmap drawn=render("prayers-top-text");RectF r=view.compactPrayerBounds();
        assertEquals(960,r.centerX(),0);assertEquals(924,r.width(),0);assertTrue(r.left>460);assertTrue(r.right<1472);assertTrue(r.bottom<128);
        assertEquals(empty.getPixel(510,80),drawn.getPixel(510,80));assertEquals(empty.getPixel(1419,80),drawn.getPixel(1419,80));
        for(int y=691;y<824;y+=7)for(int x=190;x<1730;x+=11)assertEquals("Old long panel is gone",empty.getPixel(x,y),drawn.getPixel(x,y));
        int green=0;for(int y=45;y<100;y++)for(int x=1268;x<1422;x++)if(drawn.getPixel(x,y)==0xff00ca89)green++;
        assertTrue("Active Isha remains green",green>20);assertTrue("Green text, no solid tile",green<1500);
        assertTrue(view.hits.stream().anyMatch(h->h.action.equals("prayer")&&h.rect.equals(r)));
        empty.recycle();drawn.recycle();
    }
    @Test public void topPrayersRemainVisibleWhileRecentsAreFocusedAndRemoteFollowsVerticalOrder()throws Exception{
        host.store.put("prayerLayout","top_text");host.store.list("recents",Arrays.asList(view.apps.get(0).id));
        press(KeyEvent.KEYCODE_DPAD_UP);assertTrue(view.recentFocused);Bitmap b=render(null);
        assertTrue(view.hits.stream().anyMatch(h->h.action.equals("prayer")));b.recycle();
        press(KeyEvent.KEYCODE_DPAD_UP);assertTrue(view.prayerFocused);press(KeyEvent.KEYCODE_DPAD_UP);assertTrue(view.topFocused);
        press(KeyEvent.KEYCODE_DPAD_DOWN);assertTrue(view.prayerFocused);press(KeyEvent.KEYCODE_DPAD_DOWN);assertTrue(view.recentFocused);
        press(KeyEvent.KEYCODE_DPAD_DOWN);assertFalse(view.recentFocused);assertFalse(view.prayerFocused);
    }
}
