package com.usman.braviaglass;

import static org.junit.Assert.*;
import android.content.*;
import android.graphics.*;
import android.database.*;
import android.net.Uri;
import org.robolectric.shadows.ShadowContentResolver;
import android.os.Looper;
import android.view.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,qualifiers="w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class SceneTest {
    ActivityController<MainActivity> controller;
    MainActivity host;
    GlassView view;
    @Before public void setup()throws Exception{
        MainActivity.disableNetworkForTests=true;
        RuntimeEnvironment.getApplication().getSharedPreferences("glass",0).edit().clear().commit();
        controller=Robolectric.buildActivity(MainActivity.class).create().start().resume().visible();host=controller.get();view=host.glass;host.store.put("look","couch");host.store.put("showPrayer",false);
        host.store.put("animations",false);host.store.put("idleMinutes",0);host.store.put("sceneMode","fixed");host.store.put("fixedScene","night");
        for(int i=0;i<20;i++){Shadows.shadowOf(Looper.getMainLooper()).idle();Thread.yield();}
        view.setApps(LauncherTest.samples(9));host.applications=new ArrayList<>(view.apps);host.store.seed(view.apps);
    }
    @After public void cleanup(){controller.pause().stop().destroy();MainActivity.disableNetworkForTests=false;}
    void press(int key){view.handleKey(new KeyEvent(KeyEvent.ACTION_DOWN,key));view.handleKey(new KeyEvent(KeyEvent.ACTION_UP,key));}
    @Test public void allOriginalScenesHaveMatchingDepthLayersAndRender()throws Exception{
        view.nowOverride=1794559920000L;
        view.setWeather(new Weather(9,3,view.now(),"Махачкала",Collections.emptyList()),false);
        host.store.list("recents",Arrays.asList(view.apps.get(0).id,view.apps.get(3).id));
        for(String id:SceneSet.IDS){
            SceneSet.Frame f=SceneSet.load(host,id);assertEquals(1920,f.photo.getWidth());assertEquals(ClockGlass.HEIGHT,f.glass.getHeight());
            if(!id.equals("water")){assertNotNull(f.foreground);assertTrue(f.foreground.hasAlpha());assertEquals(0,Color.alpha(f.foreground.getPixel(960,20)));}
            view.scenic.setFrame(f);render("couch-"+id);
        }
    }
    @Test public void sceneRotationAndFixedSelectionRespectSettings(){
        Store store=host.store;
        store.put("sceneMode","cycle");store.put("sceneSeconds",20);
        assertEquals("night",SceneSet.choose(store,Weather.PLACES[0],null,0,0));
        assertEquals("golden",SceneSet.choose(store,Weather.PLACES[0],null,0,20000));
        assertEquals("water",SceneSet.choose(store,Weather.PLACES[0],null,0,40000));
        assertEquals("sunset",SceneSet.choose(store,Weather.PLACES[0],null,0,100000));
        assertEquals("night",SceneSet.choose(store,Weather.PLACES[0],null,0,120000));
        store.put("sceneMode","fixed");store.put("fixedScene","water");assertEquals("water",SceneSet.choose(store,Weather.PLACES[0],null,0,999999));
    }
    @Test public void lakeMountainsCoverClockWithoutMovingOrResizingIt()throws Exception{
        SceneSet.Frame f=SceneSet.load(host,"water");view.nowOverride=1794559920000L;
        assertEquals(268,f.clockTop);assertEquals(420,f.fontSize);
        int preferredSize=host.store.number("clockSize",100);
        Bitmap visible=Bitmap.createBitmap(1920,1080,Bitmap.Config.ARGB_8888);
        Bitmap hidden=Bitmap.createBitmap(1920,1080,Bitmap.Config.ARGB_8888);
        host.store.put("showClock",true);view.scenic.scene(new Canvas(visible),f);
        host.store.put("showClock",false);view.scenic.scene(new Canvas(hidden),f);
        assertEquals("No clock pixels can appear on mountain slopes",0,differences(visible,hidden,1030,410,1210,560));
        assertTrue("Clock remains visible in the sky",differences(visible,hidden,1030,290,1210,335)>100);
        assertTrue("Original underwater effect remains",differences(visible,hidden,1030,594,1210,660)>100);
        assertEquals(preferredSize,host.store.number("clockSize",100));
        host.store.put("showClock",true);visible.recycle();hidden.recycle();
    }
    int differences(Bitmap a,Bitmap b,int left,int top,int right,int bottom){
        int n=0;for(int y=top;y<bottom;y++)for(int x=left;x<right;x++)if(a.getPixel(x,y)!=b.getPixel(x,y))n++;return n;
    }
    @Test public void glassGetsItsColourFromWallpaperPixels(){
        Bitmap warm=Bitmap.createBitmap(64,64,Bitmap.Config.ARGB_8888),cool=Bitmap.createBitmap(64,64,Bitmap.Config.ARGB_8888);
        warm.eraseColor(Color.rgb(135,65,48));cool.eraseColor(Color.rgb(45,100,150));
        Bitmap red=ClockGlass.make(warm,null),blue=ClockGlass.make(cool,null);
        int r=red.getPixel(128,72),b=blue.getPixel(128,72);
        assertTrue(Color.red(r)>Color.blue(r)+50);assertTrue(Color.blue(b)>Color.red(b)+50);
        assertTrue(Color.red(r)<245);assertTrue(Color.blue(b)<245);
        warm.recycle();cool.recycle();red.recycle();blue.recycle();
    }
    @Test public void sunsetKeepsClockGeometryAndMountainOcclusion()throws Exception{
        SceneSet.Frame night=SceneSet.load(host,"night"),sunset=SceneSet.load(host,"sunset");
        assertEquals(night.clockTop,sunset.clockTop);assertEquals(night.fontSize,sunset.fontSize);assertEquals(night.dateTop,sunset.dateTop);
        assertTrue(differences(night.glass,sunset.glass,50,20,200,70)>100);
        view.nowOverride=1794559920000L;
        Bitmap a=Bitmap.createBitmap(1920,1080,Bitmap.Config.ARGB_8888),b=Bitmap.createBitmap(1920,1080,Bitmap.Config.ARGB_8888);
        host.store.put("showClock",true);view.scenic.scene(new Canvas(a),sunset);
        host.store.put("showClock",false);view.scenic.scene(new Canvas(b),sunset);
        assertEquals(0,differences(a,b,900,410,1030,490));
        assertTrue(differences(a,b,590,190,850,310)>100);a.recycle();b.recycle();host.store.put("showClock",true);
    }
    @Test public void sunsetMigrationKeepsScaleAndRunsOnce(){
        host.store.prefs.edit().remove("look.glass.v112").commit();host.store.put("clockSize",115);
        SceneSet.migrate(host.store);assertEquals("sunset",host.store.text("fixedScene",""));assertEquals(115,host.store.number("clockSize",0));
        host.store.put("fixedScene","water");SceneSet.migrate(host.store);assertEquals("water",host.store.text("fixedScene",""));
    }
    @Test public void sunSyncDistinguishesNightDayAndOvercast()throws Exception{
        SimpleDateFormat date=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US);date.setTimeZone(TimeZone.getTimeZone("UTC"));
        assertEquals("night",SceneSet.sun(42.97782,47.50027,date.parse("2026-06-21 00:00").getTime(),0));
        assertEquals("water",SceneSet.sun(42.97782,47.50027,date.parse("2026-06-21 09:00").getTime(),0));
        assertEquals("fog",SceneSet.sun(42.97782,47.50027,date.parse("2026-06-21 09:00").getTime(),3));
    }
    @Test public void migrationKeepsWeatherFavoritesAndCustomWallpaper(){
        Store store=host.store;store.prefs.edit().remove("look.couch.v110").commit();
        store.put("city","Махачкала");store.put("wallpaper","custom.png");store.list("favorites",Arrays.asList("b","a"));
        SceneSet.migrate(store);assertEquals("couch",store.text("look",""));assertEquals(Arrays.asList("b","a"),store.list("favorites"));assertEquals("custom.png",store.text("wallpaper",""));assertEquals("Махачкала",Weather.place(store).city);
        store.put("look","classic");SceneSet.migrate(store);assertEquals("classic",store.text("look",""));
    }
    @Test public void couchDockAndRecentShelfWorkWithRemote()throws Exception{
        view.scenic.setFrame(SceneSet.load(host,"night"));render("couch-empty");
        view.selected=view.dockApps().size();press(KeyEvent.KEYCODE_DPAD_CENTER);assertEquals(GlassView.Screen.SETTINGS,view.screen);
        view.home();view.selected=view.dockApps().size()+1;press(KeyEvent.KEYCODE_DPAD_CENTER);assertEquals(GlassView.Screen.APPS,view.screen);
        view.home();host.store.list("recents",Arrays.asList(view.apps.get(0).id,view.apps.get(1).id));
        press(KeyEvent.KEYCODE_DPAD_UP);assertTrue(view.recentFocused);press(KeyEvent.KEYCODE_DPAD_RIGHT);press(KeyEvent.KEYCODE_DPAD_CENTER);
        assertEquals(view.apps.get(1).id,Shadows.shadowOf(host).getNextStartedActivity().getComponent().getPackageName());
        press(KeyEvent.KEYCODE_DPAD_UP);assertTrue(view.topFocused);assertEquals(2,view.topIndex);
    }
    @Test public void movieDeepLinkCannotLaunchAnotherPackage(){
        AppEntry app=view.apps.get(0);
        WatchCard card=new WatchCard("Film","Episode","intent://watch/12#Intent;component=bad.package/.Other;package=bad.package;end",app,null,.3f,true);
        Intent intent=WatchNextRepository.intent(card);assertNotNull(intent);assertEquals(app.id,intent.getPackage());assertNull(intent.getComponent());assertNull(intent.getSelector());
    }
    @Test public void inlineWeatherStaysVisibleWithoutClock()throws Exception{
        view.scenic.setFrame(SceneSet.load(host,"water"));host.store.put("showClock",false);
        view.setWeather(new Weather(9,3,System.currentTimeMillis(),"Махачкала",Collections.emptyList()),false);render("couch-no-clock");
        assertTrue(view.homeWeatherSummary().contains("Махачкала"));assertTrue(view.hits.stream().anyMatch(h->h.action.equals("clock")));
    }
    @Test public void realWatchNextRowsContainShowLinkAndProgress(){
        Shadows.shadowOf(host).grantPermissions(WatchNextRepository.permission());
        String owner=view.apps.get(0).id;
        ContentProvider provider=new ContentProvider(){
            @Override public boolean onCreate(){return true;}
            @Override public Cursor query(Uri u,String[] cols,String sel,String[] args,String sort){
                MatrixCursor c=new MatrixCursor(cols);c.addRow(new Object[]{1,owner,"Настоящий фильм","Серия 2",null,null,30000L,120000L,"https://example.org/watch/1"});return c;
            }
            @Override public String getType(Uri u){return null;}
            @Override public Uri insert(Uri u,ContentValues v){return null;}
            @Override public int delete(Uri u,String s,String[] a){return 0;}
            @Override public int update(Uri u,ContentValues v,String s,String[] a){return 0;}
        };
        ShadowContentResolver.registerProviderInternal("android.media.tv",provider);
        List<WatchCard> cards=WatchNextRepository.load(host,view.apps,host.store,false);
        assertEquals(1,cards.size());assertEquals("Настоящий фильм",cards.get(0).title);assertEquals(.25f,cards.get(0).progress,.001f);assertTrue(cards.get(0).program);
        host.store.hide(owner,true);assertTrue(WatchNextRepository.load(host,view.apps,host.store,false).isEmpty());
    }
    void render(String name)throws IOException{
        view.measure(View.MeasureSpec.makeMeasureSpec(1920,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(1080,View.MeasureSpec.EXACTLY));view.layout(0,0,1920,1080);
        Bitmap b=Bitmap.createBitmap(1920,1080,Bitmap.Config.ARGB_8888);view.draw(new Canvas(b));
        File file=new File("build/reports/screens/"+name+".png");file.getParentFile().mkdirs();try(FileOutputStream out=new FileOutputStream(file)){assertTrue(b.compress(Bitmap.CompressFormat.PNG,100,out));}
        assertTrue(file.length()>20000);b.recycle();
    }
}
