package com.usman.braviaglass;

import org.junit.Test;
import static org.junit.Assert.*;

public class UpdateManagerVersionTest {
    @Test public void laterVersionsAreNewer() {
        assertTrue(UpdateManager.newer("1.3.2", "1.3.1"));
        assertTrue(UpdateManager.newer("1.4", "1.3.1"));
        assertTrue(UpdateManager.newer("2.0", "1.3.1"));
        assertFalse(UpdateManager.newer("1.3.1", "1.3.1"));
        assertFalse(UpdateManager.newer("1.3.0", "1.3.1"));
        assertFalse(UpdateManager.newer("not-a-version", "1.3.1"));
    }
}
