package com.usman.braviaglass;

import static org.junit.Assert.*;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.os.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowDialog;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,qualifiers="w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class AppUninstallerTest {
    ActivityController<MainActivity> controller;
    MainActivity host;
    @Before public void setup(){
        MainActivity.disableNetworkForTests=true;
        RuntimeEnvironment.getApplication().getSharedPreferences("glass",0).edit().clear().commit();
    }
    @After public void cleanup(){if(controller!=null)controller.pause().stop().destroy();MainActivity.disableNetworkForTests=false;}
    void host()throws Exception{
        controller=Robolectric.buildActivity(MainActivity.class).create().start().resume().visible();host=controller.get();
        host.store.put("idleMinutes",0);host.store.put("animations",false);
        host.workers.submit(()->{}).get(10,TimeUnit.SECONDS);
        for(int i=0;i<12;i++){Shadows.shadowOf(Looper.getMainLooper()).idle();Thread.yield();}
        host.applications=LauncherTest.samples(3);host.glass.setApps(host.applications);host.store.seed(host.applications);
    }
    @Test public void manifestDeclaresRequestDeletePermission()throws Exception{
        Context app=RuntimeEnvironment.getApplication();
        String[] permissions=app.getPackageManager().getPackageInfo(app.getPackageName(),PackageManager.GET_PERMISSIONS).requestedPermissions;
        assertNotNull(permissions);assertTrue(Arrays.asList(permissions).contains("android.permission.REQUEST_DELETE_PACKAGES"));
    }
    @Test public void primaryRequestOpensAndroidConfirmationWithResult(){
        List<Intent> launched=new ArrayList<>();
        assertTrue(AppUninstaller.request("tv.example.player",(intent,request)->{
            launched.add(intent);assertEquals(AppUninstaller.REQUEST,request);
        }));
        assertEquals(1,launched.size());Intent intent=launched.get(0);
        assertEquals(Intent.ACTION_UNINSTALL_PACKAGE,intent.getAction());assertEquals("package:tv.example.player",intent.getDataString());
        assertTrue(intent.getBooleanExtra(Intent.EXTRA_RETURN_RESULT,false));
        assertEquals(0,intent.getFlags()&Intent.FLAG_ACTIVITY_NEW_TASK);
    }
    @Test public void legacyOnlyTvFirmwareGetsDeleteFallback(){
        List<Intent> calls=new ArrayList<>();
        assertTrue(AppUninstaller.request("tv.example.player",(intent,request)->{
            calls.add(intent);if(Intent.ACTION_UNINSTALL_PACKAGE.equals(intent.getAction()))throw new ActivityNotFoundException();
        }));
        assertEquals(2,calls.size());assertEquals(Intent.ACTION_DELETE,calls.get(1).getAction());
        assertEquals(calls.get(0).getData(),calls.get(1).getData());assertTrue(calls.get(1).getBooleanExtra(Intent.EXTRA_RETURN_RESULT,false));
    }
    @Test public void deniedHandlersReturnFailureInsteadOfPretendingToDelete(){
        List<Intent> calls=new ArrayList<>();
        assertFalse(AppUninstaller.request("tv.example.player",(intent,request)->{calls.add(intent);throw new SecurityException("firmware policy");}));
        assertEquals(2,calls.size());
    }
    @Test public void deleteMenuStartsUninstallerWithoutHidingApp()throws Exception{
        host();AppEntry app=host.applications.get(0);host.appMenu(app,false);
        AlertDialog dialog=(AlertDialog)ShadowDialog.getLatestDialog();assertNotNull(dialog);
        dialog.getListView().performItemClick(null,7,7);
        Intent intent=Shadows.shadowOf(host).getNextStartedActivity();assertNotNull(intent);
        assertEquals(Intent.ACTION_UNINSTALL_PACKAGE,intent.getAction());assertEquals(app.id,intent.getData().getSchemeSpecificPart());
        assertEquals(app.id,host.pendingUninstall);assertFalse(host.store.hidden(app.id));assertTrue(host.glass.apps.stream().anyMatch(a->a.id.equals(app.id)));
    }
    @Test public void cancelledRemovalLeavesInstalledApplicationVisible()throws Exception{
        host();AppEntry app=host.applications.get(0);PackageInfo info=new PackageInfo();info.packageName=app.id;
        info.applicationInfo=new ApplicationInfo();info.applicationInfo.packageName=app.id;
        Shadows.shadowOf(host.getPackageManager()).installPackage(info);
        host.pendingUninstall=app.id;host.pendingUninstallLabel=app.label;host.verifyUninstall(app.id);
        assertEquals("",host.pendingUninstall);assertFalse(host.store.hidden(app.id));
        assertTrue(host.glass.apps.stream().anyMatch(a->a.id.equals(app.id)));
    }
    @Test public void onlyConfirmedAbsenceRemovesTargetFromCatalog()throws Exception{
        host();AppEntry app=host.applications.get(0);String other=host.applications.get(1).id;
        host.pendingUninstall=app.id;host.pendingUninstallLabel=app.label;
        host.verifyUninstall(app.id); // PackageManager has no installed package with this sample id.
        assertEquals("",host.pendingUninstall);assertFalse(host.glass.apps.stream().anyMatch(a->a.id.equals(app.id)));
        assertTrue(host.glass.apps.stream().anyMatch(a->a.id.equals(other)));assertFalse(host.store.hidden(app.id));
    }
    @Test public void systemPackageOpensDetailsInsteadOfDelete()throws Exception{
        host();AppEntry sample=host.applications.get(0),system=new AppEntry(sample.id,sample.label,sample.component,sample.icon,true);
        host.uninstall(system);Intent intent=Shadows.shadowOf(host).getNextStartedActivity();
        assertEquals("android.settings.APPLICATION_DETAILS_SETTINGS",intent.getAction());assertEquals(system.id,intent.getData().getSchemeSpecificPart());assertEquals("",host.pendingUninstall);
    }
}
