package com.usman.braviaglass;

import static org.junit.Assert.*;
import org.junit.Test;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28)
public class WeatherTest {
    @Test public void forecastAndNegativeTemperaturesAreParsed() throws Exception {
        String json="{\"current\":{\"temperature_2m\":-2.8,\"weather_code\":71},\"daily\":{\"time\":[\"2026-11-13\"],\"temperature_2m_max\":[1.6],\"temperature_2m_min\":[-5.2],\"weather_code\":[71]}}";
        Weather w=Weather.parse(json,"Узген",123);assertEquals(-3,w.temperature);assertEquals(1,w.days.size());assertEquals(2,w.days.get(0).high);assertEquals(-5,w.days.get(0).low);assertEquals("Снег",Weather.description(w.code));assertEquals("-3°",Weather.degrees(w.temperature));
        Store store=new Store(RuntimeEnvironment.getApplication());store.prefs.edit().putString(Weather.place(store).cacheKey()+".json",json).putLong(Weather.place(store).cacheKey()+".time",123).commit();assertEquals(123,Weather.cached(store).updated);
    }
    @Test public void absentOrInvalidServiceDataIsNotReplacedByFakeWeather() throws Exception {
        try{Weather.parse("{\"current\":{\"weather_code\":0}}","Узген",1);fail();}catch(org.json.JSONException expected){}
        try{Weather.parse("{\"current\":{\"temperature_2m\":900,\"weather_code\":0}}","Узген",1);fail();}catch(org.json.JSONException expected){}
        Store store=new Store(RuntimeEnvironment.getApplication());store.prefs.edit().clear().commit();assertNull(Weather.cached(store));
    }

    static String fixture(String name)throws Exception{
        try(InputStream in=WeatherTest.class.getClassLoader().getResourceAsStream(name)){
            assertNotNull(in);return new String(in.readAllBytes(),StandardCharsets.UTF_8);
        }
    }
    @Test public void makhachkalaUpgradeFixesCoordinatesAndRetainsPersonalization(){
        Store store=new Store(RuntimeEnvironment.getApplication());store.prefs.edit().clear().commit();
        store.put("city","Махачкала");store.put("latitude","40.77");store.put("longitude","73.30");
        store.put("favorites","[\"youtube\",\"ivi\"]");store.put("wallpaper","my-photo.png");
        Weather.migrateMakhachkala(store);
        assertEquals("42.97782",store.text("latitude",""));assertEquals("47.50027",store.text("longitude",""));
        assertEquals("Махачкала",Weather.place(store).city);assertEquals("Europe/Moscow",Weather.place(store).zone);
        assertEquals("[\"youtube\",\"ivi\"]",store.text("favorites",""));assertEquals("my-photo.png",store.text("wallpaper",""));
        store.put("city","Москва");Weather.migrateMakhachkala(store);assertEquals("Москва",store.text("city",""));
    }
    @Test public void actualServiceFixturesProduceValidWeatherAndAvailableForecasts()throws Exception{
        Weather primary=Weather.parse(fixture("weather-primary.json"),"Махачкала",123);
        Weather backup=Weather.parse(fixture("weather-backup.json"),"Махачкала",123);
        assertEquals(5,primary.days.size());assertEquals(3,backup.days.size());
        assertEquals("Махачкала",primary.city);assertEquals("Open-Meteo.com",primary.source);assertEquals("wttr.in",backup.source);
        assertTrue(primary.temperature>-40&&primary.temperature<45);assertTrue(backup.temperature>-40&&backup.temperature<45);
    }
    @Test public void unavailablePrimaryAutomaticallyUsesBackupAndCachesRealResponse()throws Exception{
        Store store=new Store(RuntimeEnvironment.getApplication());store.prefs.edit().clear().commit();
        AtomicInteger attempts=new AtomicInteger();String backup=fixture("weather-backup.json");
        Weather w=Weather.fetch(Weather.PLACES[0],store.prefs,url->{
            attempts.incrementAndGet();if(url.contains("api.open-meteo.com"))throw new java.net.UnknownHostException();
            assertTrue(url.startsWith("https://wttr.in/42.97782,47.50027"));return backup;
        });
        assertEquals(2,attempts.get());assertEquals("wttr.in",w.source);assertEquals(w.temperature,Weather.cached(store).temperature);
        assertEquals("Махачкала",Weather.cached(store).city);
    }
    @Test public void badForecastDoesNotSuppressValidCurrentConditions()throws Exception{
        Weather w=Weather.parse("{\"current\":{\"temperature_2m\":9.4,\"weather_code\":3},\"daily\":{\"time\":[\"2026-11-13\"],\"temperature_2m_max\":[null],\"temperature_2m_min\":[3],\"weather_code\":[3]}}","Махачкала",1);
        assertEquals(9,w.temperature);assertEquals("Облачно",Weather.description(w.code));assertEquals(0,w.days.size());
    }
    @Test public void failedRequestsDoNotOverwriteLastSuccessfulConditions()throws Exception{
        Store store=new Store(RuntimeEnvironment.getApplication());store.prefs.edit().clear().commit();String primary=fixture("weather-primary.json");
        Weather fetched=Weather.fetch(Weather.PLACES[0],store.prefs,url->primary);
        try{Weather.fetch(Weather.PLACES[0],store.prefs,url->{throw new IOException("offline");});fail();}catch(IOException expected){}
        assertEquals(fetched.temperature,Weather.cached(store).temperature);assertEquals(fetched.updated,Weather.cached(store).updated);
    }
    @Test public void cacheBelongsToCoordinatesNotJustCityLabel()throws Exception{
        Store store=new Store(RuntimeEnvironment.getApplication());store.prefs.edit().clear().commit();
        Weather.Place first=new Weather.Place("Мой город","42.97782","47.50027","auto"),other=new Weather.Place("Мой город","55.75","37.62","auto");
        String primary=fixture("weather-primary.json");Weather.fetch(first,store.prefs,url->primary);
        assertNotNull(Weather.cached(first,store.prefs));assertNull(Weather.cached(other,store.prefs));
    }
    @Test public void failedRequestRetriesInThirtySecondsAndBackoffIsBounded(){
        WeatherRetry retry=new WeatherRetry();assertTrue(retry.due(100));retry.failure(100);
        assertFalse(retry.due(30099));assertTrue(retry.due(30100));retry.failure(30100);assertEquals(90100,retry.nextAttempt);
        for(int i=0;i<10;i++)retry.failure(100000);assertEquals(400000,retry.nextAttempt);
        retry.success(400000,Weather.FRESH_MS);assertFalse(retry.due(400001));assertTrue(retry.due(2200000));assertEquals(0,retry.failures);
        retry.reset();assertTrue(retry.due(1));
    }
    @Test public void futureDatedCacheIsNotTreatedAsFreshForever(){
        Weather w=new Weather(9,3,2000,"Махачкала",Collections.emptyList());assertFalse(Weather.fresh(w,1000));assertTrue(Weather.fresh(w,2000));assertFalse(Weather.fresh(w,2000+Weather.FRESH_MS));
    }
}
