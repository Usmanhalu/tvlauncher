package com.usman.braviaglass;

import static org.junit.Assert.*;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;
import org.robolectric.shadows.ShadowDialog;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,qualifiers="w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class LauncherTest {
    ActivityController<MainActivity> controller;
    MainActivity host;
    GlassView view;
    @Before public void setup() throws Exception {
        MainActivity.disableNetworkForTests=true;
        RuntimeEnvironment.getApplication().getSharedPreferences("glass",0).edit().clear().commit();
        controller=Robolectric.buildActivity(MainActivity.class).create().start().resume().visible();
        host=controller.get();view=host.glass;host.store.put("showPrayer",false);
        drain();
        host.store.put("look","classic");host.store.put("animations",false);host.store.put("idleMinutes",0);
        view.setApps(samples(9));host.applications=new ArrayList<>(view.apps);host.store.seed(view.apps);
        drain();
    }
    void drain() throws Exception {
        host.workers.submit(()->{}).get(10,TimeUnit.SECONDS);
        for(int i=0;i<12;i++){Shadows.shadowOf(Looper.getMainLooper()).idle();Thread.yield();}
    }
    @After public void cleanup(){controller.pause().stop().destroy();MainActivity.disableNetworkForTests=false;}
    static List<AppEntry> samples(int count){
        String[] ids={"com.google.android.youtube.tv","com.streaming.player","com.lift.player","ru.ivi.client","com.stream.tv","com.netflix.ninja","com.amazon.amazonvideo.livingroom","com.apple.atve.androidtv.appletv","com.file.manager"};
        String[] labels={"YouTube","Видео","LIFT","Иви","Телевидение","Netflix","Prime Video","Apple TV","Файлы"};
        ArrayList<AppEntry> entries=new ArrayList<>();
        for(int i=0;i<count;i++){
            String id=i<9?ids[i]:"tv.sample.app"+i,label=i<9?labels[i]:"Приложение "+(i+1);
            Bitmap icon=Bitmap.createBitmap(144,144,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(icon);Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setColor(GlassView.tileColor(id));c.drawRoundRect(new RectF(0,0,144,144),25,25,p);
            if(i==0){p.setColor(0xffff0c19);c.drawRoundRect(new RectF(20,37,124,108),18,18,p);p.setColor(Color.WHITE);Path path=new Path();path.moveTo(61,56);path.lineTo(61,91);path.lineTo(93,74);path.close();c.drawPath(path,p);}
            else{p.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));p.setColor(i==5?0xffe50914:Color.WHITE);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(i==5?90:i==6?29:34);String mark=i==1?"▶":i==2?"LIFT":i==3?"ИВИ":i==4?"ТВ":i==5?"N":i==6?"prime":i==7?"tv+":"▤";c.drawText(mark,72,i==5?105:84,p);}
            entries.add(new AppEntry(id,label,new ComponentName(id,id+".TvActivity"),icon,false));
        }
        return entries;
    }
    void press(int key){view.handleKey(new KeyEvent(KeyEvent.ACTION_DOWN,key));view.handleKey(new KeyEvent(KeyEvent.ACTION_UP,key));}
    @Test public void homeRemoteLaunchAndReturnUseRealComponents(){
        String first=view.dockApps().get(0).id;
        press(KeyEvent.KEYCODE_DPAD_CENTER);
        Intent intent=Shadows.shadowOf(host).getNextStartedActivity();assertNotNull(intent);assertEquals(first,intent.getComponent().getPackageName());
        press(KeyEvent.KEYCODE_DPAD_DOWN);assertEquals(GlassView.Screen.APPS,view.screen);
        press(KeyEvent.KEYCODE_BACK);assertEquals(GlassView.Screen.HOME,view.screen);
        press(KeyEvent.KEYCODE_DPAD_UP);assertTrue(view.topFocused);
        press(KeyEvent.KEYCODE_DPAD_CENTER);assertEquals(GlassView.Screen.CONTROL,view.screen);
        press(KeyEvent.KEYCODE_BACK);assertEquals(GlassView.Screen.HOME,view.screen);
    }
    @Test public void heldOkShowsMenuWithoutLaunchingApp(){
        view.handleKey(new KeyEvent(1000,1000,KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_DPAD_CENTER,0));
        view.handleKey(new KeyEvent(1000,1700,KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_DPAD_CENTER,1));
        assertNotNull(ShadowDialog.getLatestDialog());
        view.handleKey(new KeyEvent(1000,1750,KeyEvent.ACTION_UP,KeyEvent.KEYCODE_DPAD_CENTER,0));
        assertNull(Shadows.shadowOf(host).getNextStartedActivity());
    }
    @Test public void favoritesMoveAndHidePersistAcrossNewStore(){
        List<AppEntry> before=view.dockApps();String id=before.get(0).id;
        view.moving=true;view.moveId=id;view.selected=0;
        press(KeyEvent.KEYCODE_DPAD_RIGHT);press(KeyEvent.KEYCODE_DPAD_CENTER);
        assertFalse(view.moving);Store restored=new Store(host);assertEquals(id,restored.list("favorites").get(1));
        restored.hide(id,true);assertFalse(restored.visible(view.apps,true).stream().anyMatch(a->a.id.equals(id)));
        restored.hide(id,false);assertTrue(restored.visible(view.apps,true).stream().anyMatch(a->a.id.equals(id)));
        restored.put("label."+id,"Мой YouTube");assertEquals("Мой YouTube",restored.label(before.get(0)));
    }
    @Test public void profilesKeepIndependentLayoutAndLabels(){
        String id=view.apps.get(0).id;host.store.put("label."+id,"Основной");host.store.hide(id,true);
        host.store.addProfile("Дети");host.store.seed(view.apps);
        assertEquals("Дети",host.store.name());assertFalse(host.store.hidden(id));assertEquals(view.apps.get(0).label,host.store.label(view.apps.get(0)));
        host.store.selectProfile("p0");assertTrue(host.store.hidden(id));assertEquals("Основной",host.store.label(view.apps.get(0)));
    }
    @Test public void gridScrollIsBoundedAndAllAppsAreReachable(){
        view.setApps(samples(37));view.open(GlassView.Screen.APPS);
        for(int i=0;i<20;i++)press(KeyEvent.KEYCODE_DPAD_DOWN);
        assertEquals(36,view.gridIndex);
        for(int i=0;i<50;i++)press(KeyEvent.KEYCODE_DPAD_LEFT);
        assertEquals(0,view.gridIndex);
        press(KeyEvent.KEYCODE_CHANNEL_DOWN);assertEquals(24,view.gridIndex);
        press(KeyEvent.KEYCODE_CHANNEL_UP);assertEquals(0,view.gridIndex);
    }
    @Test public void wakingSaverDoesNotLaunchSelectedApp(){
        host.screensaver(true);assertEquals(GlassView.Screen.SAVER,view.screen);
        press(KeyEvent.KEYCODE_DPAD_CENTER);
        assertEquals(GlassView.Screen.HOME,view.screen);assertNull(Shadows.shadowOf(host).getNextStartedActivity());
        press(KeyEvent.KEYCODE_DPAD_CENTER);assertNotNull(Shadows.shadowOf(host).getNextStartedActivity());
    }
    @Test public void controlsOpenAndroidSettingsAndDoNotPretendToToggleRadios(){
        host.control(0);assertEquals("android.settings.WIFI_SETTINGS",Shadows.shadowOf(host).getNextStartedActivity().getAction());
        host.control(1);assertEquals("android.settings.BLUETOOTH_SETTINGS",Shadows.shadowOf(host).getNextStartedActivity().getAction());
        host.control(3);assertEquals("android.settings.SOUND_SETTINGS",Shadows.shadowOf(host).getNextStartedActivity().getAction());
        host.control(5);assertEquals(GlassView.Screen.SAVER,view.screen);assertTrue(host.blackOnly);
    }
    @Test public void iconThemeDoesNotConfusePrimeVideoWithIvi(){
        assertEquals(0xff087cdb,GlassView.tileColor("com.amazon.amazonvideo.livingroom"));
        assertEquals(0xffd41273,GlassView.tileColor("ru.ivi.client"));
        assertFalse(Store.matchesPriority("com.amazon.amazonvideo.livingroom","ivi"));
    }
    @Test public void settingsCanTraverseEverySectionWithRemote(){
        view.open(GlassView.Screen.SETTINGS);
        for(int cat=0;cat<8;cat++){
            view.category=cat;view.settingIndex=0;view.settingsRight=false;
            press(KeyEvent.KEYCODE_DPAD_RIGHT);
            assertTrue(view.settingsRight);
            for(int i=0;i<20;i++)press(KeyEvent.KEYCODE_DPAD_DOWN);
            assertEquals(host.rows(cat).size()-1,view.settingIndex);
            press(KeyEvent.KEYCODE_DPAD_LEFT);assertFalse(view.settingsRight);
        }
        view.category=0;view.settingIndex=3;view.settingsRight=true;
        boolean before=host.store.bool("showClock",true);press(KeyEvent.KEYCODE_DPAD_CENTER);assertEquals(!before,host.store.bool("showClock",true));
    }
    @Test public void discoveryPrefersTvActivityAndSkipsOwnPackage(){
        PackageManager pm=host.getPackageManager();
        Intent tv=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER),mobile=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        for(String activity:new String[]{"TvActivity","MobileActivity"}){
            ResolveInfo ri=new ResolveInfo();ri.activityInfo=new ActivityInfo();ri.activityInfo.packageName="tv.test.discovery";ri.activityInfo.name="tv.test.discovery."+activity;ri.activityInfo.enabled=true;ri.activityInfo.exported=true;ri.nonLocalizedLabel="Test";ri.activityInfo.applicationInfo=new ApplicationInfo();ri.activityInfo.applicationInfo.packageName=ri.activityInfo.packageName;
            Shadows.shadowOf(pm).addResolveInfoForIntent(activity.equals("TvActivity")?tv:mobile,ri);
        }
        List<AppEntry> result=AppRepository.load(host);long count=result.stream().filter(a->a.id.equals("tv.test.discovery")).count();assertEquals(1,count);
        assertEquals("tv.test.discovery.TvActivity",result.stream().filter(a->a.id.equals("tv.test.discovery")).findFirst().get().component.getClassName());
        assertFalse(result.stream().anyMatch(a->a.id.equals(host.getPackageName())));
    }
    @Test public void renderActualNativeScreensAtFullHd() throws Exception {
        try(InputStream in=host.getAssets().open("forest.jpg")){Bitmap b=BitmapFactory.decodeStream(in);view.setWallpaper(b,MainActivity.blur(b));}
        view.nowOverride=1794559920000L;
        view.setWeather(new Weather(9,3,view.now(),"Махачкала",Arrays.asList(new Weather.Day("2026-11-13",10,3,3),new Weather.Day("2026-11-14",11,4,2),new Weather.Day("2026-11-15",9,2,61),new Weather.Day("2026-11-16",8,1,3),new Weather.Day("2026-11-17",10,2,0))),false);
        render("home");view.open(GlassView.Screen.CONTROL);render("control");view.open(GlassView.Screen.APPS);render("apps");view.open(GlassView.Screen.SETTINGS);view.settingsRight=true;render("settings");view.open(GlassView.Screen.WEATHER);render("weather");
        for(int[] size:new int[][]{{1280,720},{3840,2160}}){view.measure(View.MeasureSpec.makeMeasureSpec(size[0],View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(size[1],View.MeasureSpec.EXACTLY));view.layout(0,0,size[0],size[1]);Bitmap frame=Bitmap.createBitmap(size[0],size[1],Bitmap.Config.ARGB_8888);view.home();view.draw(new Canvas(frame));assertNotEquals(0,frame.getPixel(size[0]/2,size[1]/2));frame.recycle();}
    }
    @Test public void weatherRemainsVisibleAndSelectableWhenClockIsHidden()throws Exception{
        host.store.put("showClock",false);host.store.put("showWeather",true);
        view.setWeather(new Weather(-2,71,System.currentTimeMillis(),"Махачкала",Collections.emptyList()),false);
        render("weather-without-clock");
        assertTrue(view.homeWeatherSummary().contains("Махачкала"));assertTrue(view.homeWeatherSummary().contains("-2°"));
        assertTrue(view.hits.stream().anyMatch(h->h.action.equals("clock")&&h.rect.left==66&&h.rect.top==174));
        view.tap(400,250,false);assertEquals(GlassView.Screen.WEATHER,view.screen);view.home();
        host.store.put("showWeather",false);render("weather-hidden");
        assertFalse(view.hits.stream().anyMatch(h->h.action.equals("clock")));
    }
    @Test public void failedWeatherIsShownAsAnErrorNotOnlyCityName()throws Exception{
        view.setWeather(null,true);view.weatherError="Нет связи с погодой. Повторим автоматически";
        render("weather-offline");assertTrue(view.homeWeatherSummary().contains("Нет связи"));
    }
    void render(String name) throws IOException {
        view.measure(View.MeasureSpec.makeMeasureSpec(1920,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(1080,View.MeasureSpec.EXACTLY));view.layout(0,0,1920,1080);
        Bitmap image=Bitmap.createBitmap(1920,1080,Bitmap.Config.ARGB_8888);view.draw(new Canvas(image));
        File file=new File("build/reports/screens/"+name+".png");file.getParentFile().mkdirs();try(FileOutputStream out=new FileOutputStream(file)){assertTrue(image.compress(Bitmap.CompressFormat.PNG,100,out));}assertTrue(file.length()>10000);
    }
}
