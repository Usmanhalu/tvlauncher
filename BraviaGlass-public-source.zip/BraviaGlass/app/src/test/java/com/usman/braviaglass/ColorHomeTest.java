package com.usman.braviaglass;

import static org.junit.Assert.*;
import android.content.*;
import android.graphics.*;
import android.os.Looper;
import android.view.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.*;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,qualifiers="w960dp-h540dp-land-television-xhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
public class ColorHomeTest {
    ActivityController<MainActivity> controller;MainActivity host;GlassView view;
    @Before public void setup()throws Exception{
        MainActivity.disableNetworkForTests=true;
        RuntimeEnvironment.getApplication().getSharedPreferences("glass",0).edit().clear().commit();
        controller=Robolectric.buildActivity(MainActivity.class).create().start().resume().visible();host=controller.get();view=host.glass;
        host.workers.submit(()->{}).get(10,TimeUnit.SECONDS);Shadows.shadowOf(Looper.getMainLooper()).idle();
        host.store.put("look","ambient");host.store.put("animations",false);host.store.put("showPrayer",false);host.store.put("idleMinutes",0);
        view.nowOverride=1794932580000L;
        view.setApps(samples());host.applications=new ArrayList<>(view.apps);host.store.list("favorites",new ArrayList<>());
        for(AppEntry a:view.apps)host.store.favorite(a.id,true);
        view.setWeather(new Weather(4,3,view.now(),"Махачкала",Collections.emptyList()),false);
    }
    @After public void cleanup(){controller.pause().stop().destroy();MainActivity.disableNetworkForTests=false;}
    void press(int code){view.handleKey(new KeyEvent(KeyEvent.ACTION_DOWN,code));view.handleKey(new KeyEvent(KeyEvent.ACTION_UP,code));}
    static List<AppEntry> samples(){
        String[] ids={"tv.kinopub.player","com.example.livetv","com.google.android.youtube.tv","ru.rutube.app","com.dedproxy.app","org.videolan.vlc"};
        String[] names={"Kinopub","Live TV","YouTube","RUTUBE","Дед Proxy","VLC"};int[] colors={0xff00a9e3,0xff265bff,0xffe62041,0xff7640e4,0xffadb830,0xffe9791c};
        ArrayList<AppEntry> list=new ArrayList<>();
        for(int i=0;i<ids.length;i++){
            Bitmap banner=Bitmap.createBitmap(320,180,Bitmap.Config.ARGB_8888);Canvas c=new Canvas(banner);Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
            c.drawColor(i==2?0xfff3f5f7:AppPalette.blend(ColorHome.BASE,colors[i],i==1?.9f:.25f));p.setColor(i==2?0xffe62041:Color.WHITE);p.setTextSize(i==4?30:39);p.setTypeface(Typeface.create("sans-serif-medium",0));p.setTextAlign(Paint.Align.CENTER);c.drawText(names[i],160,103,p);
            Bitmap icon=Bitmap.createBitmap(144,144,Bitmap.Config.ARGB_8888);icon.eraseColor(colors[i]);
            list.add(new AppEntry(ids[i],names[i],new ComponentName(ids[i],ids[i]+".MainActivity"),icon,banner,false));
        }return list;
    }
    @Test public void upgradePreservesDataAndDoesNotForceTheDesignAgain(){
        String id=view.apps.get(2).id;host.store.put("ambientDesignVersion",0);host.store.put("look","classic");host.store.put("label."+id,"Мой YouTube");host.store.put("city","Мой город");host.store.put("saverSeconds",120);host.store.hide(view.apps.get(4).id,true);
        List<String> order=host.store.list("favorites");host.store.migrateAmbientDesign();
        assertTrue(view.ambient());assertEquals(order,host.store.list("favorites"));assertEquals("Мой YouTube",host.store.label(view.apps.get(2)));assertEquals("Мой город",host.store.text("city",""));assertTrue(host.store.hidden(view.apps.get(4).id));assertEquals(120,host.store.number("saverSeconds",0));
        host.store.put("look","couch");new Store(host).migrateAmbientDesign();assertEquals("couch",host.store.text("look",""));
    }
    @Test public void paletteUsesBrandsAndDominantArtworkAndBlendsWithoutJumps(){
        assertEquals(0xffe62041,view.apps.get(2).accent);assertEquals(0xff7640e4,view.apps.get(3).accent);
        Bitmap green=Bitmap.createBitmap(20,20,Bitmap.Config.ARGB_8888);green.eraseColor(0xff16ad42);int derived=AppPalette.color("tv.unknown",green);assertTrue(Color.green(derived)>Color.red(derived)*2);
        assertEquals(0xff112233,AppPalette.blend(0xff112233,0xffeeccaa,0));assertEquals(0xffeeccaa,AppPalette.blend(0xff112233,0xffeeccaa,1));
        host.store.put("animations",true);view.colorHome.fromColor=0xff112233;view.colorHome.targetColor=0xffeeccaa;view.colorHome.colorStarted=1000;
        assertEquals(0xff112233,view.colorHome.currentColor(1000));assertEquals(0xffeeccaa,view.colorHome.currentColor(1800));assertNotEquals(view.colorHome.currentColor(1000),view.colorHome.currentColor(1400));
    }
    @Test public void weatherMovesUnderTheDateWithoutMovingTheAppRow()throws Exception{
        Bitmap shown=render(null);host.store.put("showWeather",false);Bitmap hidden=render(null);
        assertTrue(differences(shown,hidden,306,153,1000,208)>100);assertEquals(0,differences(shown,hidden,0,210,1920,1080));
        host.store.put("showClock",false);host.store.put("showWeather",true);Bitmap withoutClock=render(null);assertTrue(view.hits.stream().anyMatch(h->h.action.equals("clock")));assertTrue(differences(hidden,withoutClock,84,153,900,208)>100);
        shown.recycle();hidden.recycle();withoutClock.recycle();
    }
    @Test public void topMenuLaunchesSourcesWifiAppsAndSettings(){
        press(KeyEvent.KEYCODE_DPAD_UP);assertTrue(view.topFocused);assertEquals(0,view.topIndex);press(KeyEvent.KEYCODE_DPAD_CENTER);assertEquals("com.sony.dtv.intent.action.TVINPUT",Shadows.shadowOf(host).getNextStartedActivity().getAction());
        press(KeyEvent.KEYCODE_DPAD_RIGHT);press(KeyEvent.KEYCODE_DPAD_CENTER);assertEquals("android.settings.WIFI_SETTINGS",Shadows.shadowOf(host).getNextStartedActivity().getAction());
        press(KeyEvent.KEYCODE_DPAD_RIGHT);press(KeyEvent.KEYCODE_DPAD_CENTER);assertEquals(GlassView.Screen.APPS,view.screen);view.home();view.topFocused=true;view.topIndex=3;press(KeyEvent.KEYCODE_DPAD_CENTER);assertEquals(GlassView.Screen.SETTINGS,view.screen);
    }
    @Test public void rowScrollReachesEveryFavoriteAndLaunchesTheCorrectComponent()throws Exception{
        view.setApps(LauncherTest.samples(37));host.store.list("favorites",new ArrayList<>());for(AppEntry a:view.apps)host.store.favorite(a.id,true);
        for(int i=0;i<60;i++)press(KeyEvent.KEYCODE_DPAD_RIGHT);assertEquals(36,view.selected);Bitmap b=render("ambient-long-row");
        assertTrue(view.hits.stream().anyMatch(h->h.action.equals("dock")&&h.index==36));press(KeyEvent.KEYCODE_DPAD_CENTER);assertEquals(view.apps.get(36).component,Shadows.shadowOf(host).getNextStartedActivity().getComponent());
        for(int i=0;i<60;i++)press(KeyEvent.KEYCODE_DPAD_LEFT);assertEquals(0,view.selected);b.recycle();
    }
    @Test public void emptyRowAndPrayerRecentNavigationHaveNoDeadEnds()throws Exception{
        host.store.put("showPrayer",true);host.store.list("recents",Arrays.asList(view.apps.get(0).id));
        press(KeyEvent.KEYCODE_DPAD_UP);assertTrue(view.recentFocused);Bitmap b=render("ambient-recents");assertTrue(view.hits.stream().anyMatch(h->h.action.equals("recent")));b.recycle();
        press(KeyEvent.KEYCODE_DPAD_UP);assertTrue(view.prayerFocused);press(KeyEvent.KEYCODE_DPAD_UP);assertTrue(view.topFocused);
        RectF prayer=view.compactPrayerBounds();assertTrue(prayer.top>210);assertTrue(prayer.bottom<400);
        view.home();host.store.list("favorites",Collections.emptyList());b=render("ambient-empty");assertEquals(0,view.selected);assertTrue(view.hits.stream().anyMatch(h->h.action.equals("allApps")));press(KeyEvent.KEYCODE_DPAD_DOWN);assertEquals(GlassView.Screen.APPS,view.screen);b.recycle();
    }
    @Test public void bannersRenderAndCustomIconsCanOverrideThem()throws Exception{
        Bitmap green=Bitmap.createBitmap(320,180,Bitmap.Config.ARGB_8888);green.eraseColor(0xff15aa45);Bitmap red=Bitmap.createBitmap(144,144,Bitmap.Config.ARGB_8888);red.eraseColor(0xffdd2233);
        AppEntry app=new AppEntry("tv.banner.test","Test",new ComponentName("tv.banner.test","tv.banner.test.Main"),red,green,false);
        Bitmap b=Bitmap.createBitmap(400,220,Bitmap.Config.ARGB_8888);view.colorHome.tile(new Canvas(b),app,new RectF(10,10,330,190));assertEquals(0xff15aa45,b.getPixel(170,100));
        host.customIcons.put(app.id,red);view.colorHome.tile(new Canvas(b),app,new RectF(10,10,330,190));assertNotEquals(0xff15aa45,b.getPixel(170,100));b.recycle();
    }
    @Test public void renderApprovedDesignAcrossTelevisionResolutions()throws Exception{
        for(int i:new int[]{0,1,2,3}){view.selected=i;Bitmap b=render("ambient-"+i);assertNotEquals(ColorHome.BASE,b.getPixel(570,340));b.recycle();}
        host.store.put("showPrayer",true);Bitmap b=render("ambient-prayers");b.recycle();
        for(int[] size:new int[][]{{1280,720},{3840,2160}}){view.measure(View.MeasureSpec.makeMeasureSpec(size[0],View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(size[1],View.MeasureSpec.EXACTLY));view.layout(0,0,size[0],size[1]);b=Bitmap.createBitmap(size[0],size[1],Bitmap.Config.ARGB_8888);view.draw(new Canvas(b));assertTrue(view.hits.stream().filter(h->h.action.equals("top")).count()==4);b.recycle();}
    }
    int differences(Bitmap a,Bitmap b,int l,int t,int r,int bottom){int n=0;for(int y=t;y<bottom;y++)for(int x=l;x<r;x++)if(a.getPixel(x,y)!=b.getPixel(x,y))n++;return n;}
    Bitmap render(String name)throws IOException{
        view.measure(View.MeasureSpec.makeMeasureSpec(1920,View.MeasureSpec.EXACTLY),View.MeasureSpec.makeMeasureSpec(1080,View.MeasureSpec.EXACTLY));view.layout(0,0,1920,1080);Bitmap b=Bitmap.createBitmap(1920,1080,Bitmap.Config.ARGB_8888);view.draw(new Canvas(b));
        if(name!=null){File file=new File("build/reports/screens/"+name+".png");file.getParentFile().mkdirs();try(FileOutputStream out=new FileOutputStream(file)){assertTrue(b.compress(Bitmap.CompressFormat.PNG,100,out));}}return b;
    }
}
