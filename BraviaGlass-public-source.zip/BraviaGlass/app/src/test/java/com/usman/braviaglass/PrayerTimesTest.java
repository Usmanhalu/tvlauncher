package com.usman.braviaglass;

import static org.junit.Assert.*;
import android.content.*;
import java.util.*;
import org.json.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28)
public class PrayerTimesTest {
    Context context;SharedPreferences prefs;PrayerTimes prayers;
    @Before public void setup(){context=RuntimeEnvironment.getApplication();prefs=context.getSharedPreferences("prayer-unit",0);prefs.edit().clear().commit();prayers=new PrayerTimes(context,prefs);}
    static long wall(String date,int hour,int minute){Calendar c=Calendar.getInstance(PrayerTimes.ZONE);c.setTime(PrayerTimes.parseDate(date));c.set(Calendar.HOUR_OF_DAY,hour);c.set(Calendar.MINUTE,minute);return c.getTimeInMillis();}
    @Test public void officialSeedMatchesPhotoAndContainsOnlyVerifiedMonths(){
        assertEquals(61,prayers.days.size());assertEquals("2026-11-01",prayers.days.firstKey());assertEquals("2026-12-31",prayers.days.lastKey());
        assertArrayEquals(new String[]{"05:05","06:37","11:39","14:09","16:33","17:50"},prayers.days.get("2026-11-13").times);
        assertArrayEquals(new String[]{"05:41","07:18","11:57","14:08","16:29","17:50"},prayers.days.get("2026-12-31").times);
    }
    @Test public void greenChangesExactlyAtPrayerBoundariesAndNeverForSunrise(){
        PrayerTimes.Day d=prayers.days.get("2026-11-13");
        assertEquals(-1,d.active(304));assertEquals(0,d.active(305));assertEquals(0,d.active(396));assertEquals(-1,d.active(397));
        assertEquals(-1,d.active(698));assertEquals(2,d.active(699));assertEquals(2,d.active(848));assertEquals(3,d.active(849));
        assertEquals(3,d.active(992));assertEquals(4,d.active(993));assertEquals(4,d.active(1069));assertEquals(5,d.active(1070));
    }
    @Test public void nextDateAndNightUseMakhachkalaZoneEvenOnForeignTv(){
        TimeZone old=TimeZone.getDefault();try{
            TimeZone.setDefault(TimeZone.getTimeZone("Pacific/Honolulu"));
            PrayerTimes.Display night=prayers.display(wall("2026-11-14",0,3));assertEquals("2026-11-13",night.day.date);assertEquals(5,night.active);assertTrue(night.previousNight);
            PrayerTimes.Display dawn=prayers.display(wall("2026-11-14",5,6));assertEquals("2026-11-14",dawn.day.date);assertEquals(0,dawn.active);assertFalse(dawn.previousNight);
        }finally{TimeZone.setDefault(old);}
    }
    @Test public void expiredAndMissingDaysNeverRepeatAnOldSchedule(){
        assertNull(prayers.display(wall("2027-01-01",0,1)));assertNull(prayers.display(wall("2026-10-31",19,0)));
        assertEquals(-1,prayers.display(wall("2026-11-01",0,1)).active);
        prayers.days.remove("2026-11-14");assertNull(prayers.display(wall("2026-11-14",1,0)));
    }
    @Test public void onlyOfficialCityAndMatchingMethodCanBeImported(){
        assertEquals("2026-11",PrayerTimes.monthFromUrl(PrayerTimes.BASE+"2026-11"));
        assertEquals("2026-11",PrayerTimes.monthFromUrl(PrayerTimes.BASE+"2026-11?asr=standard&method=678"));
        for(String url:new String[]{"http://sajda.com/ru/prayer-times/russia/dagestan-makhachkala/532096/2026-11",PrayerTimes.BASE+"2026-11?asr=hanafi",PrayerTimes.BASE+"2026-11?method=3",PrayerTimes.BASE+"2026-13",PrayerTimes.BASE.replace("532096","123456")+"2026-11",PrayerTimes.BASE.replace("sajda.com","sajda.com.evil.test")+"2026-11"})assertEquals(url,"",PrayerTimes.monthFromUrl(url));
        assertFalse(SajdaImportActivity.allowedNavigation("file:///etc/passwd"));assertFalse(SajdaImportActivity.allowedNavigation("https://example.org/"));assertTrue(SajdaImportActivity.allowedNavigation(PrayerTimes.BASE+"2026-11"));
    }
    static String table(String month,int count){
        StringBuilder s=new StringBuilder("<table id=\"prayer-times-monthly-table\"><thead><tr><th>Дата</th>");
        for(String label:PrayerTimes.LABELS)s.append("<th scope=\"col\">").append(label).append("</th>");
        s.append("<th>Тахаджуд</th></tr></thead><tbody>");
        for(int i=1;i<=count;i++){
            s.append(String.format(Locale.US,"<tr data-date=\"%s-%02d\"><th><p>Дата</p></th>",month,i));
            for(String time:new String[]{"05:05","06:37","11:39","14:09","16:33","17:50","00:55"})s.append("<td><p>").append(time).append("</p></td>");s.append("</tr>");
        }return s.append("</tbody></table>").toString();
    }
    @Test public void fullPublishedMonthImportsAndSurvivesRestart(){
        prayers.importHtml(PrayerTimes.BASE+"2027-01",table("2027-01",31));PrayerTimes restored=new PrayerTimes(context,prefs);
        assertEquals(92,restored.days.size());assertEquals(5,restored.display(wall("2027-01-02",18,0)).active);
        assertTrue(prefs.getString("prayers.sajda.lastSource","").endsWith("2027-01"));
    }
    @Test public void incompleteWrongOrReorderedTableCannotCorruptSavedMonth(){
        String valid=table("2026-11",30);
        for(String html:new String[]{table("2026-11",7),valid.replaceFirst("data-date=\"2026-11-02\"","data-date=\"2026-11-01\""),valid.replace("<th scope=\"col\">Фаджр</th>","<th>Иша</th>"),valid.replace("14:09","25:09"),valid.replace("2026-11-30","2026-12-01"),"<h1>Just a moment...</h1>"}){
            try{prayers.importHtml(PrayerTimes.BASE+"2026-11",html);fail("Must reject incomplete or malformed source");}catch(IllegalArgumentException expected){}
            assertEquals(61,prayers.days.size());assertArrayEquals(new String[]{"05:05","06:37","11:39","14:09","16:33","17:50"},prayers.days.get("2026-11-13").times);assertFalse(prefs.contains(PrayerTimes.CACHE));
        }
    }
    @Test public void corruptCacheFallsBackToVerifiedSeed(){prefs.edit().putString(PrayerTimes.CACHE,"[[\"2026-11-13\",\"invalid\"]]").commit();assertEquals(61,new PrayerTimes(context,prefs).days.size());}
}
