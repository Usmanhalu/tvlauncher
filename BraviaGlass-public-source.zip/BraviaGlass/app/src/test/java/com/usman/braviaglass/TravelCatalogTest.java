package com.usman.braviaglass;

import static org.junit.Assert.*;
import java.util.*;
import org.junit.Test;

public class TravelCatalogTest {
    @Test public void everyPhotoAppearsOncePerRoundWithoutBoundaryRepeats(){
        for(int seed=0;seed<100;seed++){
            TravelCatalog.Deck deck=new TravelCatalog.Deck(new Random(seed));
            TravelCatalog.Photo previous=null;
            for(int round=0;round<5;round++){
                Set<TravelCatalog.Photo> seen=new HashSet<>();
                for(int i=0;i<TravelCatalog.PHOTOS.size();i++){
                    TravelCatalog.Photo next=deck.next("all");
                    assertNotSame(previous,next);assertTrue(seen.add(next));previous=next;
                }
                assertEquals(new HashSet<>(TravelCatalog.PHOTOS),seen);
            }
        }
    }
    @Test public void categoryChangeTakesEffectOnTheNextPhoto(){
        TravelCatalog.Deck deck=new TravelCatalog.Deck(new Random(24));
        deck.next("all");
        Set<TravelCatalog.Photo> nature=new HashSet<>(),cities=new HashSet<>();
        for(int i=0;i<50;i++){
            TravelCatalog.Photo photo=deck.next("nature");assertTrue(photo.nature);nature.add(photo);
        }
        for(int i=0;i<70;i++){
            TravelCatalog.Photo photo=deck.next("cities");assertFalse(photo.nature);cities.add(photo);
        }
        assertEquals(5,nature.size());assertEquals(7,cities.size());
    }
    @Test public void corruptOrOldSettingsHaveSafeDefaults(){
        TravelCatalog.Deck deck=new TravelCatalog.Deck(new Random(1));
        Set<TravelCatalog.Photo> all=new HashSet<>();
        for(int i=0;i<12;i++)all.add(deck.next("obsolete-setting"));
        assertEquals(12,all.size());
        assertEquals(30,TravelCatalog.intervalSeconds(Integer.MIN_VALUE));
        assertEquals(300,TravelCatalog.intervalSeconds(Integer.MAX_VALUE));
        for(int seconds:new int[]{30,60,120,300})assertEquals(seconds,TravelCatalog.intervalSeconds(seconds));
    }
}
