package com.usman.braviaglass;

import static org.junit.Assert.*;
import android.os.*;
import java.net.UnknownHostException;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28,qualifiers="w960dp-h540dp-land-television-xhdpi")
public class WeatherFlowTest {
    ActivityController<MainActivity> controller;
    MainActivity host;
    @Before public void start(){
        MainActivity.disableNetworkForTests=true;
        RuntimeEnvironment.getApplication().getSharedPreferences("glass",0).edit().clear().commit();
        controller=Robolectric.buildActivity(MainActivity.class).create().start().resume().visible();host=controller.get();
    }
    @After public void stop(){MainActivity.disableNetworkForTests=true;controller.pause().stop().destroy();MainActivity.disableNetworkForTests=false;}
    void finishWeather()throws Exception{
        for(int i=0;i<200;i++){
            Shadows.shadowOf(Looper.getMainLooper()).idle();
            if(!host.weatherBusy)return;Thread.sleep(5);
        }
        fail("Weather callback did not complete");
    }
    @Test public void reEnablingWeatherFetchesImmediatelyAfterAnEarlierFailure()throws Exception{
        AtomicInteger calls=new AtomicInteger();host.weatherLoader=place->{calls.incrementAndGet();throw new UnknownHostException("offline");};
        MainActivity.disableNetworkForTests=false;host.refreshWeather(true);finishWeather();
        assertEquals(1,calls.get());assertNull(host.glass.weather);assertFalse(host.glass.weatherError.isEmpty());
        assertTrue(host.weatherRetry.nextAttempt-SystemClock.elapsedRealtime()<=30000);
        host.weatherRetry.nextAttempt=Long.MAX_VALUE;host.store.put("showWeather",false);
        host.rows(3).get(0).action.run();finishWeather();
        assertTrue(host.store.bool("showWeather",false));assertEquals(2,calls.get());
    }
    @Test public void citySwitchDuringRequestCannotApplyWeatherFromOldCity()throws Exception{
        CountDownLatch started=new CountDownLatch(1),release=new CountDownLatch(1);
        host.weatherLoader=place->{
            if(place.city.equals("Махачкала")){started.countDown();release.await(2,TimeUnit.SECONDS);}
            return new Weather(place.city.equals("Махачкала")?9:-3,3,System.currentTimeMillis(),place.city,Collections.emptyList());
        };
        MainActivity.disableNetworkForTests=false;host.refreshWeather(true);assertTrue(started.await(2,TimeUnit.SECONDS));
        host.setCity("Москва","55.75","37.62");release.countDown();finishWeather();
        assertNotNull(host.glass.weather);assertEquals("Москва",host.glass.weather.city);assertEquals(-3,host.glass.weather.temperature);
    }
}
