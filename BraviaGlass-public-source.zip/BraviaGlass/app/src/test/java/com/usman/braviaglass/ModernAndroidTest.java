package com.usman.braviaglass;

import static org.junit.Assert.*;
import android.content.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=35,qualifiers="w960dp-h540dp-land-television-xhdpi")
public class ModernAndroidTest {
    @Test public void launchesAndRegistersReceiversOnAndroid15(){
        MainActivity.disableNetworkForTests=true;
        try(var c=Robolectric.buildActivity(MainActivity.class).create().start().resume().visible()){
            assertNotNull(c.get().glass);
            Intent home=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).setPackage(c.get().getPackageName());
            assertFalse(c.get().getPackageManager().queryIntentActivities(home,0).isEmpty());
        }finally{MainActivity.disableNetworkForTests=false;}
    }
}
