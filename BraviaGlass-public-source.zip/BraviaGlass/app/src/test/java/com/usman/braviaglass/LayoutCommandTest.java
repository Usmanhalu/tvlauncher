package com.usman.braviaglass;

import static org.junit.Assert.*;
import android.content.*;
import android.content.pm.*;
import java.util.*;
import org.junit.*;
import org.junit.runner.RunWith;
import org.robolectric.*;
import org.robolectric.annotation.Config;

@RunWith(RobolectricTestRunner.class)
@Config(sdk=28)
public class LayoutCommandTest {
    Context context;Store store;
    @Before public void setup(){context=RuntimeEnvironment.getApplication();context.getSharedPreferences("glass",0).edit().clear().commit();store=new Store(context);}
    Intent command(){return new Intent(LayoutCommandReceiver.ACTION).setComponent(new ComponentName(context,LayoutCommandReceiver.class));}
    void send(Intent intent){new LayoutCommandReceiver().onReceive(context,intent);}
    @Test public void commandSavesBothOptionsAndPreservesClockWallpaperAndOtherPreferences(){
        store.put("clockSize",120);store.put("wallpaper","my-wallpaper.jpg");store.put("scene","warm");store.put("showPrayer",true);
        Map<String,?> before=new HashMap<>(store.prefs.getAll());
        send(command().putExtra("weather_position","under_clock").putExtra("weather_background",false));
        Store restored=new Store(context);assertEquals("under_clock",restored.text("weatherPosition",""));assertFalse(restored.bool("weatherBackground",true));
        for(Map.Entry<String,?> entry:before.entrySet())assertEquals(entry.getKey(),entry.getValue(),restored.prefs.getAll().get(entry.getKey()));
        assertEquals(before.size()+2,restored.prefs.getAll().size());
    }
    @Test public void malformedOrUnknownOptionsNeverPartiallyApply(){
        store.put("weatherPosition","top_right");store.put("weatherBackground",true);Map<String,?> before=new HashMap<>(store.prefs.getAll());
        for(Intent bad:Arrays.asList(command(),new Intent("other.action").putExtra("weather_background",false),command().putExtra("weather_position","anywhere"),command().putExtra("weather_background","false"),command().putExtra("weather_position","under_clock").putExtra("clockSize",1),command().putExtra("weather_position","under_clock").putExtra("weather_background",3))){send(bad);assertEquals(before,store.prefs.getAll());}
    }
    @Test public void commandCanRestoreOriginalPositionAndBackground(){
        send(command().putExtra("weather_position","under_clock").putExtra("weather_background",false));
        send(command().putExtra("weather_position","top_right").putExtra("weather_background",true));
        assertEquals("top_right",store.text("weatherPosition",""));assertTrue(store.bool("weatherBackground",false));
    }
    @Test public void updatesOnlyCurrentProfile(){
        store.put("weatherPosition","top_right");store.addProfile("Гость");String guest=store.profile();
        send(command().putExtra("weather_position","under_clock").putExtra("weather_background",false));
        assertEquals("under_clock",new Store(context).text("weatherPosition",""));store.selectProfile("p0");assertEquals("top_right",store.text("weatherPosition",""));assertFalse(store.prefs.contains(store.key("weatherBackground")));store.selectProfile(guest);assertFalse(store.bool("weatherBackground",true));
    }
    @Test public void manifestRestrictsEndpointToSystemDumpPermission()throws Exception{
        ActivityInfo receiver=context.getPackageManager().getReceiverInfo(new ComponentName(context,LayoutCommandReceiver.class),0);
        assertTrue(receiver.exported);assertEquals("android.permission.DUMP",receiver.permission);
        PackageInfo pkg=context.getPackageManager().getPackageInfo(context.getPackageName(),PackageManager.GET_PERMISSIONS);
        assertFalse(Arrays.asList(pkg.requestedPermissions).contains("android.permission.DUMP"));
    }
    @Test public void prayerLayoutCommandPersistsAndRejectsBadValuesAtomically(){
        store.put("weatherPosition","under_clock");store.put("weatherBackground",false);
        send(command().putExtra("prayer_layout","top_text"));assertEquals("top_text",new Store(context).text("prayerLayout",""));
        send(command().putExtra("prayer_layout","shelf_card"));assertEquals("shelf_card",store.text("prayerLayout",""));
        Map<String,?> before=new HashMap<>(store.prefs.getAll());
        for(Intent bad:Arrays.asList(command().putExtra("prayer_layout","other").putExtra("weather_background",true),command().putExtra("prayer_layout",60))){send(bad);assertEquals(before,store.prefs.getAll());}
    }
}
