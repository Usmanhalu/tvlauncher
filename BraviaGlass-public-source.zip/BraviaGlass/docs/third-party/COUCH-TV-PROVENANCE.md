# Couch TV attribution

Source: https://github.com/Seagey/couch-tv
Upstream commit: `377d9cbc0952facaec4b920eed07031f1c5d38a7`
Copyright (c) 2026 Seagey. MIT; full licence in COUCH-TV-LICENSE.txt and assets/scenes/LICENSE-Couch-TV.txt.

Reused: the five scene JPEGs, their frosted JPEGs and transparent foreground WebP files; Antonio Light TTF; scene clock geometry and the solar-altitude/scene-choice formula. Layout/rendering is adapted to native Android Canvas in Bravia Glass. The upstream bridge, remote, Claude integration, Android accessibility services and setup scripts are not included or executed.

Upstream confirms the five default scenes were generated from text and their derived foreground/glass files are free to use; see bundled CREDITS.md. Other photos listed there were not copied.

Antonio: SIL Open Font License 1.1, full licence bundled at app/src/main/assets/fonts/Antonio-OFL.txt.

Bravia Glass 1.1.2 adds a runtime colour-graded sunset variant of night. Glass textures are now generated natively from each scene photo with blur, colour adaptation and a small refraction offset; the original upstream glass JPEGs remain bundled for source provenance.
