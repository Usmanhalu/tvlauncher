#!/usr/bin/env python3
"""Build this dependency-free native launcher with JDK 17 and Android SDK, without Gradle downloads."""
from pathlib import Path
import os,re,subprocess,zipfile,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
if not os.environ.get('BRAVIA_SIGNING_PASSWORD'):
    raise SystemExit('Missing BRAVIA_SIGNING_PASSWORD secret; release build stopped')
if not (root/'signing/bravia-glass.jks').is_file():
    raise SystemExit('Missing private signing keystore; release build stopped')
sdk=Path(os.environ['ANDROID_HOME']);jdk=Path(os.environ['JAVA_HOME'])
build=root/'app/build/native-release';build.mkdir(parents=True,exist_ok=True)
bt=sdk/'build-tools/35.0.0';android=sdk/'platforms/android-35/android.jar'
gradle=(root/'app/build.gradle').read_text();version=re.search(r"versionName '([^']+)'",gradle).group(1);code=re.search(r'versionCode (\d+)',gradle).group(1)
def run(*args):subprocess.run([str(x) for x in args],check=True)
manifest=(root/'app/src/main/AndroidManifest.xml').read_text().replace('<manifest ','<manifest package="com.usman.braviaglass" ',1)
(build/'AndroidManifest.xml').write_text(manifest)
run(bt/'aapt2','compile','--dir',root/'app/src/main/res','-o',build/'resources.zip')
run(bt/'aapt2','link','-o',build/'unsigned.apk','-I',android,'--manifest',build/'AndroidManifest.xml','-A',root/'app/src/main/assets','--java',build/'generated','--min-sdk-version','24','--target-sdk-version','35','--version-code',code,'--version-name',version,build/'resources.zip')
classes=build/'classes';classes.mkdir(exist_ok=True)
files=list((root/'app/src/main/java').rglob('*.java'))+list((build/'generated').rglob('*.java'))
run(jdk/'bin/javac','-encoding','UTF-8','-source','17','-target','17','-classpath',android,'-d',classes,*files)
run(jdk/'bin/jar','cf',build/'classes.jar','-C',classes,'.')
dex=build/'dex';dex.mkdir(exist_ok=True)
run(bt/'d8','--release','--lib',android,'--min-api','24','--output',dex,build/'classes.jar')
with zipfile.ZipFile(build/'unsigned.apk','a',zipfile.ZIP_DEFLATED) as z:
 for f in dex.glob('*.dex'):z.write(f,f.name)
run(bt/'zipalign','-f','4',build/'unsigned.apk',build/'aligned.apk')
out=build/('BraviaGlass-'+version+'.apk')
run(bt/'apksigner','sign','--ks',root/'signing/bravia-glass.jks','--ks-key-alias','braviaglass','--ks-pass','env:BRAVIA_SIGNING_PASSWORD','--key-pass','env:BRAVIA_SIGNING_PASSWORD','--out',out,build/'aligned.apk')
run(bt/'apksigner','verify','--verbose',out)
print(out)
